/**
 * UTILS — funções compartilhadas, com foco em nunca deixar dado vindo
 * do banco (ou digitado por alguém) virar HTML/atributo executável.
 *
 * Regra geral usada em todo o app: texto livre (nome, observação,
 * pedido de oração etc.) SEMPRE passa por escapeHtml antes de entrar
 * num template string que vira innerHTML. Links (tel:, mailto:,
 * https://wa.me/...) sempre passam por sanitizarUrl, que só deixa
 * passar esquemas conhecidos e caracteres esperados — nunca um valor
 * cru vindo do banco.
 */

// Ver o comentário equivalente em js/logica-pura.js: isso evita que um
// `const DateUtil` local esconda o DateUtil global de verdade no navegador.
const _DateUtilRefParaUtils = typeof module !== "undefined" && module.exports ? require("./datetime.js") : DateUtil;

const Utils = (() => {
  const DateUtil = _DateUtilRefParaUtils;

  function toArray(obj) {
    if (!obj) return [];
    return Object.entries(obj).map(([id, val]) => ({ id, ...val }));
  }

  function initials(name) {
    if (!name) return "?";
    const parts = name.trim().split(/\s+/);
    const first = parts[0]?.[0] || "";
    const last = parts.length > 1 ? parts[parts.length - 1][0] : "";
    return (first + last).toUpperCase();
  }

  function todayISO() {
    return DateUtil.hojeISO();
  }

  function sha256Indisponivel() {
    // Mantido apenas para compatibilidade de referência — o app não usa
    // mais hash de senha em lugar nenhum (autenticação é 100% Firebase).
    throw new Error("Removido: autenticação agora é via Firebase Authentication.");
  }

  function toast(msg, kind = "info") {
    const el = document.createElement("div");
    el.className = `toast toast-${kind}`;
    el.textContent = msg; // textContent — nunca innerHTML aqui
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add("show"));
    setTimeout(() => {
      el.classList.remove("show");
      setTimeout(() => el.remove(), 300);
    }, 2600);
  }

  function openModal(html) {
    closeModal();
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay";
    overlay.id = "activeModal";
    const card = document.createElement("div");
    card.className = "modal-card";
    card.innerHTML = html; // o chamador é responsável por já ter escapado os dados dinâmicos
    overlay.appendChild(card);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeModal();
    });
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add("show"));
    return card;
  }

  function closeModal() {
    const existing = document.getElementById("activeModal");
    if (existing) existing.remove();
  }

  /** Escapa texto para uso seguro dentro de HTML (texto ou atributo). */
  function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /**
   * Sanitiza uma URL antes de usar em href/src. Só permite os esquemas
   * explicitamente esperados pelo app — qualquer outra coisa (incluindo
   * "javascript:", "data:" fora do previsto, etc.) vira "#" (link morto)
   * em vez de ser inserida crua no HTML.
   */
  function sanitizarUrl(url, esquemasPermitidos = ["https:", "tel:", "mailto:"]) {
    if (!url) return "#";
    try {
      // Para tel:/mailto: o construtor URL exige um formato específico;
      // fazemos uma checagem simples de prefixo para esses dois casos.
      if (/^tel:/i.test(url) || /^mailto:/i.test(url)) {
        const esquema = url.split(":")[0].toLowerCase() + ":";
        if (!esquemasPermitidos.includes(esquema)) return "#";
        return escapeHtml(url);
      }
      const parsed = new URL(url, window.location.href);
      if (!esquemasPermitidos.includes(parsed.protocol)) return "#";
      return escapeHtml(parsed.href);
    } catch {
      return "#";
    }
  }

  function normalizarTelefone(telefone) {
    return (telefone || "").replace(/\D/g, "");
  }

  function normalizarNome(nome) {
    return (nome || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // remove acentos
      .replace(/\s+/g, " ")
      .trim();
  }

  function nomesParecidos(a, b) {
    const na = normalizarNome(a);
    const nb = normalizarNome(b);
    if (!na || !nb) return false;
    if (na === nb) return true;
    // heurística simples: mesmo primeiro nome + algum sobrenome em comum
    const [primA, ...restA] = na.split(" ");
    const [primB, ...restB] = nb.split(" ");
    if (primA === primB && restA.some((s) => restB.includes(s))) return true;
    return false;
  }

  /**
   * Valida uma data opcional no formato YYYY-MM-DD. Campo vazio é
   * válido (o campo é opcional) — só validamos de verdade quando algo
   * foi digitado. Detecta datas que "não existem" (ex.: 31/02) porque
   * o JS normalmente aceita "2000-02-31" e silenciosamente vira
   * 2000-03-02 — aqui a gente confere se os componentes batem depois
   * de montar a data, e só aceita se baterem exatamente.
   */
  function validarDataOpcional(valor, { proibirFutura = false } = {}) {
    if (!valor) return { valido: true, vazio: true };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(valor)) {
      return { valido: false, motivo: "Use o formato de data do calendário (dia/mês/ano)." };
    }
    const [ano, mes, dia] = valor.split("-").map(Number);
    const d = new Date(Date.UTC(ano, mes - 1, dia, 12, 0, 0));
    const dataExiste = d.getUTCFullYear() === ano && d.getUTCMonth() === mes - 1 && d.getUTCDate() === dia;
    if (!dataExiste) {
      return { valido: false, motivo: "Essa data não existe no calendário — confira o dia e o mês." };
    }
    if (proibirFutura && valor > DateUtil.hojeISO()) {
      return { valido: false, motivo: "Essa data ainda não aconteceu — não pode ser no futuro." };
    }
    return { valido: true, vazio: false };
  }

  function astronautIcon() {
    // Avatar padrão oficial: foto do astronauta (arquivo de marca), não
    // mais um ícone desenhado. Nome da função mantido por compatibilidade
    // com todos os lugares que já chamam Utils.astronautIcon().
    return `<img src="assets/images/default-astronaut-avatar.webp" alt="" loading="lazy" width="96" height="96" />`;
  }

  function avatarInner(pessoa) {
    if (pessoa && pessoa.fotoUrl) return "";
    return astronautIcon();
  }

  function logoImg(classe = "") {
    const nomeGc = typeof CONFIG !== "undefined" && CONFIG.GC_NOME ? CONFIG.GC_NOME : "GC Top do Universo";
    return `<img src="assets/images/gc-top-logo.webp" alt="${nomeGc}" class="${classe}" loading="eager" />`;
  }

  function dateBadgeHTML(iso) {
    const d = new Date(iso + "T12:00:00");
    const dow = d.toLocaleDateString("pt-BR", { weekday: "short", timeZone: typeof CONFIG !== "undefined" ? CONFIG.FUSO_HORARIO : undefined }).replace(".", "");
    const mon = d.toLocaleDateString("pt-BR", { month: "short", timeZone: typeof CONFIG !== "undefined" ? CONFIG.FUSO_HORARIO : undefined }).replace(".", "");
    return `<div class="date-badge"><div class="dow">${dow}</div><div class="day">${String(d.getDate()).padStart(2, "0")}</div><div class="mon">${mon}</div></div>`;
  }

  function iconSearch() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M20 20l-4.8-4.8"/></svg>`;
  }

  function daysUntilNextBirthday(iso) {
    return DateUtil.diasAteProximoAniversario(iso);
  }

  function daysSince(iso) {
    return DateUtil.diasSince(iso);
  }

  function parseDateBR(iso) {
    return DateUtil.formatarDataBR(iso);
  }

  function formatBirthdayShort(iso) {
    return DateUtil.formatarDataCurta(iso);
  }

  function statusBadgeClass(situacao) {
    const map = {
      visitante: "badge-blue",
      "visitante recorrente": "badge-teal",
      membro: "badge-green",
      "novo integrado": "badge-gold",
      "afastado/inativo": "badge-muted",
    };
    return map[situacao] || "badge-muted";
  }

  function capitalize(s) {
    if (!s) return "—";
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  return {
    toArray,
    initials,
    todayISO,
    toast,
    openModal,
    closeModal,
    escapeHtml,
    sanitizarUrl,
    normalizarTelefone,
    normalizarNome,
    nomesParecidos,
    validarDataOpcional,
    astronautIcon,
    avatarInner,
    logoImg,
    iconSearch,
    dateBadgeHTML,
    daysUntilNextBirthday,
    daysSince,
    parseDateBR,
    formatBirthdayShort,
    statusBadgeClass,
    capitalize,
  };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = Utils;
}
