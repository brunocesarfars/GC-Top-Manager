/**
 * DATETIME — utilitário central de datas, sempre em America/Sao_Paulo.
 *
 * Por que isto existe: o bug mais comum em apps assim é usar
 * `new Date()` ou `.toISOString()` cru, que trabalham em UTC e fazem a
 * data "virar" antes da hora certa no Brasil (ex.: 21h de um dia vira
 * o dia seguinte em UTC). Todo lugar do app que precisa da data de
 * hoje, de aniversário, de encontro etc. deve passar por aqui — nunca
 * usar `new Date().toISOString().slice(0,10)` direto no código.
 *
 * Observação: o Brasil aboliu o horário de verão em 2019, então
 * America/Sao_Paulo hoje é sempre UTC-3 fixo. Ainda assim usamos
 * Intl.DateTimeFormat com timeZone explícito (em vez de um offset fixo
 * "-03:00" cravado no código) para o utilitário continuar correto caso
 * isso mude novamente no futuro.
 *
 * Funciona tanto no navegador quanto no Node (para os testes em
 * tests/logica.test.js) — por isso o `module.exports` condicional no
 * final do arquivo.
 */

const DateUtil = (() => {
  const TZ = "America/Sao_Paulo";

  function hojeISO(base = new Date()) {
    return new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(base);
  }

  function agoraPartsSP(base = new Date()) {
    const fmt = new Intl.DateTimeFormat("en-CA", {
      timeZone: TZ,
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
      hour12: false,
    });
    const parts = {};
    fmt.formatToParts(base).forEach((p) => (parts[p.type] = p.value));
    return {
      ano: Number(parts.year), mes: Number(parts.month), dia: Number(parts.day),
      hora: Number(parts.hour), minuto: Number(parts.minute), segundo: Number(parts.second),
    };
  }

  function isoParaDataUTCMeioDia(iso) {
    // Converte "YYYY-MM-DD" num Date em UTC ao meio-dia — evita qualquer
    // problema de fuso na comparação/diferença de datas (meio-dia nunca
    // "vira o dia" por causa de offset de poucas horas).
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  }

  function diasEntre(isoInicio, isoFim) {
    const a = isoParaDataUTCMeioDia(isoInicio);
    const b = isoParaDataUTCMeioDia(isoFim);
    return Math.round((b - a) / 86400000);
  }

  function diasSince(iso, hoje = hojeISO()) {
    if (!iso) return null;
    return diasEntre(iso, hoje);
  }

  function ehBissexto(ano) {
    return (ano % 4 === 0 && ano % 100 !== 0) || ano % 400 === 0;
  }

  /**
   * Dias até o próximo aniversário a partir de "hoje" (ISO, America/Sao_Paulo).
   * Trata 29/fev: em anos não bissextos, o aniversário é considerado em
   * 28/fev (escolha documentada — dá pra trocar para 1/mar mudando a
   * linha marcada abaixo, mas o comportamento precisa ser o mesmo em
   * todo o sistema, por isso está centralizado aqui).
   */
  function diasAteProximoAniversario(nascimentoISO, hojeISOStr = hojeISO()) {
    if (!nascimentoISO) return null;
    const [, mesStr, diaStr] = nascimentoISO.split("-");
    let mes = Number(mesStr);
    let dia = Number(diaStr);
    const [anoHoje, mesHoje, diaHoje] = hojeISOStr.split("-").map(Number);

    function aniversarioNoAno(ano) {
      if (mes === 2 && dia === 29 && !ehBissexto(ano)) {
        return `${ano}-02-28`; // <- escolha documentada acima
      }
      return `${ano}-${String(mes).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;
    }

    let candidato = aniversarioNoAno(anoHoje);
    if (diasEntre(hojeISOStr, candidato) < 0) {
      candidato = aniversarioNoAno(anoHoje + 1);
    }
    return diasEntre(hojeISOStr, candidato);
  }

  function formatarDataBR(iso) {
    if (!iso) return "—";
    const [y, m, d] = iso.split("-");
    return `${d}/${m}/${y}`;
  }

  function formatarDataCurta(iso) {
    if (!iso) return "—";
    const [, m, d] = iso.split("-");
    return `${d}/${m}`;
  }

  return {
    TZ,
    hojeISO,
    agoraPartsSP,
    diasEntre,
    diasSince,
    ehBissexto,
    diasAteProximoAniversario,
    formatarDataBR,
    formatarDataCurta,
  };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = DateUtil;
}
