/**
 * Registro do service worker + aviso de "nova versão disponível".
 *
 * Fluxo: quando existe um service worker novo instalado (esperando,
 * porque sw.js não chama skipWaiting sozinho), mostramos um aviso
 * discreto. Só troca de versão quando a pessoa toca em "Atualizar" —
 * nunca troca o app debaixo dela sem avisar.
 */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("sw.js")
      .then((registro) => {
        if (registro.waiting) mostrarAvisoAtualizacao(registro.waiting);

        registro.addEventListener("updatefound", () => {
          const novo = registro.installing;
          if (!novo) return;
          novo.addEventListener("statechange", () => {
            if (novo.state === "installed" && navigator.serviceWorker.controller) {
              mostrarAvisoAtualizacao(novo);
            }
          });
        });
      })
      .catch(() => {
        /* PWA offline é um extra — se falhar, o app continua funcionando normalmente online */
      });

    let recarregouUmaVez = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (recarregouUmaVez) return;
      recarregouUmaVez = true;
      window.location.reload();
    });
  });
}

function mostrarAvisoAtualizacao(worker) {
  if (document.getElementById("bannerAtualizacao")) return;
  const banner = document.createElement("div");
  banner.id = "bannerAtualizacao";
  banner.className = "update-banner";
  banner.innerHTML = `
    <span style="font-size:13px;">Nova versão disponível.</span>
    <button class="btn btn-primary" id="btnAtualizarAgora" style="padding:8px 14px;font-size:12.5px;white-space:nowrap;">Atualizar</button>
  `;
  document.body.appendChild(banner);
  document.getElementById("btnAtualizarAgora").addEventListener("click", () => {
    worker.postMessage({ type: "SKIP_WAITING" });
    banner.remove();
  });
}
