/**
 * PERMISSÕES — matriz central. Isto governa o que a INTERFACE mostra
 * e habilita — é conveniência de UX, não segurança. A segurança de
 * verdade está em rules/database.rules.json, que o servidor do
 * Firebase aplica independente do que rodar no navegador (alguém
 * pode inspecionar/alterar este arquivo no próprio navegador e ainda
 * assim as regras do banco vão negar o que não for permitido).
 */

const Permissoes = (() => {
  const MATRIZ = {
    admin: {
      verPessoas: true,
      editarPessoas: true,
      arquivarPessoas: true,
      anonimizarPessoas: true,
      excluirDefinitivamente: true,
      verEncontros: true,
      registrarPresenca: true,
      editarEncontros: true,
      arquivarEncontros: true,
      adicionarVisitante: true,
      verVisitantes: true,
      verPulpito: true,
      editarPulpito: true,
      verAniversariantes: true,
      editarConfigAniversario: true,
      verOracaoVisivel: true,
      verOracaoPrivada: true,
      editarOracao: true,
      verAcompanhamentoPastoral: true,
      editarAcompanhamentoPastoral: true,
      verCuidado: true,
      resolverCuidado: true,
      gerenciarUsuarios: true,
      verLixeira: true,
      restaurarLixeira: true,
    },
    lideranca: {
      verPessoas: true,
      editarPessoas: true,
      arquivarPessoas: false,
      anonimizarPessoas: false,
      excluirDefinitivamente: false,
      verEncontros: true,
      registrarPresenca: true,
      editarEncontros: true,
      arquivarEncontros: false,
      adicionarVisitante: true,
      verVisitantes: true,
      verPulpito: true,
      editarPulpito: false,
      verAniversariantes: true,
      editarConfigAniversario: false,
      verOracaoVisivel: true,
      verOracaoPrivada: false,
      editarOracao: true,
      verAcompanhamentoPastoral: false,
      editarAcompanhamentoPastoral: false,
      verCuidado: true,
      resolverCuidado: true,
      gerenciarUsuarios: false,
      verLixeira: false,
      restaurarLixeira: false,
    },
  };

  function pode(papel, acao) {
    if (!papel || !MATRIZ[papel]) return false;
    return !!MATRIZ[papel][acao];
  }

  return { MATRIZ, pode };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = Permissoes;
}
