/**
 * LOGICA PURA — regras de negócio sem nenhuma dependência de DOM,
 * Firebase ou navegador. Isso existe separado de propósito: são estas
 * funções que os testes em tests/logica.test.js exercitam diretamente
 * com `node tests/logica.test.js`, sem precisar simular um navegador
 * nem um banco de dados.
 */

// Captura DateUtil ANTES do IIFE abaixo criar seu próprio escopo — se
// declarássemos isso dentro do IIFE com o mesmo nome, o `const DateUtil`
// interno "esconderia" o DateUtil global de verdade no navegador (uma
// referência tipo `window.DateUtil` NÃO enxerga `const DateUtil` de
// outro <script>, só o identificador solto enxerga). Isso já foi um
// bug real aqui — corrigido.
const _DateUtilRefParaLogica = typeof module !== "undefined" && module.exports ? require("./datetime.js") : DateUtil;

const Logica = (() => {
  // Em navegador, DateUtil já é global (script carregado antes deste).
  // Em Node (testes), precisa ser importado explicitamente.
  const DateUtil = _DateUtilRefParaLogica;

  const ELEGIVEL_SITUACOES = ["membro", "novo integrado"];

  /**
   * Snapshot de quem é elegível para um encontro NA DATA em que o
   * snapshot é tirado (normalmente ao criar o encontro ou na primeira
   * vez que a tela de presença é aberta). Isso trava a lista: pessoas
   * cadastradas depois não "aparecem" retroativamente como ausentes
   * em encontros antigos, e pessoas que ainda não tinham chegado ao
   * GC na data do encontro não entram na conta.
   */
  function calcularElegiveis(pessoas, dataEncontroISO) {
    return pessoas
      .filter((p) => !p.arquivadoEm)
      .filter((p) => ELEGIVEL_SITUACOES.includes(p.situacao))
      .filter((p) => !p.chegouEm || p.chegouEm <= dataEncontroISO)
      .map((p) => p.id);
  }

  /**
   * Garante que TODO elegível tenha uma entrada explícita true/false
   * em presenca — nunca undefined. Visitantes marcados também são
   * preservados como estão (true/false), nunca inferidos.
   */
  function montarPresencaExplicita(participantesElegiveis, presencaParcial, visitantesIds = []) {
    const resultado = {};
    participantesElegiveis.forEach((id) => {
      resultado[id] = presencaParcial[id] === true;
    });
    visitantesIds.forEach((id) => {
      resultado[id] = presencaParcial[id] === true;
    });
    return resultado;
  }

  function calcularTotais(presenca, participantesElegiveis, visitantesIds = []) {
    const elegiveisSet = new Set(participantesElegiveis);
    const visitantesSet = new Set(visitantesIds);
    let totalMembrosPresentes = 0;
    let totalVisitantesPresentes = 0;
    Object.entries(presenca).forEach(([id, presente]) => {
      if (!presente) return;
      if (elegiveisSet.has(id)) totalMembrosPresentes++;
      else if (visitantesSet.has(id)) totalVisitantesPresentes++;
    });
    return {
      totalMembrosPresentes,
      totalVisitantesPresentes,
      totalPresentes: totalMembrosPresentes + totalVisitantesPresentes,
    };
  }

  function encontrosRealizados(encontros, hojeISO) {
    return encontros.filter((e) => e.data && e.data <= hojeISO);
  }

  /**
   * Frequência individual = encontros em que a pessoa esteve presente
   * dividido pelos encontros para os quais ela era elegível (isto é,
   * já tinha chegado ao GC e o encontro já aconteceu). Nunca ultrapassa
   * 100% porque o numerador é sempre subconjunto do denominador.
   */
  function frequenciaIndividual(pessoaId, encontros, hojeISO) {
    const realizados = encontrosRealizados(encontros, hojeISO);
    let elegivel = 0;
    let presente = 0;
    realizados.forEach((e) => {
      const elegiveis = e.participantesElegiveis || [];
      if (!elegiveis.includes(pessoaId)) return;
      elegivel++;
      if (e.presenca && e.presenca[pessoaId] === true) presente++;
    });
    const percentual = elegivel > 0 ? Math.min(100, Math.round((presente / elegivel) * 100)) : 0;
    return { elegivel, presente, percentual };
  }

  /**
   * Frequência geral = soma de membros presentes / soma de membros
   * elegíveis, olhando só para encontros já realizados. Visitantes
   * nunca entram nesta conta (nem no numerador nem no denominador).
   */
  function frequenciaGeral(encontros, hojeISO) {
    const realizados = encontrosRealizados(encontros, hojeISO);
    let somaElegiveis = 0;
    let somaPresentes = 0;
    realizados.forEach((e) => {
      const elegiveis = e.participantesElegiveis || [];
      somaElegiveis += elegiveis.length;
      somaPresentes += elegiveis.filter((id) => e.presenca && e.presenca[id] === true).length;
    });
    const percentual = somaElegiveis > 0 ? Math.min(100, Math.round((somaPresentes / somaElegiveis) * 100)) : 0;
    return { somaElegiveis, somaPresentes, percentual };
  }

  /**
   * Indicador de visitantes, separado da frequência de membros:
   * quantas vezes cada visitante apareceu marcado como presente.
   */
  function frequenciaVisitante(pessoaId, encontros, hojeISO) {
    const realizados = encontrosRealizados(encontros, hojeISO);
    let visitas = 0;
    realizados.forEach((e) => {
      if ((e.visitantesIds || []).includes(pessoaId) && e.presenca && e.presenca[pessoaId] === true) visitas++;
    });
    return visitas;
  }

  /**
   * Cuidado e acompanhamento — identifica quem pode precisar de
   * contato. Nunca olha para o futuro, nunca cobra alguém por
   * encontros anteriores à entrada dele no GC (isso já vem garantido
   * pelo snapshot de participantesElegiveis), e nunca duplica: cada
   * pessoa aparece no máximo uma vez, com o motivo mais relevante.
   */
  function identificarCuidado(pessoas, encontros, hojeISO, contatosResolvidos = {}) {
    const realizados = encontrosRealizados(encontros, hojeISO).sort((a, b) => (a.data < b.data ? 1 : -1)); // mais recentes primeiro
    const resultado = [];

    pessoas
      .filter((p) => !p.arquivadoEm && ELEGIVEL_SITUACOES.includes(p.situacao))
      .forEach((p) => {
        const participacoes = realizados.filter((e) => (e.participantesElegiveis || []).includes(p.id));
        if (!participacoes.length) return;

        let faltasConsecutivas = 0;
        for (const e of participacoes) {
          if (e.presenca && e.presenca[p.id] === false) faltasConsecutivas++;
          else break;
        }

        const ultimaPresenca = participacoes.find((e) => e.presenca && e.presenca[p.id] === true);
        const diasSemParticipar = ultimaPresenca ? DateUtil.diasEntre(ultimaPresenca.data, hojeISO) : null;

        const motivos = [];
        if (faltasConsecutivas >= 3) motivos.push(`Ausência nos últimos ${faltasConsecutivas} encontros`);
        if (diasSemParticipar !== null && diasSemParticipar >= 15) motivos.push(`Último encontro há ${diasSemParticipar} dias`);
        if (!ultimaPresenca && participacoes.length >= 2) motivos.push(`Elegível em ${participacoes.length} encontros e ainda não participou`);

        if (!motivos.length) return;

        const chaveResolucao = `${p.id}`;
        const resolvido = contatosResolvidos[chaveResolucao];
        if (resolvido && resolvido.status === "concluido") return;
        if (resolvido && resolvido.status === "adiado" && resolvido.adiadoAte && resolvido.adiadoAte > hojeISO) return;

        resultado.push({
          pessoaId: p.id,
          motivo: motivos.join(" · "),
          faltasConsecutivas,
          diasSemParticipar,
        });
      });

    return resultado.sort((a, b) => (b.diasSemParticipar || 0) - (a.diasSemParticipar || 0));
  }

  return {
    ELEGIVEL_SITUACOES,
    calcularElegiveis,
    montarPresencaExplicita,
    calcularTotais,
    encontrosRealizados,
    frequenciaIndividual,
    frequenciaGeral,
    frequenciaVisitante,
    identificarCuidado,
  };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = Logica;
}
