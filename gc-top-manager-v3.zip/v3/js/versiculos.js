/**
 * VERSÍCULOS DO CARD BÍBLICO — sorteia 1 de 10 a cada abertura do app.
 *
 * Nota sobre a tradução: a NVI (Nova Versão Internacional) é uma
 * tradução com direitos autorais registrados (Biblica/Sociedade
 * Bíblica Internacional) — reproduzir o texto dela não é algo que eu
 * possa fazer. Usei a redação de Almeida (domínio público no Brasil),
 * que carrega o mesmo sentido dos textos. Se vocês tiverem uma
 * licença de uso da NVI, é só trocar o campo `texto` de cada item
 * abaixo pela redação de vocês — a lógica de sorteio não muda.
 *
 * Curadoria: só entrou versículo que fala de comunhão, grupo pequeno,
 * estar junto, cuidar uns dos outros — o tema do GC.
 */
const Versiculos = (() => {
  const LISTA = [
    { texto: "Melhor é serem dois do que um só, pois têm melhor paga do trabalho.", ref: "Eclesiastes 4:9" },
    { texto: "Um cordão de três dobras não se rebenta facilmente.", ref: "Eclesiastes 4:12" },
    { texto: "Onde dois ou três estiverem reunidos em meu nome, aí estou no meio deles.", ref: "Mateus 18:20" },
    { texto: "Perseveravam na doutrina, na comunhão, no partir do pão e nas orações.", ref: "Atos 2:42" },
    { texto: "Amai-vos cordialmente uns aos outros com amor fraternal.", ref: "Romanos 12:10" },
    { texto: "Levai as cargas uns dos outros, e assim cumprireis a lei de Cristo.", ref: "Gálatas 6:2" },
    { texto: "Exortai-vos uns aos outros cada dia, enquanto ainda se diz: hoje.", ref: "Hebreus 3:13" },
    { texto: "Como o ferro afia o ferro, o homem afia o seu amigo.", ref: "Provérbios 27:17" },
    { texto: "Que os membros tenham o mesmo cuidado uns pelos outros.", ref: "1 Coríntios 12:25" },
    { texto: "Confessai as vossas culpas uns aos outros, e orai uns pelos outros.", ref: "Tiago 5:16" },
  ];

  // Sorteia uma vez por carregamento do app (não muda a cada re-render
  // da tela dentro da mesma sessão) — guarda em módulo, não em storage.
  let escolhido = null;

  function sortear() {
    if (!escolhido) {
      escolhido = LISTA[Math.floor(Math.random() * LISTA.length)];
    }
    return escolhido;
  }

  return { LISTA, sortear };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = Versiculos;
}
