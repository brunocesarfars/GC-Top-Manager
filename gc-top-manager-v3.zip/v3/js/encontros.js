/**
 * ENCONTROS — agenda do GC, presença rápida pelo celular.
 *
 * A cada encontro é tirado um "snapshot" de quem era elegível
 * (participantesElegiveis) na data dele — isso trava a lista de forma
 * que pessoas cadastradas depois não contam como ausentes em
 * encontros antigos, e ninguém é cobrado por um encontro anterior à
 * própria entrada no GC. Ver js/logica-pura.js para a lógica exata
 * (com testes em tests/logica.test.js).
 */

const Encontros = (() => {
  let aba = "proximos";

  function iconPin() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-6.6 7-11.5A7 7 0 0 0 5 9.5C5 14.4 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.3"/></svg>`;
  }
  function iconClock() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>`;
  }

  function render(screen, state, session) {
    const podeCriar = Permissoes.pode(session.papel, "editarEncontros");
    const hoje = state.hojeISO;
    const lista = state.encontros
      .filter((e) => !e.arquivadoEm)
      .filter((e) => (aba === "proximos" ? e.data >= hoje : e.data < hoje))
      .sort((a, b) => (aba === "proximos" ? (a.data > b.data ? 1 : -1) : a.data > b.data ? -1 : 1));

    screen.innerHTML = `
      <div class="topbar">
        <h1>Encontros</h1>
        ${podeCriar ? `<button class="icon-btn" id="addEncontroBtn">+</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div class="chip-row">
        <button class="chip ${aba === "proximos" ? "active" : ""}" data-a="proximos">Próximos</button>
        <button class="chip ${aba === "realizados" ? "active" : ""}" data-a="realizados">Realizados</button>
      </div>
      <div class="row-list">
        ${
          lista.length
            ? lista
                .map((e) => {
                  return `<button class="card" style="width:100%;margin-bottom:10px;" data-nav="encontros/${e.id}">
                <div class="encontro-card-row">
                  ${Utils.dateBadgeHTML(e.data)}
                  <div class="info">
                    <div class="titulo">${Utils.escapeHtml(e.tema || "Encontro do GC")}</div>
                    <div class="sub">${Utils.escapeHtml(e.textoBiblico || "")}</div>
                    <div class="linha2">
                      <span>${iconPin()}${Utils.escapeHtml(e.local || "—")}</span>
                      <span>${iconClock()}${Utils.escapeHtml(e.hora || "")}${e.hora ? "h" : ""}</span>
                    </div>
                  </div>
                  <span class="chev">›</span>
                </div>
              </button>`;
                })
                .join("")
            : `<div class="card empty-state"><div class="glyph">📅</div><p>Nenhum encontro ${aba === "proximos" ? "agendado" : "registrado"}.</p></div>`
        }
      </div>
    `;

    screen.querySelectorAll("[data-nav]").forEach((el) => el.addEventListener("click", () => App.navigate(el.dataset.nav)));
    screen.querySelector(".chip-row").addEventListener("click", (e) => {
      const btn = e.target.closest(".chip");
      if (!btn) return;
      aba = btn.dataset.a;
      render(screen, state, session);
    });
    if (podeCriar) document.getElementById("addEncontroBtn").addEventListener("click", () => openForm(null, state, session));
  }

  async function garantirElegiveis(encontro, state) {
    if (encontro.participantesElegiveis) return encontro.participantesElegiveis;
    // Encontro antigo sem snapshot (ex.: criado antes desta versão) — gera agora e salva.
    const elegiveis = Logica.calcularElegiveis(state.pessoas, encontro.data);
    try {
      await Api.update("encontros", encontro.id, { participantesElegiveis: elegiveis });
    } catch {
      /* segue mesmo se não conseguir persistir agora (ex.: sem permissão) */
    }
    encontro.participantesElegiveis = elegiveis;
    return elegiveis;
  }

  async function renderDetail(screen, state, id, session) {
    const e = state.encontros.find((x) => x.id === id);
    if (!e) {
      screen.innerHTML = `<div class="empty-state">Encontro não encontrado.</div>`;
      return;
    }
    const elegiveis = await garantirElegiveis(e, state);
    const membros = elegiveis.map((mid) => state.pessoas.find((p) => p.id === mid)).filter(Boolean);
    const visitantesIds = e.visitantesIds || [];
    const visitantesDoEncontro = visitantesIds.map((vid) => state.pessoas.find((p) => p.id === vid)).filter(Boolean);
    const todasPessoas = [...membros, ...visitantesDoEncontro];
    const presenca = e.presenca || {};
    const totalMarcados = todasPessoas.filter((p) => presenca[p.id] === true).length;
    const podeEditar = Permissoes.pode(session.papel, "editarEncontros");
    const podeRegistrarPresenca = Permissoes.pode(session.papel, "registrarPresenca");
    const podeAdicionarVisitante = Permissoes.pode(session.papel, "adicionarVisitante");

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1 style="font-size:16px;">Presença</h1>
        ${podeEditar ? `<button class="icon-btn" id="editEncontroBtn">✎</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div class="card" style="margin-bottom:14px;">
        <div class="encontro-card-row">
          ${Utils.dateBadgeHTML(e.data)}
          <div class="info">
            <div class="titulo">${Utils.escapeHtml(e.tema || "Encontro do GC")}</div>
            <div class="linha2">
              <span>${iconPin()}${Utils.escapeHtml(e.local || "")}</span>
              <span>${iconClock()}${Utils.escapeHtml(e.hora || "")}${e.hora ? "h" : ""}</span>
            </div>
            <div class="sub" style="margin-top:4px;">${Utils.escapeHtml(e.textoBiblico || "")}</div>
          </div>
        </div>
      </div>

      <div class="stat-grid" style="grid-template-columns:repeat(3,1fr);">
        <div class="stat-card"><div class="value">${membros.length}</div><div class="label">Elegíveis</div></div>
        <div class="stat-card"><div class="value">${visitantesDoEncontro.length}</div><div class="label">Visitantes</div></div>
        <div class="stat-card"><div class="value">${totalMarcados}</div><div class="label">Total presente</div></div>
      </div>

      <div class="search-box"><span>${Utils.iconSearch()}</span><input id="presencaSearch" placeholder="Buscar pessoa…" /></div>

      <div class="card row-list" id="checklistWrap">
        ${todasPessoas
          .map(
            (p) => `<div class="check-row" data-pessoa="${Utils.escapeHtml(p.id)}" data-name="${Utils.escapeHtml((p.nomeCompleto || "").toLowerCase())}">
              <div class="check-box ${presenca[p.id] ? "checked" : ""} ${podeRegistrarPresenca ? "" : "disabled"}" ${podeRegistrarPresenca ? `data-toggle="${Utils.escapeHtml(p.id)}"` : ""}>${presenca[p.id] ? "✓" : ""}</div>
              <div style="flex:1;">${Utils.escapeHtml(p.nomeCompleto)}</div>
              ${visitantesIds.includes(p.id) ? `<span class="badge badge-blue">Visitante</span>` : ""}
            </div>`
          )
          .join("")}
      </div>

      ${podeAdicionarVisitante ? `<button class="btn btn-secondary btn-block" id="addVisitanteBtn" style="margin-top:14px;">+ Adicionar visitante</button>` : ""}
      ${podeRegistrarPresenca ? `<button class="btn btn-primary btn-block" id="salvarPresencaBtn" style="margin-top:10px;">Salvar presença</button>` : ""}
    `;

    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("encontros"));

    const localPresenca = { ...presenca };
    if (podeRegistrarPresenca) {
      screen.querySelector("#checklistWrap").addEventListener("click", (ev) => {
        const box = ev.target.closest("[data-toggle]");
        if (!box) return;
        const pid = box.dataset.toggle;
        localPresenca[pid] = !localPresenca[pid];
        box.classList.toggle("checked");
        box.textContent = localPresenca[pid] ? "✓" : "";
      });
    }

    document.getElementById("presencaSearch").addEventListener("input", (ev) => {
      const term = ev.target.value.toLowerCase();
      screen.querySelectorAll("[data-name]").forEach((row) => {
        row.style.display = row.dataset.name.includes(term) ? "flex" : "none";
      });
    });

    if (podeRegistrarPresenca) {
      document.getElementById("salvarPresencaBtn").addEventListener("click", async () => {
        const presencaExplicita = Logica.montarPresencaExplicita(elegiveis, localPresenca, visitantesIds);
        const totais = Logica.calcularTotais(presencaExplicita, elegiveis, visitantesIds);
        try {
          await Api.update("encontros", e.id, {
            presenca: presencaExplicita,
            participantesElegiveis: elegiveis,
            visitantesIds,
            ...totais,
          });
          Utils.toast("Presença salva!");
          App.reloadData();
        } catch (err) {
          Utils.toast(err.code === "PERMISSION_DENIED" ? "Sem permissão para registrar presença." : "Erro ao salvar.", "error");
        }
      });
    }

    if (podeAdicionarVisitante) document.getElementById("addVisitanteBtn").addEventListener("click", () => openVisitanteRapido(e, state));
    if (podeEditar) document.getElementById("editEncontroBtn").addEventListener("click", () => openForm(e, state, session));
  }

  function openVisitanteRapido(encontro, state) {
    const modal = Utils.openModal(`
      <div class="modal-title">Adicionar visitante</div>
      <div class="field"><label>Nome</label><input id="vNome" /></div>
      <div class="field"><label>Telefone</label><input id="vTelefone" /></div>
      <div class="field"><label>Quem convidou</label><input id="vConvidadoPor" /></div>
      <div id="vDuplicatasWrap"></div>
      <button class="btn btn-primary btn-block" id="salvarVisitanteBtn">Adicionar</button>
    `);

    document.getElementById("salvarVisitanteBtn").addEventListener("click", async () => {
      const nome = document.getElementById("vNome").value.trim();
      const telefone = document.getElementById("vTelefone").value.trim();
      if (!nome) return Utils.toast("Informe o nome.", "error");

      const duplicatas = Pessoas.encontrarPossiveisDuplicatas(nome, telefone, state.pessoas);
      if (duplicatas.length && !modal.dataset.duplicataResolvida) {
        document.getElementById("vDuplicatasWrap").innerHTML = `
          <div class="card" style="border-color:var(--gold);margin-bottom:12px;">
            <div style="font-weight:700;margin-bottom:8px;">Já existe alguém parecido</div>
            ${duplicatas
              .map(
                (d) => `<button type="button" class="row-item" data-usar="${d.id}" style="width:100%;">
                <div class="avatar">${Utils.astronautIcon()}</div>
                <div class="row-main"><div class="name">${Utils.escapeHtml(d.nomeCompleto)}</div><div class="meta">${Utils.escapeHtml(d.telefone || "")}</div></div>
              </button>`
              )
              .join("")}
            <div class="text-dim" style="font-size:12px;margin-top:8px;">Toque em alguém acima para usar o cadastro existente, ou toque em "Adicionar" de novo para criar mesmo assim.</div>
          </div>`;
        modal.dataset.duplicataResolvida = "1";
        document.querySelectorAll("[data-usar]").forEach((btn) =>
          btn.addEventListener("click", async () => {
            const pessoaId = btn.dataset.usar;
            await marcarVisitantePresente(encontro, pessoaId);
            Utils.closeModal();
            App.reloadData();
          })
        );
        return;
      }

      const novaPessoaId = await Api.push("pessoas", {
        nomeCompleto: nome,
        telefone,
        convidadoPor: document.getElementById("vConvidadoPor").value.trim(),
        situacao: "visitante",
        chegouEm: encontro.data,
        situacaoHistorico: [{ situacao: "visitante", data: encontro.data }],
      });
      await marcarVisitantePresente(encontro, novaPessoaId);
      Utils.toast("Visitante adicionado!");
      Utils.closeModal();
      App.reloadData();
    });
  }

  async function marcarVisitantePresente(encontro, pessoaId) {
    const visitantesIds = Array.from(new Set([...(encontro.visitantesIds || []), pessoaId]));
    const presenca = { ...(encontro.presenca || {}), [pessoaId]: true };
    await Api.update("encontros", encontro.id, { visitantesIds, presenca });
  }

  function openForm(encontro, state, session) {
    const isEdit = !!encontro;
    const podeArquivar = isEdit && Permissoes.pode(session.papel, "arquivarEncontros");
    Utils.openModal(`
      <div class="modal-title">${isEdit ? "Editar encontro" : "Novo encontro"}</div>
      <div class="field-row">
        <div class="field"><label>Data</label><input type="date" id="eData" value="${encontro ? encontro.data || "" : ""}" /></div>
        <div class="field"><label>Hora</label><input type="time" id="eHora" value="${encontro ? encontro.hora || "" : ""}" /></div>
      </div>
      <div class="field"><label>Tema</label><input id="eTema" value="${encontro ? Utils.escapeHtml(encontro.tema || "") : ""}" /></div>
      <div class="field"><label>Texto bíblico</label><input id="eTexto" value="${encontro ? Utils.escapeHtml(encontro.textoBiblico || "") : ""}" /></div>
      <div class="field"><label>Responsável pela palavra</label><input id="eResponsavel" value="${encontro ? Utils.escapeHtml(encontro.responsavel || "") : ""}" /></div>
      <div class="field"><label>Local</label><input id="eLocal" value="${encontro ? Utils.escapeHtml(encontro.local || "") : ""}" /></div>
      <div class="field"><label>Observações</label><textarea id="eObs">${encontro ? Utils.escapeHtml(encontro.observacoes || "") : ""}</textarea></div>
      <button class="btn btn-primary btn-block" id="salvarEncontroBtn">Salvar</button>
      ${podeArquivar ? `<button class="btn btn-danger btn-block" style="margin-top:10px;" id="arquivarEncontroBtn">Arquivar (mover para a lixeira)</button>` : ""}
    `);

    document.getElementById("salvarEncontroBtn").addEventListener("click", async () => {
      const data = document.getElementById("eData").value;
      if (!data) return Utils.toast("Informe a data.", "error");

      const dataMudou = isEdit && encontro.data !== data;
      const obj = {
        data,
        hora: document.getElementById("eHora").value,
        tema: document.getElementById("eTema").value.trim(),
        textoBiblico: document.getElementById("eTexto").value.trim(),
        responsavel: document.getElementById("eResponsavel").value.trim(),
        local: document.getElementById("eLocal").value.trim(),
        observacoes: document.getElementById("eObs").value.trim(),
        presenca: encontro ? encontro.presenca || {} : {},
        visitantesIds: encontro ? encontro.visitantesIds || [] : [],
        participantesElegiveis:
          !isEdit || dataMudou ? Logica.calcularElegiveis(state.pessoas, data) : encontro.participantesElegiveis,
      };
      try {
        if (isEdit) await Api.update("encontros", encontro.id, obj);
        else await Api.push("encontros", obj);
        Utils.toast("Encontro salvo!");
        Utils.closeModal();
        App.reloadData();
      } catch (e) {
        Utils.toast(e.code === "PERMISSION_DENIED" ? "Sem permissão para esta ação." : "Erro ao salvar.", "error");
      }
    });

    if (podeArquivar) {
      document.getElementById("arquivarEncontroBtn").addEventListener("click", async () => {
        if (!confirm("Arquivar este encontro? Ele vai para a lixeira.")) return;
        try {
          await Api.update("encontros", encontro.id, { arquivadoEm: Utils.todayISO() });
          Utils.toast("Encontro arquivado.");
          Utils.closeModal();
          App.navigate("encontros");
          App.reloadData();
        } catch (e) {
          Utils.toast("Sem permissão para arquivar.", "error");
        }
      });
    }
  }

  return { render, renderDetail, openForm };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = Encontros;
}
