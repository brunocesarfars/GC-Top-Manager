/**
 * VISITANTES — funil de integração ao GC.
 */

const Visitantes = (() => {
  const ETAPAS = [
    { key: "visitante", label: "Visitou pela 1ª vez" },
    { key: "visitante recorrente", label: "Retornou" },
    { key: "novo integrado", label: "Começou a participar" },
    { key: "membro", label: "Integrado ao GC" },
  ];

  function visitasDe(pessoaId, state) {
    return Logica.encontrosRealizados(state.encontros, state.hojeISO).filter((e) => e.presenca && e.presenca[pessoaId] === true);
  }

  function render(screen, state, session) {
    const pessoasFunil = state.pessoas.filter((p) => !p.arquivadoEm && ETAPAS.some((et) => et.key === p.situacao));
    const contagens = ETAPAS.map((et) => pessoasFunil.filter((p) => p.situacao === et.key).length);

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Visitantes e integração</h1>
        <div style="width:38px;"></div>
      </div>

      <div class="card" style="margin-bottom:16px;">
        ${ETAPAS.map(
          (et, i) => `
          <div style="display:flex;align-items:center;gap:12px;${i > 0 ? "margin-top:6px;" : ""}">
            <div style="width:34px;height:34px;border-radius:50%;background:var(--gold-soft);color:var(--gold-text);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;">${contagens[i]}</div>
            <div style="font-size:13.5px;">${et.label}</div>
          </div>
          ${i < ETAPAS.length - 1 ? `<div style="margin-left:17px;width:1px;height:14px;background:var(--border-strong);"></div>` : ""}
        `
        ).join("")}
      </div>

      <div class="section-title"><h2>Pessoas no funil</h2></div>
      <div class="card row-list">
        ${
          pessoasFunil.length
            ? pessoasFunil
                .map((p) => {
                  const visitas = visitasDe(p.id, state);
                  return `<button class="row-item" data-nav="pessoas/${p.id}">
                <div class="avatar">${Utils.astronautIcon()}</div>
                <div class="row-main">
                  <div class="name">${Utils.escapeHtml(p.nomeCompleto)}</div>
                  <div class="meta"><span class="badge ${Utils.statusBadgeClass(p.situacao)}">${Utils.escapeHtml(p.situacao)}</span> · ${visitas.length} visita${visitas.length === 1 ? "" : "s"}</div>
                  <div class="meta">${p.convidadoPor ? "Convidado por " + Utils.escapeHtml(p.convidadoPor) : ""}</div>
                </div>
                <span class="chev">›</span>
              </button>`;
                })
                .join("")
            : `<div class="empty-state"><div class="glyph">🚀</div><p>Nenhum visitante no funil ainda.</p></div>`
        }
      </div>
    `;

    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("mais"));
    screen.querySelectorAll("[data-nav]").forEach((el) => el.addEventListener("click", () => App.navigate(el.dataset.nav)));
  }

  return { render };
})();
