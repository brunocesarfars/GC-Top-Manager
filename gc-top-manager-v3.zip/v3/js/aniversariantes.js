/**
 * ANIVERSARIANTES — lista + configuração do aviso para a Fran.
 *
 * O envio em si roda no Google Apps Script (apps-script/aviso-
 * aniversariantes.gs), autenticado com uma conta de serviço própria
 * (papel "automacao") — nunca com as credenciais de Bruno ou Fran.
 * O botão "Enviar e-mail de teste" apenas grava um pedido em
 * /filaTeste; o Apps Script (rodando periodicamente) o processa e
 * registra o resultado em /avisosEnviados, que aparece aqui como
 * histórico.
 */

const Aniversariantes = (() => {
  let aba = "proximos";

  function render(screen, state, session) {
    const todos = state.pessoas
      .filter((p) => !p.arquivadoEm)
      .map((p) => ({ ...p, dias: Utils.daysUntilNextBirthday(p.nascimento) }))
      .filter((p) => p.dias !== null)
      .sort((a, b) => a.dias - b.dias);

    const lista = aba === "proximos" ? todos.filter((p) => p.dias <= 30) : todos;
    const podeConfigurar = Permissoes.pode(session.papel, "editarConfigAniversario");
    const cfg = state.config.avisoAniversario || {};

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Aniversariantes</h1>
        ${podeConfigurar ? `<button class="icon-btn" id="cfgAvisoBtn">⚙️</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div class="chip-row">
        <button class="chip ${aba === "proximos" ? "active" : ""}" data-a="proximos">Próximos 30 dias</button>
        <button class="chip ${aba === "todos" ? "active" : ""}" data-a="todos">Todos</button>
      </div>
      <div class="card row-list">
        ${
          lista.length
            ? lista
                .map(
                  (p) => `<div class="row-item" style="cursor:default;">
                <div class="avatar">${Utils.astronautIcon()}</div>
                <div class="row-main">
                  <div class="name">${Utils.escapeHtml(p.nomeCompleto)}</div>
                  <div class="meta">${Utils.formatBirthdayShort(p.nascimento)} · Em ${p.dias} ${p.dias === 1 ? "dia" : "dias"}</div>
                </div>
              </div>`
                )
                .join("")
            : `<div class="empty-state"><div class="glyph">🎂</div><p>Nenhum aniversário cadastrado nesse período.</p></div>`
        }
      </div>
    `;

    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("mais"));
    screen.querySelector(".chip-row").addEventListener("click", (e) => {
      const btn = e.target.closest(".chip");
      if (!btn) return;
      aba = btn.dataset.a;
      render(screen, state, session);
    });
    if (podeConfigurar) document.getElementById("cfgAvisoBtn").addEventListener("click", () => openConfig(cfg, state));
  }

  function openConfig(cfg, state) {
    const antecedencia = cfg.antecedencia || { 7: true, 3: true, 1: true, 0: true };
    Utils.openModal(`
      <div class="modal-title">Aviso de aniversários para a Fran</div>
      <div class="field"><label>E-mail destinatário</label><input id="cEmail" value="${cfg.email ? Utils.escapeHtml(cfg.email) : ""}" /></div>
      <div class="field"><label>WhatsApp (só arquitetura — envio futuro via API oficial)</label><input id="cWhats" value="${cfg.whatsapp ? Utils.escapeHtml(cfg.whatsapp) : ""}" /></div>
      <div class="field">
        <label>Horário do envio diário</label>
        <input type="time" id="cHorario" value="${cfg.horario || "07:00"}" />
        <div class="text-dim" style="font-size:11px;margin-top:4px;line-height:1.4;">
          O Apps Script precisa estar com o gatilho rodando a cada 15 minutos — ele só
          envia quando o horário atual cair dentro dos 15 min a partir daqui. Ver LEIA-ME.md.
        </div>
      </div>
      <div class="field"><label>Fuso horário</label><input value="America/Sao_Paulo" disabled /></div>
      <div class="field">
        <label>Avisar com quantos dias de antecedência</label>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          ${[7, 3, 1, 0]
            .map(
              (d) => `<label style="display:flex;align-items:center;gap:6px;background:var(--bg-elevated);padding:8px 12px;border-radius:10px;border:1px solid var(--border-strong);">
              <input type="checkbox" data-dia="${d}" ${antecedencia[d] ? "checked" : ""} /> ${d === 0 ? "No dia" : `${d} dia${d > 1 ? "s" : ""} antes`}
            </label>`
            )
            .join("")}
        </div>
      </div>
      <button class="btn btn-primary btn-block" id="salvarCfgBtn">Salvar</button>
      <button class="btn btn-secondary btn-block" id="testeBtn" style="margin-top:10px;">Enviar e-mail de teste</button>
      <div id="testeStatus" class="text-dim" style="font-size:12px;margin-top:8px;"></div>

      <div class="divider"></div>
      <div style="font-weight:700;margin-bottom:8px;">Histórico de avisos</div>
      <div class="row-list" style="max-height:220px;overflow-y:auto;">
        ${
          (state.avisosEnviados || []).length
            ? state.avisosEnviados
                .slice()
                .sort((a, b) => (a.enviadoEm < b.enviadoEm ? 1 : -1))
                .slice(0, 20)
                .map((a) => {
                  const pessoa = state.pessoas.find((p) => p.id === a.pessoaId);
                  const corBadge = { sucesso: "badge-green", erro: "badge-muted", incerto: "badge-gold", enviando: "badge-blue", reservado: "badge-blue" }[a.status] || "badge-muted";
                  return `<div class="row-item" style="cursor:default;padding:8px 4px;">
                  <div class="row-main">
                    <div class="name" style="font-size:13px;">${Utils.escapeHtml(pessoa?.nomeCompleto || a.pessoaId || "")}</div>
                    <div class="meta">${a.enviadoEm || a.reservadoEm ? Utils.escapeHtml(a.enviadoEm || a.reservadoEm) : ""} · <span class="badge ${corBadge}">${Utils.escapeHtml(a.status || "")}</span>${a.status === "incerto" ? " · revisar manualmente" : ""}</div>
                  </div>
                </div>`;
                })
                .join("")
            : `<div class="text-dim" style="font-size:12.5px;">Nenhum envio registrado ainda.</div>`
        }
      </div>
    `);

    document.getElementById("salvarCfgBtn").addEventListener("click", async () => {
      const novaAntecedencia = {};
      document.querySelectorAll("[data-dia]").forEach((el) => (novaAntecedencia[el.dataset.dia] = el.checked));
      const obj = {
        email: document.getElementById("cEmail").value.trim(),
        whatsapp: document.getElementById("cWhats").value.trim(),
        horario: document.getElementById("cHorario").value,
        fuso: CONFIG.FUSO_HORARIO,
        antecedencia: novaAntecedencia,
      };
      try {
        await Api.set("config", "avisoAniversario", obj);
        Utils.toast("Configuração salva!");
        Utils.closeModal();
        App.reloadData();
      } catch (e) {
        Utils.toast("Sem permissão para configurar.", "error");
      }
    });

    document.getElementById("testeBtn").addEventListener("click", async () => {
      const status = document.getElementById("testeStatus");
      try {
        await Api.push("filaTeste", { solicitadoEm: new Date().toISOString(), destinatario: document.getElementById("cEmail").value.trim() });
        status.textContent = "Pedido registrado. O envio depende do Apps Script estar com um gatilho ativo (veja LEIA-ME.md) — pode levar alguns minutos.";
      } catch (e) {
        status.textContent = "Não foi possível registrar o pedido de teste.";
      }
    });
  }

  return { render };
})();
