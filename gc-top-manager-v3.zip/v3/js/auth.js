/**
 * AUTH — autenticação real via Firebase Authentication.
 *
 * Não existe mais nenhuma senha, hash ou lista de usuários no código.
 * As contas de Bruno e Fran são criadas no Firebase Authentication
 * (console ou script em scripts/criar-usuarios.js) — este arquivo só
 * fala com o Firebase, nunca guarda credenciais.
 *
 * O PAPEL (admin/liderança) nunca vem do sessionStorage nem de nada
 * que o navegador possa inventar: ele é lido de
 * `/gcTopManager/usuarios/{uid}/papel` no Realtime Database, um
 * caminho que as regras do banco (rules/database.rules.json) só
 * permitem a própria pessoa LER — e ninguém, nem ela mesma, pode
 * ESCREVER (só é editável via console do Firebase ou pelo Admin SDK).
 * Isso é o que impede alguém de "virar admin" alterando algo no
 * próprio navegador.
 */

const Auth = (() => {
  let currentUser = null;
  let currentPapel = null;
  let listeners = [];
  let tentativasFalhas = 0;
  let bloqueadoAte = 0;

  const ERROS_AMIGAVEIS = {
    "auth/invalid-email": "E-mail inválido.",
    "auth/user-disabled": "Esta conta foi desativada.",
    "auth/user-not-found": "E-mail ou senha incorretos.",
    "auth/wrong-password": "E-mail ou senha incorretos.",
    "auth/invalid-credential": "E-mail ou senha incorretos.",
    "auth/invalid-login-credentials": "E-mail ou senha incorretos.",
    "auth/too-many-requests": "Muitas tentativas. Aguarde alguns minutos e tente novamente.",
    "auth/network-request-failed": "Falha de conexão. Verifique a internet e tente novamente.",
    "auth/missing-password": "Informe a senha.",
  };

  function mensagemErro(codigo) {
    return ERROS_AMIGAVEIS[codigo] || "Não foi possível entrar. Tente novamente em instantes.";
  }

  async function buscarPapel(uid) {
    try {
      const snap = await DB.ref(`${CONFIG.ROOT_PATH}/usuarios/${uid}/papel`).once("value");
      return snap.val() || null;
    } catch (e) {
      // Se as regras negarem a leitura (ex.: papel não cadastrado ainda
      // para este uid), tratamos como "sem papel" em vez de travar o app.
      return null;
    }
  }

  function init(onChange) {
    AUTH.onAuthStateChanged(async (user) => {
      currentUser = user;
      currentPapel = user ? await buscarPapel(user.uid) : null;
      onChange(currentSession());
    });
  }

  function currentSession() {
    if (!currentUser) return null;
    if (!currentPapel) {
      // Autenticado no Firebase, mas sem papel configurado em
      // /usuarios/{uid}/papel — precisa de um administrador (ou
      // acesso ao console) para atribuir o papel. Não presumimos
      // nenhum papel por padrão.
      return { uid: currentUser.uid, email: currentUser.email, nome: currentUser.email, papel: null };
    }
    const nome = (currentUser.displayName || currentUser.email || "").split(/[@\s]/)[0];
    return { uid: currentUser.uid, email: currentUser.email, nome: capitalize(nome), papel: currentPapel };
  }

  function capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
  }

  async function login(email, senha) {
    if (Date.now() < bloqueadoAte) {
      const segundos = Math.ceil((bloqueadoAte - Date.now()) / 1000);
      return { ok: false, error: `Muitas tentativas seguidas. Tente novamente em ${segundos}s.` };
    }
    try {
      await AUTH.signInWithEmailAndPassword(email.trim(), senha);
      tentativasFalhas = 0;
      return { ok: true };
    } catch (e) {
      tentativasFalhas++;
      // Proteção extra no cliente (a proteção real contra força bruta
      // é do próprio Firebase Authentication, que já bloqueia a conta
      // no servidor após várias tentativas com auth/too-many-requests).
      if (tentativasFalhas >= 5) {
        bloqueadoAte = Date.now() + 60_000;
        tentativasFalhas = 0;
        return { ok: false, error: "Muitas tentativas seguidas. Tente novamente em 60s." };
      }
      return { ok: false, error: mensagemErro(e.code) };
    }
  }

  async function logout() {
    await AUTH.signOut();
  }

  async function resetPassword(email) {
    try {
      await AUTH.sendPasswordResetEmail(email.trim());
      return { ok: true };
    } catch (e) {
      return { ok: false, error: mensagemErro(e.code) };
    }
  }

  function pode(acao) {
    const s = currentSession();
    return Permissoes.pode(s && s.papel, acao);
  }

  return { init, currentSession, login, logout, resetPassword, pode };
})();
