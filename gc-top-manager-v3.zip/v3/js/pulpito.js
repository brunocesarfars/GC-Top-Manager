/**
 * PÚLPITO — biblioteca de mensagens/estudos/devocionais, mapa bíblico
 * e temas mais utilizados. Só administrador edita (verPulpito true
 * para liderança, editarPulpito só para admin).
 */

const Pulpito = (() => {
  const LIVROS = [
    "Gênesis","Êxodo","Levítico","Números","Deuteronômio","Josué","Juízes","Rute",
    "1 Samuel","2 Samuel","1 Reis","2 Reis","1 Crônicas","2 Crônicas","Esdras","Neemias",
    "Ester","Jó","Salmos","Provérbios","Eclesiastes","Cantares","Isaías","Jeremias",
    "Lamentações","Ezequiel","Daniel","Oséias","Joel","Amós","Obadias","Jonas","Miquéias",
    "Naum","Habacuque","Sofonias","Ageu","Zacarias","Malaquias",
    "Mateus","Marcos","Lucas","João","Atos","Romanos","1 Coríntios","2 Coríntios",
    "Gálatas","Efésios","Filipenses","Colossenses","1 Tessalonicenses","2 Tessalonicenses",
    "1 Timóteo","2 Timóteo","Tito","Filemom","Hebreus","Tiago","1 Pedro","2 Pedro",
    "1 João","2 João","3 João","Judas","Apocalipse",
  ];

  const ABREVIACOES = {
    gn: "Gênesis", ex: "Êxodo", lv: "Levítico", nm: "Números", dt: "Deuteronômio",
    js: "Josué", jz: "Juízes", rt: "Rute", "1sm": "1 Samuel", "2sm": "2 Samuel",
    "1rs": "1 Reis", "2rs": "2 Reis", "1cr": "1 Crônicas", "2cr": "2 Crônicas",
    ed: "Esdras", ne: "Neemias", et: "Ester", job: "Jó", sl: "Salmos", sal: "Salmos",
    pv: "Provérbios", ec: "Eclesiastes", ct: "Cantares", is: "Isaías", jr: "Jeremias",
    lm: "Lamentações", ez: "Ezequiel", dn: "Daniel", os: "Oséias", jl: "Joel",
    am: "Amós", ob: "Obadias", jn: "Jonas", mq: "Miquéias", na: "Naum", hc: "Habacuque",
    sf: "Sofonias", ag: "Ageu", zc: "Zacarias", ml: "Malaquias",
    mt: "Mateus", mc: "Marcos", lc: "Lucas", jo: "João", at: "Atos", rm: "Romanos",
    "1co": "1 Coríntios", "2co": "2 Coríntios", gl: "Gálatas", ef: "Efésios",
    fp: "Filipenses", cl: "Colossenses", "1ts": "1 Tessalonicenses", "2ts": "2 Tessalonicenses",
    "1tm": "1 Timóteo", "2tm": "2 Timóteo", tt: "Tito", fm: "Filemom", hb: "Hebreus",
    tg: "Tiago", "1pe": "1 Pedro", "2pe": "2 Pedro", "1jo": "1 João", "2jo": "2 João",
    "3jo": "3 João", jd: "Judas", ap: "Apocalipse",
  };

  const LOCAIS_USO = ["GC Top do Universo", "Grupo de homens", "We Care", "Culto", "Devocional", "Outro"];

  let filtroTag = "todos";
  let termoBusca = "";
  let contarTextosApoio = false;

  function normalizarRef(txt) {
    return (txt || "").toLowerCase().replace(/\./g, "").replace(/\s+/g, " ").trim();
  }

  function bookOf(passagem) {
    if (!passagem) return null;
    const norm = normalizarRef(passagem);
    const semNumeros = norm.replace(/[\d:.,\-–\s]+$/, "").trim();
    // 1) tenta abreviação exata (ex.: "jo", "1jo", "fp")
    const chaveAbrev = semNumeros.replace(/\s+/g, "");
    if (ABREVIACOES[chaveAbrev]) return ABREVIACOES[chaveAbrev];
    // 2) tenta nome completo por prefixo
    const found = LIVROS.find((l) => normalizarRef(l).startsWith(semNumeros) || semNumeros.startsWith(normalizarRef(l)));
    return found || null;
  }

  function extrairLivros(mensagem, incluirApoio) {
    const livros = new Set();
    const principal = bookOf(mensagem.passagemPrincipal);
    if (principal) livros.add(principal);
    if (incluirApoio && mensagem.textosApoio) {
      mensagem.textosApoio
        .split(/[;,]/)
        .map((t) => bookOf(t))
        .filter(Boolean)
        .forEach((l) => livros.add(l));
    }
    return Array.from(livros);
  }

  function todasTags(state) {
    const set = new Set();
    state.mensagens.forEach((m) => (m.tags || []).forEach((t) => set.add(t)));
    return Array.from(set).sort();
  }

  // ---------- Biblioteca ----------
  function render(screen, state, session) {
    let lista = state.mensagens.filter((m) => !m.arquivadoEm);
    if (filtroTag !== "todos") {
      lista = lista.filter((m) => (m.ondeMinistrada || []).some((o) => o.local === filtroTag) || (m.tags || []).includes(filtroTag));
    }
    if (termoBusca) {
      const t = termoBusca.toLowerCase();
      lista = lista.filter((m) =>
        [m.titulo, m.passagemPrincipal, m.tema, m.ideiaCentral, ...(m.tags || [])].filter(Boolean).join(" ").toLowerCase().includes(t)
      );
    }

    const podeEditar = Permissoes.pode(session.papel, "editarPulpito");

    screen.innerHTML = `
      <div class="topbar">
        <h1>Púlpito</h1>
        ${podeEditar ? `<button class="icon-btn" id="addMsgBtn">+</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div class="search-box"><span>${Utils.iconSearch()}</span><input id="msgSearch" placeholder="Buscar mensagens, textos, temas ou tags…" value="${Utils.escapeHtml(termoBusca)}" /></div>
      <div class="chip-row" id="tagChips">
        <button class="chip ${filtroTag === "todos" ? "active" : ""}" data-t="todos">Todos</button>
        ${LOCAIS_USO.map((l) => `<button class="chip ${filtroTag === l ? "active" : ""}" data-t="${Utils.escapeHtml(l)}">${Utils.escapeHtml(l)}</button>`).join("")}
        ${todasTags(state)
          .map((t) => `<button class="chip ${filtroTag === t ? "active" : ""}" data-t="${Utils.escapeHtml(t)}">#${Utils.escapeHtml(t)}</button>`)
          .join("")}
      </div>
      <div class="section-title" style="margin-top:4px;">
        <a href="#/mapa-biblico">📖 Mapa bíblico</a>
        <a href="#" id="temasLink">🏷️ Temas mais usados</a>
      </div>
      <div class="card" style="padding:0;">
        ${
          lista.length
            ? lista
                .map(
                  (m) => `<button class="row-item msg-card" style="width:100%;" data-nav="pulpito/${m.id}">
                <div class="msg-thumb">📖</div>
                <div class="row-main">
                  <div class="msg-title">${Utils.escapeHtml(m.titulo)}</div>
                  <div class="msg-ref">${Utils.escapeHtml(m.passagemPrincipal || "")}</div>
                  <div class="msg-meta">${(m.ondeMinistrada || []).map((o) => o.local).join(", ") || "—"} · ${m.data ? Utils.parseDateBR(m.data) : ""}</div>
                </div>
              </button>`
                )
                .join("")
            : `<div class="empty-state"><div class="glyph">📖</div><p>Nenhuma mensagem encontrada.</p></div>`
        }
      </div>
    `;

    screen.querySelectorAll("[data-nav]").forEach((el) => el.addEventListener("click", () => App.navigate(el.dataset.nav)));
    if (podeEditar) document.getElementById("addMsgBtn").addEventListener("click", () => openForm(null, state, session));
    document.getElementById("msgSearch").addEventListener("input", (e) => {
      termoBusca = e.target.value;
      render(screen, state, session);
    });
    document.getElementById("tagChips").addEventListener("click", (e) => {
      const btn = e.target.closest(".chip");
      if (!btn) return;
      filtroTag = btn.dataset.t;
      render(screen, state, session);
    });
    document.getElementById("temasLink").addEventListener("click", (e) => {
      e.preventDefault();
      openTemas(state);
    });
  }

  function openTemas(state) {
    const contagem = {};
    state.mensagens
      .filter((m) => !m.arquivadoEm)
      .forEach((m) => {
        if (!m.tema) return;
        contagem[m.tema] = (contagem[m.tema] || 0) + 1;
      });
    const ordenado = Object.entries(contagem).sort((a, b) => b[1] - a[1]);
    Utils.openModal(`
      <div class="modal-title">Temas mais utilizados</div>
      <div class="row-list">
        ${
          ordenado.length
            ? ordenado.map(([tema, n]) => `<div class="row-item" style="cursor:default;"><div class="row-main"><div class="name">${Utils.escapeHtml(tema)}</div></div><span class="badge badge-gold">${n}</span></div>`).join("")
            : `<div class="empty-state" style="padding:16px;">Cadastre temas nas mensagens para ver esta análise.</div>`
        }
      </div>
    `);
  }

  // ---------- Mapa bíblico ----------
  function renderMapa(screen, state) {
    function calcularContagem() {
      const contagem = {};
      LIVROS.forEach((l) => (contagem[l] = 0));
      state.mensagens
        .filter((m) => !m.arquivadoEm)
        .forEach((m) => {
          extrairLivros(m, contarTextosApoio).forEach((l) => (contagem[l] = (contagem[l] || 0) + 1));
        });
      return contagem;
    }

    function desenhar() {
      const contagem = calcularContagem();
      screen.innerHTML = `
        <div class="topbar">
          <button class="icon-btn" id="voltarBtn">←</button>
          <h1>Mapa bíblico</h1>
          <div style="width:38px;"></div>
        </div>
        <div class="text-dim" style="font-size:12.5px;margin-bottom:10px;">Quantas mensagens já utilizaram cada livro — para perceber o que tem sido pouco explorado.</div>
        <label style="display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--text-dim);margin-bottom:14px;">
          <input type="checkbox" id="toggleApoio" ${contarTextosApoio ? "checked" : ""} /> Contar também os textos de apoio
        </label>
        <div class="card row-list" id="mapaList">
          ${LIVROS.map(
            (l) => `<button class="row-item" style="width:100%;" data-livro="${Utils.escapeHtml(l)}">
              <div class="row-main"><div class="name">${l}</div></div>
              <span class="badge ${contagem[l] > 0 ? "badge-gold" : "badge-muted"}">${contagem[l]}</span>
            </button>`
          ).join("")}
        </div>
      `;
      document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("pulpito"));
      document.getElementById("toggleApoio").addEventListener("change", (e) => {
        contarTextosApoio = e.target.checked;
        desenhar();
      });
      screen.querySelectorAll("[data-livro]").forEach((el) =>
        el.addEventListener("click", () => {
          const livro = el.dataset.livro;
          const relacionadas = state.mensagens.filter((m) => !m.arquivadoEm && extrairLivros(m, contarTextosApoio).includes(livro));
          const card = Utils.openModal(`
            <div class="modal-title">${Utils.escapeHtml(livro)} (${relacionadas.length})</div>
            <div class="row-list">
              ${
                relacionadas.length
                  ? relacionadas.map((m) => `<button class="row-item" style="width:100%;" data-nav="pulpito/${m.id}"><div class="row-main"><div class="name">${Utils.escapeHtml(m.titulo)}</div><div class="meta">${Utils.escapeHtml(m.passagemPrincipal || "")}</div></div><span class="chev">›</span></button>`).join("")
                  : `<div class="empty-state" style="padding:16px;">Nenhuma mensagem ainda com este livro.</div>`
              }
            </div>
          `);
          card.querySelectorAll("[data-nav]").forEach((b) =>
            b.addEventListener("click", () => {
              Utils.closeModal();
              App.navigate(b.dataset.nav);
            })
          );
        })
      );
    }
    desenhar();
  }

  // ---------- Detalhe da mensagem ----------
  function renderDetail(screen, state, id, session) {
    const m = state.mensagens.find((x) => x.id === id);
    if (!m) {
      screen.innerHTML = `<div class="empty-state">Mensagem não encontrada.</div>`;
      return;
    }
    const tempos = m.temposEstimados || [];
    const totalMin = tempos.reduce((acc, t) => acc + (Number(t.minutos) || 0), 0);
    const podeEditar = Permissoes.pode(session.papel, "editarPulpito");

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        ${podeEditar ? `<button class="icon-btn" id="duplicarMsgBtn">⧉</button>` : `<div style="width:38px;"></div>`}
        ${podeEditar ? `<button class="icon-btn" id="editMsgBtn">✎</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div style="margin-bottom:6px;">
        <div style="font-size:20px;font-weight:700;">${Utils.escapeHtml(m.titulo)}</div>
        <div style="color:var(--gold-text);font-size:13.5px;margin-top:3px;">${Utils.escapeHtml(m.passagemPrincipal || "")}</div>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin:10px 0 16px;">
        ${m.tema ? `<span class="badge badge-gold">${Utils.escapeHtml(m.tema)}</span>` : ""}
        ${m.publico ? `<span class="badge badge-blue">${Utils.escapeHtml(m.publico)}</span>` : ""}
        ${(m.ondeMinistrada || []).map((o) => `<span class="badge badge-teal">${Utils.escapeHtml(o.local)}</span>`).join("")}
        ${(m.tags || []).map((t) => `<span class="badge badge-muted">#${Utils.escapeHtml(t)}</span>`).join("")}
      </div>

      ${
        (m.ondeMinistrada || []).length > 1
          ? `<div class="card" style="margin-bottom:14px;">Já foi ministrada <strong>${m.ondeMinistrada.length} vezes</strong>: ${m.ondeMinistrada.map((o) => `${Utils.escapeHtml(o.local)}${o.data ? " (" + Utils.parseDateBR(o.data) + ")" : ""}`).join(", ")}</div>`
          : ""
      }

      ${section("Textos de apoio", m.textosApoio)}
      ${section("Contexto", m.contexto)}
      ${section("Exegese", m.exegese)}
      ${section("Ideia central", m.ideiaCentral)}
      ${section("Estrutura", m.estrutura)}
      ${section("Introdução", m.introducao)}
      ${section("Desenvolvimento", m.desenvolvimento)}
      ${section("Conclusão", m.conclusao)}
      ${section("Aplicações", m.aplicacoes)}
      ${section("Observações", m.observacoes)}

      ${
        tempos.length
          ? `<div class="section-title"><h2>Tempo estimado</h2></div>
             <div class="card">
               ${tempos.map((t) => `<div class="flex-between" style="padding:6px 0;border-bottom:1px solid var(--border);"><span>${Utils.escapeHtml(t.parte)}</span><span class="text-dim">${Utils.escapeHtml(String(t.minutos))} min</span></div>`).join("")}
               <div class="flex-between" style="padding-top:10px;font-weight:700;"><span>Total estimado</span><span style="color:var(--gold-text);">${totalMin} minutos</span></div>
             </div>`
          : ""
      }

      <button class="btn btn-secondary btn-block" id="exportarBtn" style="margin-top:16px;">Exportar / Imprimir</button>
    `;

    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("pulpito"));
    document.getElementById("exportarBtn").addEventListener("click", () => exportarParaImpressao(m));
    if (podeEditar) {
      document.getElementById("editMsgBtn").addEventListener("click", () => openForm(m, state, session));
      document.getElementById("duplicarMsgBtn").addEventListener("click", async () => {
        const copia = { ...m, titulo: `${m.titulo} (cópia)`, data: Utils.todayISO(), ondeMinistrada: [] };
        delete copia.id;
        const novoId = await Api.push("mensagens", copia);
        Utils.toast("Mensagem duplicada!");
        App.navigate(`pulpito/${novoId}`);
        App.reloadData();
      });
    }
  }

  function exportarParaImpressao(m) {
    const win = window.open("", "_blank");
    if (!win) return Utils.toast("Permita pop-ups para exportar.", "error");
    const partes = [
      ["Passagem principal", m.passagemPrincipal],
      ["Textos de apoio", m.textosApoio],
      ["Contexto", m.contexto],
      ["Exegese", m.exegese],
      ["Ideia central", m.ideiaCentral],
      ["Estrutura", m.estrutura],
      ["Introdução", m.introducao],
      ["Desenvolvimento", m.desenvolvimento],
      ["Conclusão", m.conclusao],
      ["Aplicações", m.aplicacoes],
      ["Observações", m.observacoes],
    ].filter(([, v]) => v);
    const doc = win.document;
    doc.title = m.titulo;
    const h1 = doc.createElement("h1");
    h1.textContent = m.titulo;
    doc.body.appendChild(h1);
    partes.forEach(([titulo, conteudo]) => {
      const h2 = doc.createElement("h3");
      h2.textContent = titulo;
      const p = doc.createElement("p");
      p.style.whiteSpace = "pre-wrap";
      p.textContent = conteudo;
      doc.body.appendChild(h2);
      doc.body.appendChild(p);
    });
    win.print();
  }

  function section(title, content) {
    if (!content) return "";
    return `<div class="section-title"><h2>${title}</h2></div><div class="card" style="white-space:pre-wrap;font-size:13.5px;line-height:1.55;">${Utils.escapeHtml(content)}</div>`;
  }

  // ---------- Rascunho local (autosave) ----------
  function chaveRascunho(msgId) {
    return `gcTopManager.rascunhoMensagem.${msgId || "nova"}`;
  }

  function lerCamposForm() {
    const campos = ["mTitulo","mPassagem","mTextosApoio","mTema","mOcasiao","mPublico","mData","mLocal","mTags","mContexto","mExegese","mIdeia","mEstrutura","mIntroducao","mDesenvolvimento","mConclusao","mAplicacoes","mObservacoes"];
    const obj = {};
    campos.forEach((c) => {
      const el = document.getElementById(c);
      if (el) obj[c] = el.value;
    });
    return obj;
  }

  function aplicarCamposForm(obj) {
    Object.entries(obj).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el) el.value = val;
    });
  }

  // ---------- Formulário ----------
  function openForm(msg, state, session) {
    const isEdit = !!msg;
    const ondeMinistrada = msg ? [...(msg.ondeMinistrada || [])] : [];
    const tempos = msg
      ? [...(msg.temposEstimados || [])]
      : [
          { parte: "Introdução", minutos: 3 },
          { parte: "Ponto 1", minutos: 6 },
          { parte: "Conclusão", minutos: 3 },
        ];

    const chave = chaveRascunho(msg ? msg.id : null);
    let rascunhoSalvo = null;
    try {
      const bruto = localStorage.getItem(chave);
      if (bruto) rascunhoSalvo = JSON.parse(bruto);
    } catch {
      rascunhoSalvo = null;
    }

    const modal = Utils.openModal(`
      <div class="modal-title">${isEdit ? "Editar mensagem" : "Nova mensagem"}</div>
      ${rascunhoSalvo ? `<div class="card" style="border-color:var(--gold);margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
        <span style="font-size:12.5px;">Encontramos um rascunho não salvo desta mensagem.</span>
        <button type="button" class="btn btn-secondary" id="restaurarRascunhoBtn" style="padding:8px 12px;font-size:12px;white-space:nowrap;">Restaurar</button>
      </div>` : ""}
      <div class="field"><label>Título</label><input id="mTitulo" value="${msg ? Utils.escapeHtml(msg.titulo) : ""}" /></div>
      <div class="field"><label>Passagem principal</label><input id="mPassagem" value="${msg ? Utils.escapeHtml(msg.passagemPrincipal || "") : ""}" /></div>
      <div class="field"><label>Textos de apoio (separe por vírgula)</label><input id="mTextosApoio" value="${msg ? Utils.escapeHtml(msg.textosApoio || "") : ""}" /></div>
      <div class="field-row">
        <div class="field"><label>Tema</label><input id="mTema" value="${msg ? Utils.escapeHtml(msg.tema || "") : ""}" /></div>
        <div class="field"><label>Ocasião</label><input id="mOcasiao" value="${msg ? Utils.escapeHtml(msg.ocasiao || "") : ""}" /></div>
      </div>
      <div class="field-row">
        <div class="field"><label>Público</label><input id="mPublico" value="${msg ? Utils.escapeHtml(msg.publico || "") : ""}" /></div>
        <div class="field"><label>Data</label><input type="date" id="mData" value="${msg ? msg.data || "" : ""}" /></div>
      </div>
      <div class="field"><label>Local</label><input id="mLocal" value="${msg ? Utils.escapeHtml(msg.local || "") : ""}" /></div>
      <div class="field"><label>Tags (separadas por vírgula)</label><input id="mTags" value="${msg ? Utils.escapeHtml((msg.tags || []).join(", ")) : ""}" /></div>

      <div class="field"><label>Onde foi ministrada (pode adicionar várias)</label>
        <div id="ondeList"></div>
        <button type="button" class="btn btn-secondary" id="addOndeBtn" style="margin-top:6px;">+ Adicionar local</button>
      </div>

      <div class="divider"></div>
      <div class="field"><label>Contexto</label><textarea id="mContexto">${msg ? Utils.escapeHtml(msg.contexto || "") : ""}</textarea></div>
      <div class="field"><label>Exegese</label><textarea id="mExegese">${msg ? Utils.escapeHtml(msg.exegese || "") : ""}</textarea></div>
      <div class="field"><label>Ideia central</label><textarea id="mIdeia">${msg ? Utils.escapeHtml(msg.ideiaCentral || "") : ""}</textarea></div>
      <div class="field"><label>Estrutura</label><textarea id="mEstrutura">${msg ? Utils.escapeHtml(msg.estrutura || "") : ""}</textarea></div>
      <div class="field"><label>Introdução</label><textarea id="mIntroducao">${msg ? Utils.escapeHtml(msg.introducao || "") : ""}</textarea></div>
      <div class="field"><label>Desenvolvimento</label><textarea id="mDesenvolvimento">${msg ? Utils.escapeHtml(msg.desenvolvimento || "") : ""}</textarea></div>
      <div class="field"><label>Conclusão</label><textarea id="mConclusao">${msg ? Utils.escapeHtml(msg.conclusao || "") : ""}</textarea></div>
      <div class="field"><label>Aplicações</label><textarea id="mAplicacoes">${msg ? Utils.escapeHtml(msg.aplicacoes || "") : ""}</textarea></div>
      <div class="field"><label>Observações</label><textarea id="mObservacoes">${msg ? Utils.escapeHtml(msg.observacoes || "") : ""}</textarea></div>

      <div class="field"><label>Tempo estimado por parte</label>
        <div id="temposList"></div>
        <button type="button" class="btn btn-secondary" id="addTempoBtn" style="margin-top:6px;">+ Adicionar parte</button>
      </div>

      <div id="rascunhoAviso" class="text-dim" style="font-size:11.5px;margin-top:10px;"></div>
      <button class="btn btn-primary btn-block" id="salvarMsgBtn" style="margin-top:10px;">Salvar</button>
      ${isEdit ? `<button class="btn btn-danger btn-block" style="margin-top:10px;" id="arquivarMsgBtn">Arquivar</button>` : ""}
    `);

    const ondeListEl = document.getElementById("ondeList");
    const temposListEl = document.getElementById("temposList");

    function renderOndeList() {
      ondeListEl.innerHTML = ondeMinistrada
        .map(
          (o, i) => `<div class="field-row" style="margin-top:8px;align-items:center;">
          <select data-onde-local="${i}" style="flex:1;background:var(--bg-elevated);border:1px solid var(--border-strong);border-radius:10px;color:var(--text);padding:10px;">
            ${LOCAIS_USO.map((l) => `<option ${o.local === l ? "selected" : ""}>${Utils.escapeHtml(l)}</option>`).join("")}
          </select>
          <input type="date" data-onde-data="${i}" value="${o.data || ""}" style="flex:1;background:var(--bg-elevated);border:1px solid var(--border-strong);border-radius:10px;color:var(--text);padding:10px;" />
          <button type="button" data-onde-del="${i}" class="icon-btn" style="width:36px;height:36px;">✕</button>
        </div>`
        )
        .join("");
      ondeListEl.querySelectorAll("[data-onde-local]").forEach((el) => el.addEventListener("change", (e) => (ondeMinistrada[+el.dataset.ondeLocal].local = e.target.value)));
      ondeListEl.querySelectorAll("[data-onde-data]").forEach((el) => el.addEventListener("change", (e) => (ondeMinistrada[+el.dataset.ondeData].data = e.target.value)));
      ondeListEl.querySelectorAll("[data-onde-del]").forEach((el) =>
        el.addEventListener("click", () => {
          ondeMinistrada.splice(+el.dataset.ondeDel, 1);
          renderOndeList();
        })
      );
    }

    function renderTemposList() {
      temposListEl.innerHTML = tempos
        .map(
          (t, i) => `<div class="field-row" style="margin-top:8px;">
          <input data-tempo-parte="${i}" value="${Utils.escapeHtml(t.parte)}" placeholder="Parte" style="flex:2;background:var(--bg-elevated);border:1px solid var(--border-strong);border-radius:10px;color:var(--text);padding:10px;" />
          <input data-tempo-min="${i}" type="number" value="${Utils.escapeHtml(String(t.minutos))}" placeholder="min" style="flex:1;background:var(--bg-elevated);border:1px solid var(--border-strong);border-radius:10px;color:var(--text);padding:10px;" />
          <button type="button" data-tempo-del="${i}" class="icon-btn" style="width:36px;height:36px;">✕</button>
        </div>`
        )
        .join("");
      temposListEl.querySelectorAll("[data-tempo-parte]").forEach((el) => el.addEventListener("input", (e) => (tempos[+el.dataset.tempoParte].parte = e.target.value)));
      temposListEl.querySelectorAll("[data-tempo-min]").forEach((el) => el.addEventListener("input", (e) => (tempos[+el.dataset.tempoMin].minutos = e.target.value)));
      temposListEl.querySelectorAll("[data-tempo-del]").forEach((el) =>
        el.addEventListener("click", () => {
          tempos.splice(+el.dataset.tempoDel, 1);
          renderTemposList();
        })
      );
    }

    renderOndeList();
    renderTemposList();

    if (rascunhoSalvo) {
      document.getElementById("restaurarRascunhoBtn").addEventListener("click", () => {
        aplicarCamposForm(rascunhoSalvo);
        Utils.toast("Rascunho restaurado.");
      });
    }

    // autosave — salva a cada alteração, silenciosamente
    let avisoTimeout;
    modal.addEventListener("input", () => {
      try {
        localStorage.setItem(chave, JSON.stringify(lerCamposForm()));
        const aviso = document.getElementById("rascunhoAviso");
        if (aviso) {
          aviso.textContent = "Rascunho salvo automaticamente neste dispositivo.";
          clearTimeout(avisoTimeout);
          avisoTimeout = setTimeout(() => (aviso.textContent = ""), 2500);
        }
      } catch {
        /* localStorage indisponível — segue sem autosave */
      }
    });

    function limparRascunho() {
      try {
        localStorage.removeItem(chave);
      } catch {}
    }

    document.getElementById("addOndeBtn").addEventListener("click", () => {
      ondeMinistrada.push({ local: LOCAIS_USO[0], data: "" });
      renderOndeList();
    });
    document.getElementById("addTempoBtn").addEventListener("click", () => {
      tempos.push({ parte: "", minutos: 5 });
      renderTemposList();
    });

    document.getElementById("salvarMsgBtn").addEventListener("click", async () => {
      const titulo = document.getElementById("mTitulo").value.trim();
      if (!titulo) return Utils.toast("Informe o título.", "error");
      const tags = document
        .getElementById("mTags")
        .value.split(",")
        .map((t) => t.trim())
        .filter(Boolean);
      const obj = {
        titulo,
        passagemPrincipal: document.getElementById("mPassagem").value.trim(),
        textosApoio: document.getElementById("mTextosApoio").value.trim(),
        tema: document.getElementById("mTema").value.trim(),
        ocasiao: document.getElementById("mOcasiao").value.trim(),
        publico: document.getElementById("mPublico").value.trim(),
        data: document.getElementById("mData").value,
        local: document.getElementById("mLocal").value.trim(),
        tags,
        ondeMinistrada,
        contexto: document.getElementById("mContexto").value.trim(),
        exegese: document.getElementById("mExegese").value.trim(),
        ideiaCentral: document.getElementById("mIdeia").value.trim(),
        estrutura: document.getElementById("mEstrutura").value.trim(),
        introducao: document.getElementById("mIntroducao").value.trim(),
        desenvolvimento: document.getElementById("mDesenvolvimento").value.trim(),
        conclusao: document.getElementById("mConclusao").value.trim(),
        aplicacoes: document.getElementById("mAplicacoes").value.trim(),
        observacoes: document.getElementById("mObservacoes").value.trim(),
        temposEstimados: tempos,
      };
      try {
        if (isEdit) await Api.update("mensagens", msg.id, obj);
        else await Api.push("mensagens", obj);
        limparRascunho();
        Utils.toast("Mensagem salva!");
        Utils.closeModal();
        App.reloadData();
      } catch (e) {
        Utils.toast(e.code === "PERMISSION_DENIED" ? "Sem permissão para esta ação." : "Erro ao salvar.", "error");
      }
    });

    if (isEdit) {
      document.getElementById("arquivarMsgBtn").addEventListener("click", async () => {
        if (!confirm("Arquivar esta mensagem?")) return;
        await Api.update("mensagens", msg.id, { arquivadoEm: Utils.todayISO() });
        limparRascunho();
        Utils.toast("Mensagem arquivada.");
        Utils.closeModal();
        App.navigate("pulpito");
        App.reloadData();
      });
    }
  }

  return { render, renderDetail, renderMapa, LIVROS, LOCAIS_USO, ABREVIACOES, bookOf };
})();
