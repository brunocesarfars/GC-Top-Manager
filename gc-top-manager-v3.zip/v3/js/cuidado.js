/**
 * CUIDADO — três telas: (1) Atenção (calculado, com "contato
 * realizado"), (2) Acompanhamento pastoral (restrito), (3) Pedidos de
 * oração (visível/privado, com histórico de alterações).
 */

const Cuidado = (() => {
  // ---------- 1) Atenção ----------
  function renderAtencao(screen, state, session) {
    const podeResolver = Permissoes.pode(session.papel, "resolverCuidado");
    const contatosPorPessoa = Dashboard.indexarContatos(state.cuidadoContatos);
    const lista = Logica.identificarCuidado(state.pessoas, state.encontros, state.hojeISO, contatosPorPessoa);

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Cuidado e acompanhamento</h1>
        <div style="width:38px;"></div>
      </div>
      <div class="text-dim" style="font-size:12.5px;margin-bottom:14px;line-height:1.5;">
        Pessoas que podem precisar de um contato — não é uma lista de cobrança, é um lembrete de cuidado.
      </div>
      <div class="card row-list" id="listaAtencao">
        ${
          lista.length
            ? lista
                .map((a) => {
                  const pessoa = state.pessoas.find((p) => p.id === a.pessoaId);
                  return `<div class="row-item" style="cursor:default;align-items:flex-start;" data-pessoa="${a.pessoaId}">
                <div class="avatar">${Utils.astronautIcon()}</div>
                <div class="row-main">
                  <button class="name" data-nav="pessoas/${a.pessoaId}" style="background:none;border:none;color:inherit;padding:0;text-align:left;font:inherit;cursor:pointer;">${Utils.escapeHtml(pessoa?.nomeCompleto || "")}</button>
                  <div class="meta">${Utils.escapeHtml(a.motivo)}</div>
                  ${
                    podeResolver
                      ? `<div style="display:flex;gap:8px;margin-top:8px;">
                    <button class="btn btn-secondary" data-resolver="${a.pessoaId}" data-status="adiado" style="padding:7px 12px;font-size:12px;">Adiar 7 dias</button>
                    <button class="btn btn-secondary" data-resolver="${a.pessoaId}" data-status="concluido" style="padding:7px 12px;font-size:12px;">Contato feito</button>
                  </div>`
                      : ""
                  }
                </div>
              </div>`;
                })
                .join("")
            : `<div class="empty-state"><div class="glyph">💛</div><p>Ninguém precisando de atenção especial agora.</p></div>`
        }
      </div>
    `;

    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("mais"));
    screen.querySelectorAll("[data-nav]").forEach((el) => el.addEventListener("click", () => App.navigate(el.dataset.nav)));
    screen.querySelectorAll("[data-resolver]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        const pessoaId = btn.dataset.resolver;
        const status = btn.dataset.status;
        const obj = { pessoaId, status, responsavel: session.nome, data: Utils.todayISO() };
        if (status === "adiado") {
          const dt = new Date(state.hojeISO + "T12:00:00Z");
          dt.setUTCDate(dt.getUTCDate() + 7);
          obj.adiadoAte = dt.toISOString().slice(0, 10);
        }
        try {
          await Api.push("cuidadoContatos", obj);
          Utils.toast(status === "concluido" ? "Marcado como contato feito." : "Adiado por 7 dias.");
          App.reloadData();
        } catch (e) {
          Utils.toast("Sem permissão para esta ação.", "error");
        }
      })
    );
  }

  // ---------- 2) Acompanhamento pastoral (restrito) ----------
  function renderAcompanhamento(screen, state, session) {
    if (!Permissoes.pode(session.papel, "verAcompanhamentoPastoral")) {
      screen.innerHTML = `<div class="empty-state" style="padding-top:60px;"><div class="glyph">🔒</div><p>Área restrita à administração.</p></div>`;
      return;
    }
    const registros = [...state.acompanhamento].filter((r) => !r.arquivadoEm).sort((a, b) => (a.data < b.data ? 1 : -1));
    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Acompanhamento</h1>
        <button class="icon-btn" id="addAcompBtn">+</button>
      </div>
      <div class="card row-list">
        ${
          registros.length
            ? registros
                .map((r) => {
                  const pessoa = state.pessoas.find((p) => p.id === r.pessoaId);
                  const vencido = r.proximoAcompanhamento && r.proximoAcompanhamento < state.hojeISO && r.situacao !== "Concluído";
                  return `<button class="row-item" style="width:100%;" data-editar="${r.id}">
                <div class="avatar">${Utils.astronautIcon()}</div>
                <div class="row-main">
                  <div class="name">${Utils.escapeHtml(pessoa?.nomeCompleto || "Pessoa removida")}</div>
                  <div class="meta">${Utils.escapeHtml(r.assunto || "")}</div>
                  <div class="meta">${Utils.parseDateBR(r.data)} · ${Utils.escapeHtml(r.responsavel || "")} · ${Utils.escapeHtml(r.situacao || "")}</div>
                  ${vencido ? `<span class="badge badge-muted" style="margin-top:4px;">Acompanhamento vencido</span>` : ""}
                </div>
              </button>`;
                })
                .join("")
            : `<div class="empty-state"><div class="glyph">🛡️</div><p>Nenhum registro ainda.</p></div>`
        }
      </div>
    `;
    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("mais"));
    document.getElementById("addAcompBtn").addEventListener("click", () => openAcompForm(state, session, null));
    screen.querySelectorAll("[data-editar]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const r = state.acompanhamento.find((x) => x.id === btn.dataset.editar);
        openAcompForm(state, session, r);
      })
    );
  }

  function openAcompForm(state, session, registro) {
    const isEdit = !!registro;
    Utils.openModal(`
      <div class="modal-title">${isEdit ? "Editar acompanhamento" : "Novo registro de acompanhamento"}</div>
      <div class="field"><label>Pessoa</label>
        <select id="aPessoa" ${isEdit ? "disabled" : ""}>${state.pessoas
          .filter((p) => !p.arquivadoEm)
          .map((p) => `<option value="${p.id}" ${registro && registro.pessoaId === p.id ? "selected" : ""}>${Utils.escapeHtml(p.nomeCompleto)}</option>`)
          .join("")}</select>
      </div>
      <div class="field-row">
        <div class="field"><label>Data</label><input type="date" id="aData" value="${registro ? registro.data : Utils.todayISO()}" /></div>
        <div class="field"><label>Responsável</label><input id="aResponsavel" value="${registro ? Utils.escapeHtml(registro.responsavel || "") : Utils.escapeHtml(session.nome)}" /></div>
      </div>
      <div class="field"><label>Assunto geral</label><input id="aAssunto" value="${registro ? Utils.escapeHtml(registro.assunto || "") : ""}" /></div>
      <div class="field"><label>Observação</label><textarea id="aObs">${registro ? Utils.escapeHtml(registro.observacao || "") : ""}</textarea></div>
      <div class="field-row">
        <div class="field"><label>Próximo acompanhamento</label><input type="date" id="aProximo" value="${registro ? registro.proximoAcompanhamento || "" : ""}" /></div>
        <div class="field"><label>Situação</label>
          <select id="aSituacao">
            ${["Em andamento", "Aguardando", "Concluído"].map((s) => `<option ${registro && registro.situacao === s ? "selected" : ""}>${s}</option>`).join("")}
          </select>
        </div>
      </div>
      <button class="btn btn-primary btn-block" id="salvarAcompBtn">Salvar</button>
      ${isEdit ? `<button class="btn btn-danger btn-block" style="margin-top:10px;" id="arquivarAcompBtn">Arquivar</button>` : ""}
      ${
        isEdit && (registro.historico || []).length
          ? `<div class="divider"></div><div style="font-size:12px;color:var(--text-dim);font-weight:600;margin-bottom:6px;">Histórico</div>
             ${registro.historico
               .slice()
               .reverse()
               .map((h) => `<div class="text-dim" style="font-size:11.5px;margin-bottom:4px;">${Utils.parseDateBR(h.data)} · ${Utils.escapeHtml(h.autor)} · ${Utils.escapeHtml(h.resumo)}</div>`)
               .join("")}`
          : ""
      }
    `);

    document.getElementById("salvarAcompBtn").addEventListener("click", async () => {
      const historico = registro ? [...(registro.historico || [])] : [];
      historico.push({ data: Utils.todayISO(), autor: session.nome, resumo: isEdit ? "Editado" : "Criado" });
      const obj = {
        pessoaId: registro ? registro.pessoaId : document.getElementById("aPessoa").value,
        data: document.getElementById("aData").value,
        responsavel: document.getElementById("aResponsavel").value.trim(),
        assunto: document.getElementById("aAssunto").value.trim(),
        observacao: document.getElementById("aObs").value.trim(),
        proximoAcompanhamento: document.getElementById("aProximo").value,
        situacao: document.getElementById("aSituacao").value,
        historico,
        autorCriacao: registro ? registro.autorCriacao : session.nome,
        criadoEm: registro ? registro.criadoEm : Utils.todayISO(),
      };
      try {
        if (isEdit) await Api.update("acompanhamento", registro.id, obj);
        else await Api.push("acompanhamento", obj);
        Utils.toast("Registro salvo!");
        Utils.closeModal();
        App.reloadData();
      } catch (e) {
        Utils.toast("Sem permissão para esta ação.", "error");
      }
    });

    if (isEdit) {
      document.getElementById("arquivarAcompBtn").addEventListener("click", async () => {
        if (!confirm("Arquivar este registro?")) return;
        await Api.update("acompanhamento", registro.id, { arquivadoEm: Utils.todayISO() });
        Utils.toast("Registro arquivado.");
        Utils.closeModal();
        App.reloadData();
      });
    }
  }

  // ---------- 3) Pedidos de oração ----------
  function renderOracao(screen, state, session) {
    const podeVerPrivado = Permissoes.pode(session.papel, "verOracaoPrivada");
    const podeCriar = Permissoes.pode(session.papel, "editarOracao");
    const todos = [...state.oracaoVisivel, ...(podeVerPrivado ? state.oracaoPrivado : [])].filter((o) => !o.arquivadoEm);
    const statusOrdem = { novo: 0, "em oração": 1, acompanhando: 2, respondido: 3, encerrado: 4 };
    todos.sort((a, b) => (statusOrdem[a.status] ?? 9) - (statusOrdem[b.status] ?? 9));

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Pedidos de oração</h1>
        ${podeCriar ? `<button class="icon-btn" id="addOracaoBtn">+</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div class="card row-list">
        ${
          todos.length
            ? todos
                .map((o) => {
                  const pessoa = state.pessoas.find((p) => p.id === o.pessoaId);
                  return `<button class="row-item" style="width:100%;align-items:flex-start;" data-editar="${o.id}" data-colecao="${o.privacidade === "privado" ? "oracaoPrivado" : "oracaoVisivel"}">
                <div class="avatar">${Utils.astronautIcon()}</div>
                <div class="row-main">
                  <div class="name">${Utils.escapeHtml(pessoa?.nomeCompleto || "Anônimo")}</div>
                  <div class="meta">${Utils.escapeHtml(o.pedido || "")}</div>
                  <div class="meta">${Utils.parseDateBR(o.data)} · <span class="badge badge-gold">${Utils.capitalize(o.status)}</span> ${o.privacidade === "privado" ? '<span class="badge badge-muted">Privado</span>' : ""}</div>
                </div>
              </button>`;
                })
                .join("")
            : `<div class="empty-state"><div class="glyph">🙏</div><p>Nenhum pedido registrado.</p></div>`
        }
      </div>
    `;
    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("mais"));
    if (podeCriar) document.getElementById("addOracaoBtn").addEventListener("click", () => openOracaoForm(state, session, null));
    screen.querySelectorAll("[data-editar]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const colecao = btn.dataset.colecao;
        const lista = colecao === "oracaoPrivado" ? state.oracaoPrivado : state.oracaoVisivel;
        const o = lista.find((x) => x.id === btn.dataset.editar);
        openOracaoForm(state, session, o, colecao);
      })
    );
  }

  function openOracaoForm(state, session, pedido, colecaoAtual) {
    const isEdit = !!pedido;
    const podeVerPrivado = Permissoes.pode(session.papel, "verOracaoPrivada");
    Utils.openModal(`
      <div class="modal-title">${isEdit ? "Editar pedido" : "Novo pedido de oração"}</div>
      <div class="field"><label>Pessoa</label>
        <select id="oPessoa"><option value="">Anônimo</option>${state.pessoas
          .filter((p) => !p.arquivadoEm)
          .map((p) => `<option value="${p.id}" ${pedido && pedido.pessoaId === p.id ? "selected" : ""}>${Utils.escapeHtml(p.nomeCompleto)}</option>`)
          .join("")}</select>
      </div>
      <div class="field"><label>Pedido</label><textarea id="oPedido">${pedido ? Utils.escapeHtml(pedido.pedido || "") : ""}</textarea></div>
      <div class="field-row">
        <div class="field"><label>Status</label>
          <select id="oStatus">${["novo", "em oração", "acompanhando", "respondido", "encerrado"].map((s) => `<option ${pedido && pedido.status === s ? "selected" : ""}>${s}</option>`).join("")}</select>
        </div>
        <div class="field"><label>Privacidade</label>
          <select id="oPriv" ${!podeVerPrivado ? 'disabled title="Somente administrador"' : ""}>
            <option value="liderança" ${pedido && pedido.privacidade === "liderança" ? "selected" : ""}>Liderança</option>
            <option value="compartilhável" ${pedido && pedido.privacidade === "compartilhável" ? "selected" : ""}>Compartilhável com o GC</option>
            ${podeVerPrivado ? `<option value="privado" ${pedido && pedido.privacidade === "privado" ? "selected" : ""}>Privado</option>` : ""}
          </select>
        </div>
      </div>
      <div class="field"><label>Responsável pelo acompanhamento</label><input id="oResponsavel" value="${pedido ? Utils.escapeHtml(pedido.responsavel || "") : Utils.escapeHtml(session.nome)}" /></div>
      ${
        pedido && pedido.status === "respondido"
          ? `<div class="field"><label>Testemunho (opcional)</label><textarea id="oTestemunho">${Utils.escapeHtml(pedido.testemunho || "")}</textarea></div>`
          : ""
      }
      <button class="btn btn-primary btn-block" id="salvarOracaoBtn">Salvar</button>
      ${isEdit ? `<button class="btn btn-danger btn-block" style="margin-top:10px;" id="arquivarOracaoBtn">Arquivar</button>` : ""}
    `);

    document.getElementById("salvarOracaoBtn").addEventListener("click", async () => {
      const novaPrivacidade = document.getElementById("oPriv").value;
      const novoStatus = document.getElementById("oStatus").value;
      const historico = pedido ? [...(pedido.historico || [])] : [];
      historico.push({ data: Utils.todayISO(), autor: session.nome, resumo: isEdit ? `Atualizado (status: ${novoStatus})` : "Criado" });

      const obj = {
        pessoaId: document.getElementById("oPessoa").value || null,
        pedido: document.getElementById("oPedido").value.trim(),
        data: pedido ? pedido.data : Utils.todayISO(),
        status: novoStatus,
        privacidade: novaPrivacidade,
        responsavel: document.getElementById("oResponsavel").value.trim(),
        historico,
      };
      const testemunhoEl = document.getElementById("oTestemunho");
      if (testemunhoEl) obj.testemunho = testemunhoEl.value.trim();
      if (novoStatus === "respondido" && (!pedido || pedido.status !== "respondido")) {
        obj.dataResposta = Utils.todayISO();
      } else if (pedido && pedido.dataResposta) {
        obj.dataResposta = pedido.dataResposta;
      }

      const colecaoDestino = novaPrivacidade === "privado" ? "oracaoPrivado" : "oracaoVisivel";

      try {
        if (isEdit) {
          if (colecaoDestino === colecaoAtual) {
            await Api.update(colecaoDestino, pedido.id, obj);
          } else {
            await Api.push(colecaoDestino, obj);
            await Api.remove(colecaoAtual, pedido.id);
          }
        } else {
          await Api.push(colecaoDestino, obj);
        }
        Utils.toast("Pedido salvo!");
        Utils.closeModal();
        App.reloadData();
      } catch (e) {
        Utils.toast(e.code === "PERMISSION_DENIED" ? "Sem permissão para esta ação." : "Erro ao salvar.", "error");
      }
    });

    if (isEdit) {
      document.getElementById("arquivarOracaoBtn").addEventListener("click", async () => {
        if (!confirm("Arquivar este pedido?")) return;
        await Api.update(colecaoAtual, pedido.id, { arquivadoEm: Utils.todayISO() });
        Utils.toast("Pedido arquivado.");
        Utils.closeModal();
        App.reloadData();
      });
    }
  }

  return { renderAtencao, renderAcompanhamento, renderOracao };
})();
