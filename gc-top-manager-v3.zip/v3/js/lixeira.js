/**
 * LIXEIRA — pessoas/encontros/mensagens arquivados. Restaurar é
 * sempre possível para quem tem permissão de editar aquele tipo.
 * Exclusão DEFINITIVA é só para admin, com confirmação forte (digitar
 * o nome) e limpeza de referências (para não deixar ponteiros
 * quebrados em encontros, oração e acompanhamento).
 */

const Lixeira = (() => {
  function render(screen, state, session) {
    if (!Permissoes.pode(session.papel, "verLixeira")) {
      screen.innerHTML = `<div class="empty-state" style="padding-top:60px;"><div class="glyph">🔒</div><p>Área restrita à administração.</p></div>`;
      return;
    }

    const podeRestaurar = Permissoes.pode(session.papel, "restaurarLixeira");
    const podeExcluir = Permissoes.pode(session.papel, "excluirDefinitivamente");
    const podeAnonimizar = Permissoes.pode(session.papel, "anonimizarPessoas");

    const pessoas = state.pessoas.filter((p) => p.arquivadoEm);
    const encontros = state.encontros.filter((e) => e.arquivadoEm);
    const mensagens = state.mensagens.filter((m) => m.arquivadoEm);

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Lixeira</h1>
        <div style="width:38px;"></div>
      </div>

      <div class="section-title"><h2>Pessoas (${pessoas.length})</h2></div>
      <div class="card row-list">${itensPessoas(pessoas, state, podeRestaurar, podeExcluir, podeAnonimizar)}</div>

      <div class="section-title"><h2>Encontros (${encontros.length})</h2></div>
      <div class="card row-list">${itens(encontros, "encontros", (e) => `${e.tema || "Encontro"} — ${Utils.parseDateBR(e.data)}`, podeRestaurar, podeExcluir)}</div>

      <div class="section-title"><h2>Mensagens (${mensagens.length})</h2></div>
      <div class="card row-list">${itens(mensagens, "mensagens", (m) => m.titulo, podeRestaurar, podeExcluir)}</div>
    `;

    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("mais"));

    screen.querySelectorAll("[data-restaurar]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        const [colecao, id] = btn.dataset.restaurar.split("::");
        try {
          await Api.update(colecao, id, { arquivadoEm: null });
          Utils.toast("Restaurado.");
          App.reloadData();
        } catch (e) {
          Utils.toast("Sem permissão para restaurar.", "error");
        }
      })
    );

    screen.querySelectorAll("[data-excluir]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const [colecao, id] = btn.dataset.excluir.split("::");
        const nome = btn.dataset.nome;
        confirmarExclusaoDefinitiva(colecao, id, nome, state);
      })
    );

    screen.querySelectorAll("[data-anonimizar]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const pessoa = state.pessoas.find((p) => p.id === btn.dataset.anonimizar);
        if (pessoa) Pessoas.anonimizar(pessoa);
      })
    );
  }

  function itensPessoas(lista, state, podeRestaurar, podeExcluir, podeAnonimizar) {
    if (!lista.length) return `<div class="empty-state" style="padding:16px;">Vazio.</div>`;
    return lista
      .map((p) => {
        if (p.anonimizadoEm) {
          return `<div class="row-item" style="cursor:default;">
            <div class="row-main"><div class="name">Pessoa anonimizada</div><div class="meta">Anonimizada em ${Utils.parseDateBR(p.anonimizadoEm)} · dados pessoais não podem ser restaurados</div></div>
          </div>`;
        }
        const temHistorico = Pessoas.temHistoricoRelacionado(p.id, state);
        return `<div class="row-item" style="cursor:default;">
          <div class="row-main"><div class="name">${Utils.escapeHtml(p.nomeCompleto)}</div><div class="meta">Arquivado em ${Utils.parseDateBR(p.arquivadoEm)}${temHistorico ? " · tem histórico de encontros/oração" : ""}</div></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;">
            ${podeRestaurar ? `<button class="btn btn-secondary" data-restaurar="pessoas::${p.id}" style="padding:7px 10px;font-size:11.5px;">Restaurar</button>` : ""}
            ${
              temHistorico
                ? podeAnonimizar
                  ? `<button class="btn btn-danger" data-anonimizar="${p.id}" style="padding:7px 10px;font-size:11.5px;">Anonimizar</button>`
                  : ""
                : podeExcluir
                ? `<button class="btn btn-danger" data-excluir="pessoas::${p.id}" data-nome="${Utils.escapeHtml(p.nomeCompleto)}" style="padding:7px 10px;font-size:11.5px;">Excluir</button>`
                : ""
            }
          </div>
        </div>`;
      })
      .join("");
  }

  function itens(lista, colecao, nomeFn, podeRestaurar, podeExcluir) {
    if (!lista.length) return `<div class="empty-state" style="padding:16px;">Vazio.</div>`;
    return lista
      .map(
        (item) => `<div class="row-item" style="cursor:default;">
        <div class="row-main"><div class="name">${Utils.escapeHtml(nomeFn(item))}</div><div class="meta">Arquivado em ${Utils.parseDateBR(item.arquivadoEm)}</div></div>
        <div style="display:flex;gap:6px;">
          ${podeRestaurar ? `<button class="btn btn-secondary" data-restaurar="${colecao}::${item.id}" style="padding:7px 10px;font-size:11.5px;">Restaurar</button>` : ""}
          ${podeExcluir ? `<button class="btn btn-danger" data-excluir="${colecao}::${item.id}" data-nome="${Utils.escapeHtml(nomeFn(item))}" style="padding:7px 10px;font-size:11.5px;">Excluir</button>` : ""}
        </div>
      </div>`
      )
      .join("");
  }

  function confirmarExclusaoDefinitiva(colecao, id, nome, state) {
    const modal = Utils.openModal(`
      <div class="modal-title">Excluir definitivamente</div>
      <div class="text-dim" style="font-size:13px;margin-bottom:14px;line-height:1.5;">
        Esta ação NÃO pode ser desfeita. Para confirmar, digite exatamente:<br/>
        <strong>${Utils.escapeHtml(nome)}</strong>
      </div>
      <div class="field"><input id="confirmaNome" /></div>
      <button class="btn btn-danger btn-block" id="confirmarBtn">Excluir definitivamente</button>
    `);
    document.getElementById("confirmarBtn").addEventListener("click", async () => {
      if (document.getElementById("confirmaNome").value.trim() !== nome) {
        Utils.toast("O nome digitado não confere.", "error");
        return;
      }
      try {
        if (colecao === "pessoas") await limparReferenciasPessoa(id, state);
        await Api.remove(colecao, id);
        Utils.toast("Excluído definitivamente.");
        Utils.closeModal();
        App.reloadData();
      } catch (e) {
        Utils.toast("Sem permissão para excluir definitivamente.", "error");
      }
    });
  }

  /**
   * Remove a referência da pessoa em coleções relacionadas, para não
   * deixar "pontas soltas" depois da exclusão definitiva. Encontros
   * mantêm o histórico de presença (números continuam corretos), só
   * removemos o id da lista de elegíveis/visitantes/presença; pedidos
   * de oração e acompanhamentos ficam com pessoaId nulo (preservados
   * como registro, sem apontar mais para ninguém).
   */
  async function limparReferenciasPessoa(pessoaId, state) {
    const atualizacoesEncontros = state.encontros
      .filter((e) => (e.participantesElegiveis || []).includes(pessoaId) || (e.visitantesIds || []).includes(pessoaId) || (e.presenca && pessoaId in e.presenca))
      .map(async (e) => {
        const participantesElegiveis = (e.participantesElegiveis || []).filter((x) => x !== pessoaId);
        const visitantesIds = (e.visitantesIds || []).filter((x) => x !== pessoaId);
        const presenca = { ...(e.presenca || {}) };
        delete presenca[pessoaId];
        await Api.update("encontros", e.id, { participantesElegiveis, visitantesIds, presenca });
      });

    const atualizacoesOracaoVisivel = state.oracaoVisivel
      .filter((o) => o.pessoaId === pessoaId)
      .map((o) => Api.update("oracaoVisivel", o.id, { pessoaId: null }));
    const atualizacoesOracaoPrivado = state.oracaoPrivado
      .filter((o) => o.pessoaId === pessoaId)
      .map((o) => Api.update("oracaoPrivado", o.id, { pessoaId: null }));
    const atualizacoesAcompanhamento = state.acompanhamento
      .filter((a) => a.pessoaId === pessoaId)
      .map((a) => Api.update("acompanhamento", a.id, { arquivadoEm: Utils.todayISO() }));

    await Promise.all([...atualizacoesEncontros, ...atualizacoesOracaoVisivel, ...atualizacoesOracaoPrivado, ...atualizacoesAcompanhamento]);
  }

  return { render };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = Lixeira;
}
