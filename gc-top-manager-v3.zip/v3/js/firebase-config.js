/**
 * CONFIGURAÇÃO DO FIREBASE — GC Top Manager
 * ---------------------------------------------------------------
 * Preencha com os valores do SEU projeto Firebase (Configurações do
 * projeto → Geral → "Seus apps" → app da Web). Nenhum destes valores
 * é secreto no sentido de senha — a apiKey do Firebase Web é pública
 * por design (ela só identifica o projeto; quem protege os dados são
 * as regras do Realtime Database, em rules/database.rules.json — não
 * ela). Ainda assim, NÃO coloque aqui e-mail/senha de ninguém: contas
 * são criadas no Firebase Authentication (veja LEIA-ME.md), nunca no
 * código.
 *
 * Variáveis a preencher (todas vêm do console do Firebase):
 *   FIREBASE_API_KEY, FIREBASE_AUTH_DOMAIN, FIREBASE_DATABASE_URL,
 *   FIREBASE_PROJECT_ID, FIREBASE_STORAGE_BUCKET,
 *   FIREBASE_MESSAGING_SENDER_ID, FIREBASE_APP_ID
 */

const firebaseConfig = {
  apiKey: "AIzaSyDxgv4JQ5PJhHtd_UArubK1VN0E98DdRHk",
  authDomain: "gc-top-manager-ac718.firebaseapp.com",
  databaseURL: "https://gc-top-manager-ac718-default-rtdb.firebaseio.com",
  projectId: "gc-top-manager-ac718",
  storageBucket: "gc-top-manager-ac718.firebasestorage.app",
  messagingSenderId: "324709613835",
  appId: "1:324709613835:web:719135c0054d5b0f34220e",
};

const CONFIG = {
  // Caminho isolado dentro do Realtime Database — mesma lógica de
  // "gaveta separada" do ConectaWe/CheckWe, mas agora com regras que
  // exigem autenticação (nunca reutilize as regras abertas antigas).
  ROOT_PATH: "gcTopManager",
  GC_NOME: "GC Top do Universo",
  FUSO_HORARIO: "America/Sao_Paulo",
  POLL_INTERVAL_SECONDS: 20,
};

// Inicialização do Firebase (SDK "compat", carregado via <script> no
// index.html — sem bundler, mesma filosofia do ConectaWe/CheckWe).
firebase.initializeApp(firebaseConfig);
const AUTH = firebase.auth();
const DB = firebase.database();
