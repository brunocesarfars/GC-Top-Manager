/**
 * USUÁRIOS — tela de administração de papéis (admin/liderança).
 *
 * Importante: criar a CONTA (e-mail/senha) continua sendo feito no
 * Firebase Authentication (console ou scripts/criar-usuarios.js) —
 * esta tela só atribui o PAPEL a um uid que já existe, e as regras do
 * banco impedem que alguém edite o próprio papel (mesmo um admin),
 * então essa ação sempre é feita por outro administrador.
 */

const Usuarios = (() => {
  async function render(screen, state, session) {
    if (!Permissoes.pode(session.papel, "gerenciarUsuarios")) {
      screen.innerHTML = `<div class="empty-state" style="padding-top:60px;"><div class="glyph">🔒</div><p>Área restrita à administração.</p></div>`;
      return;
    }

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Usuários e permissões</h1>
        <div style="width:38px;"></div>
      </div>
      <div class="text-dim" style="font-size:12.5px;margin-bottom:14px;line-height:1.5;">
        Para CRIAR uma conta nova (e-mail/senha), use o console do Firebase ou
        <code>scripts/criar-usuarios.js</code> — aqui você só define o papel de um
        uid que já existe. Ninguém pode alterar o próprio papel, nem um administrador.
      </div>
      <div id="listaUsuarios" class="card row-list"><div class="empty-state" style="padding:16px;">Carregando…</div></div>
    `;
    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("mais"));

    let usuarios = {};
    try {
      usuarios = await Api.getAll("usuarios");
    } catch (e) {
      document.getElementById("listaUsuarios").innerHTML = `<div class="empty-state" style="padding:16px;">Não foi possível carregar a lista.</div>`;
      return;
    }

    const lista = Utils.toArray(usuarios);
    const wrap = document.getElementById("listaUsuarios");
    wrap.innerHTML = lista.length
      ? lista
          .map(
            (u) => `<div class="row-item" style="cursor:default;">
          <div class="avatar">${Utils.initials(u.nome || u.id)}</div>
          <div class="row-main">
            <div class="name">${Utils.escapeHtml(u.nome || u.id)}</div>
            <div class="meta">Papel atual: <span class="badge badge-gold">${Utils.escapeHtml(u.papel || "sem papel")}</span></div>
          </div>
          ${
            u.id !== session.uid
              ? `<select data-uid="${Utils.escapeHtml(u.id)}" style="background:var(--bg-elevated);border:1px solid var(--border-strong);border-radius:8px;color:var(--text);padding:6px 8px;font-size:12px;">
                  <option value="lideranca" ${u.papel === "lideranca" ? "selected" : ""}>Liderança</option>
                  <option value="admin" ${u.papel === "admin" ? "selected" : ""}>Admin</option>
                </select>`
              : `<span class="text-faint" style="font-size:11px;">(você)</span>`
          }
        </div>`
          )
          .join("")
      : `<div class="empty-state" style="padding:16px;">Nenhum usuário com papel atribuído ainda. Crie as contas no Firebase Authentication e depois defina o papel aqui pelo console (ou peça a outro admin, já que você não pode alterar o próprio).</div>`;

    wrap.querySelectorAll("[data-uid]").forEach((sel) =>
      sel.addEventListener("change", async () => {
        try {
          await Api.update("usuarios", sel.dataset.uid, { papel: sel.value });
          Utils.toast("Papel atualizado.");
        } catch (e) {
          Utils.toast("As regras do banco recusaram esta alteração.", "error");
        }
      })
    );
  }

  return { render };
})();
