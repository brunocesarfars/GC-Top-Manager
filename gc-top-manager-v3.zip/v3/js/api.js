/**
 * API — camada de acesso ao Firebase Realtime Database, agora via SDK
 * autenticado (em vez de REST cru). Toda chamada carrega automaticamente
 * o token da pessoa logada; quem decide se ela pode ler/escrever cada
 * caminho são as regras do banco (rules/database.rules.json) — este
 * arquivo não faz nenhuma checagem de permissão, só repassa o pedido
 * e trata o erro de forma previsível quando o banco nega.
 */

const Api = (() => {
  function ref(path) {
    return DB.ref(`${CONFIG.ROOT_PATH}/${path}`);
  }

  class ErroPermissao extends Error {
    constructor(path) {
      super(`Sem permissão para acessar "${path}".`);
      this.code = "PERMISSION_DENIED";
      this.path = path;
    }
  }

  function tratarErro(e, path) {
    if (e && (e.code === "PERMISSION_DENIED" || /permission_denied/i.test(e.message || ""))) {
      throw new ErroPermissao(path);
    }
    throw e;
  }

  async function getAll(path) {
    try {
      const snap = await ref(path).once("value");
      return snap.val() || {};
    } catch (e) {
      tratarErro(e, path);
    }
  }

  async function getOne(path, id) {
    try {
      const snap = await ref(`${path}/${id}`).once("value");
      return snap.val();
    } catch (e) {
      tratarErro(e, path);
    }
  }

  async function push(path, obj) {
    try {
      const novaRef = ref(path).push();
      await novaRef.set(obj);
      return novaRef.key;
    } catch (e) {
      tratarErro(e, path);
    }
  }

  async function set(path, id, obj) {
    try {
      await ref(`${path}/${id}`).set(obj);
      return obj;
    } catch (e) {
      tratarErro(e, path);
    }
  }

  async function update(path, id, partial) {
    try {
      await ref(`${path}/${id}`).update(partial);
      return true;
    } catch (e) {
      tratarErro(e, path);
    }
  }

  async function remove(path, id) {
    try {
      await ref(`${path}/${id}`).remove();
      return true;
    } catch (e) {
      tratarErro(e, path);
    }
  }

  /**
   * Busca "tolerante": usada para coleções que podem ser negadas pelas
   * regras dependendo do papel de quem está logado (ex.: acompanhamento
   * pastoral para a liderança). Em vez de derrubar a tela toda, devolve
   * uma lista vazia e sinaliza que foi negado — a interface decide o
   * que mostrar (nada, ou uma mensagem de "área restrita").
   */
  async function getAllTolerante(path) {
    try {
      const data = await getAll(path);
      return { dados: data, negado: false };
    } catch (e) {
      if (e.code === "PERMISSION_DENIED") return { dados: {}, negado: true };
      throw e;
    }
  }

  return { getAll, getOne, push, set, update, remove, getAllTolerante, ErroPermissao };
})();
