/**
 * MAPEAMENTO CENTRAL DOS ÍCONES OFICIAIS DO GC TOP DO UNIVERSO
 * ---------------------------------------------------------------
 * Os 12 arquivos originais (fundo transparente, creme/laranja/navy)
 * ficam em assets/icons/gc-top/. Nenhuma tela referencia o caminho
 * do arquivo diretamente — todas passam por este objeto, então se um
 * arquivo mudar de nome só precisa atualizar aqui.
 *
 * Cada ícone tem uma versão .webp (preferida, menor) e .png (reserva,
 * mesma transparência) — GcIcons.src() devolve os dois pra quem quiser
 * montar um <picture>, ou só o webp pra uso direto em <img src>.
 */
const GcIcons = (() => {
  const BASE = "assets/icons/gc-top/";

  const MAPA = {
    home: "icon-home",
    people: "icon-people",
    meetings: "icon-meetings",
    pulpit: "icon-pulpit",
    more: "icon-more",
    birthdays: "icon-birthdays",
    visitors: "icon-visitors",
    pastoralCare: "icon-pastoral-care",
    prayer: "icon-prayer",
    bibleMap: "icon-bible-map",
    usersPermissions: "icon-users-permissions",
    trash: "icon-trash",
  };

  function webp(chave) {
    return `${BASE}${MAPA[chave]}.webp`;
  }
  function png(chave) {
    return `${BASE}${MAPA[chave]}.png`;
  }

  /**
   * Markup de um ícone oficial, pronto pra entrar num botão que já tem
   * texto ao lado (por isso alt="" — decorativo, sem repetir o nome
   * pro leitor de tela). classe extra é opcional (ex.: "nav-icon-img").
   */
  function img(chave, classe = "", tamanho = 28) {
    if (!MAPA[chave]) return "";
    return `<img src="${webp(chave)}" data-fallback-png="${png(chave)}" alt="" width="${tamanho}" height="${tamanho}" class="gc-icon ${classe}" loading="eager" />`;
  }

  /**
   * Chame depois de inserir HTML com ícones no DOM: troca pra PNG se o
   * WebP falhar, e se AINDA falhar, mostra um ponto discreto no lugar
   * (nunca o ícone quebrado do navegador, nunca um ícone antigo).
   */
  function ativarFallback(container) {
    (container || document).querySelectorAll("img.gc-icon").forEach((el) => {
      el.addEventListener(
        "error",
        function onErro() {
          if (el.dataset.fallbackPng && el.src.indexOf(el.dataset.fallbackPng) === -1) {
            el.src = el.dataset.fallbackPng;
            return;
          }
          if (typeof location !== "undefined" && (location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
            console.warn("[GcIcons] Falha ao carregar ícone:", el.src);
          }
          el.style.display = "none";
          const ponto = document.createElement("span");
          ponto.className = "gc-icon-fallback-dot";
          el.parentNode && el.parentNode.insertBefore(ponto, el);
        },
        { once: true }
      );
    });
  }

  return { img, webp, png, ativarFallback };
})();
