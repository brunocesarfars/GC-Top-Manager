/**
 * APP — bootstrap, roteador (hash-based) e barra de navegação.
 *
 * Mudanças de segurança importantes em relação à v1:
 * - Sessão vem de Auth.currentSession() (Firebase Authentication),
 *   nunca mais de sessionStorage decidindo o papel.
 * - Cada coleção é carregada separadamente (não um Promise.all único),
 *   porque coleções restritas (acompanhamento, oracaoPrivado, config)
 *   podem ser negadas pelas regras do banco para quem não é admin —
 *   isso é esperado e tratado, não é um erro fatal do app.
 * - Nenhum atributo onclick="..." inline é usado (só addEventListener),
 *   para permitir uma Content-Security-Policy sem 'unsafe-inline'.
 */

const App = (() => {
  const root = document.getElementById("app");

  const state = {
    pessoas: [],
    encontros: [],
    mensagens: [],
    oracaoVisivel: [],
    oracaoPrivado: [],
    oracaoPrivadoNegado: false,
    acompanhamento: [],
    acompanhamentoNegado: false,
    cuidadoContatos: [],
    config: {},
    configNegado: false,
    avisosEnviados: [],
    loaded: false,
  };

  const NAV_ITEMS = [
    { route: "dashboard", label: "Início", iconKey: "home" },
    { route: "pessoas", label: "Pessoas", iconKey: "people" },
    { route: "encontros", label: "Encontros", iconKey: "meetings" },
    { route: "pulpito", label: "Púlpito", iconKey: "pulpit" },
    { route: "mais", label: "Mais", iconKey: "more" },
  ];

  async function carregarTolerante(path) {
    const { dados } = await Api.getAllTolerante(path);
    return dados;
  }

  async function loadAll(session) {
    const hojeISO = DateUtil.hojeISO();

    const [pessoasRaw, encontrosRaw, mensagensRaw, oracaoVisivelRaw, cuidadoRaw] = await Promise.all([
      carregarTolerante("pessoas"),
      carregarTolerante("encontros"),
      carregarTolerante("mensagens"),
      carregarTolerante("oracaoVisivel"),
      carregarTolerante("cuidadoContatos"),
    ]);

    state.pessoas = Utils.toArray(pessoasRaw);
    state.encontros = Utils.toArray(encontrosRaw).sort((a, b) => (a.data < b.data ? 1 : -1));
    state.mensagens = Utils.toArray(mensagensRaw).sort((a, b) => (a.data < b.data ? 1 : -1));
    state.oracaoVisivel = Utils.toArray(oracaoVisivelRaw);
    state.cuidadoContatos = Utils.toArray(cuidadoRaw);

    if (Permissoes.pode(session.papel, "verOracaoPrivada")) {
      const r = await Api.getAllTolerante("oracaoPrivado");
      state.oracaoPrivado = Utils.toArray(r.dados);
      state.oracaoPrivadoNegado = r.negado;
    } else {
      state.oracaoPrivado = [];
      state.oracaoPrivadoNegado = true; // não tentamos nem pedir — sem permissão por design
    }

    if (Permissoes.pode(session.papel, "verAcompanhamentoPastoral")) {
      const r = await Api.getAllTolerante("acompanhamento");
      state.acompanhamento = Utils.toArray(r.dados);
      state.acompanhamentoNegado = r.negado;
    } else {
      state.acompanhamento = [];
      state.acompanhamentoNegado = true;
    }

    if (Permissoes.pode(session.papel, "editarConfigAniversario") || session.papel === "admin") {
      const r = await Api.getAllTolerante("config");
      state.config = r.dados || {};
      state.configNegado = r.negado;
      const av = await Api.getAllTolerante("avisosEnviados");
      state.avisosEnviados = Utils.toArray(av.dados);
    } else {
      state.config = {};
      state.configNegado = true;
      state.avisosEnviados = [];
    }

    state.hojeISO = hojeISO;
    state.loaded = true;
  }

  function currentRoute() {
    const hash = location.hash.replace("#/", "") || "dashboard";
    const [route, param] = hash.split("/");
    return { route, param };
  }

  function navigate(route) {
    location.hash = `#/${route}`;
  }

  async function render() {
    const session = Auth.currentSession();

    if (!session) {
      renderLogin();
      return;
    }

    if (!session.papel) {
      renderSemPapel(session);
      return;
    }

    if (!state.loaded) {
      root.innerHTML = "";
      root.appendChild(el("div", { class: "screen" }, [renderSplashNode()]));
      try {
        await loadAll(session);
      } catch (e) {
        root.innerHTML = "";
        root.appendChild(renderConnError(e));
        return;
      }
    }

    const { route, param } = currentRoute();
    root.innerHTML = "";

    const screen = document.createElement("div");
    screen.className = "screen";
    root.appendChild(screen);

    switch (route) {
      case "dashboard":
        Dashboard.render(screen, state, session);
        break;
      case "pessoas":
        if (param) Pessoas.renderDetail(screen, state, param, session);
        else Pessoas.render(screen, state, session);
        break;
      case "encontros":
        if (param) Encontros.renderDetail(screen, state, param, session);
        else Encontros.render(screen, state, session);
        break;
      case "aniversariantes":
        Aniversariantes.render(screen, state, session);
        break;
      case "visitantes":
        Visitantes.render(screen, state, session);
        break;
      case "cuidado":
        Cuidado.renderAtencao(screen, state, session);
        break;
      case "acompanhamento":
        Cuidado.renderAcompanhamento(screen, state, session);
        break;
      case "oracao":
        Cuidado.renderOracao(screen, state, session);
        break;
      case "pulpito":
        if (param) Pulpito.renderDetail(screen, state, param, session);
        else Pulpito.render(screen, state, session);
        break;
      case "mapa-biblico":
        Pulpito.renderMapa(screen, state);
        break;
      case "lixeira":
        Lixeira.render(screen, state, session);
        break;
      case "usuarios":
        Usuarios.render(screen, state, session);
        break;
      case "mais":
        renderMais(screen, session);
        break;
      case "busca":
        renderBusca(screen, state, session, param);
        break;
      default:
        Dashboard.render(screen, state, session);
    }

    root.appendChild(renderNav(route));
    window.scrollTo(0, 0);
  }

  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
    children.forEach((c) => node.appendChild(c));
    return node;
  }

  function renderSplashNode() {
    const wrap = el("div", { style: "display:flex;align-items:center;justify-content:center;min-height:70vh;" });
    wrap.innerHTML = `<div style="text-align:center;color:var(--text-dim);">
      <img src="assets/images/loading-mascot.webp" alt="" class="mascot-float" style="width:120px;height:auto;margin-bottom:6px;" />
      <div style="font-size:13.5px;">Carregando o GC…</div>
    </div>`;
    return wrap;
  }

  function renderConnError(e) {
    const wrap = el("div", { class: "screen", style: "min-height:100vh;display:flex;align-items:center;justify-content:center;" });
    const card = el("div", { class: "card", style: "max-width:340px;text-align:center;" });
    card.innerHTML = `
      <div style="font-size:26px;margin-bottom:8px;">🔌</div>
      <div style="font-weight:700;margin-bottom:6px;">Não foi possível carregar</div>
      <div class="text-dim" style="font-size:13px;margin-bottom:14px;">${Utils.escapeHtml(e.message || "Erro desconhecido.")}</div>
    `;
    const btn = el("button", { class: "btn btn-primary" });
    btn.textContent = "Tentar novamente";
    btn.addEventListener("click", () => location.reload());
    card.appendChild(btn);
    wrap.appendChild(card);
    return wrap;
  }

  function renderSemPapel(session) {
    root.innerHTML = "";
    const wrap = el("div", { class: "login-screen" });
    wrap.innerHTML = `
      <div class="login-brand">${Utils.logoImg("login-brand-logo")}</div>
      <div class="card" style="text-align:center;">
        <div style="font-size:26px;margin-bottom:10px;">🔒</div>
        <div style="font-weight:700;margin-bottom:6px;">Conta sem papel definido</div>
        <div class="text-dim" style="font-size:13px;margin-bottom:16px;">
          Você entrou como ${Utils.escapeHtml(session.email)}, mas ainda não tem um papel (Administrador/Liderança)
          atribuído em <code>usuarios/${Utils.escapeHtml(session.uid)}/papel</code>. Peça para um administrador
          configurar isso pelo console do Firebase.
        </div>
      </div>
    `;
    const btn = el("button", { class: "btn btn-secondary btn-block", style: "margin-top:14px;" });
    btn.textContent = "Sair";
    btn.addEventListener("click", async () => {
      await Auth.logout();
      render();
    });
    wrap.appendChild(btn);
    root.appendChild(wrap);
  }

  function iconEnvelope() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2.5" y="4.5" width="19" height="15" rx="2.5"/><path d="M3.5 6l8.5 7 8.5-7"/></svg>`;
  }
  function iconLock() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4.5" y="10.5" width="15" height="10" rx="2.2"/><path d="M7.5 10.5V7a4.5 4.5 0 0 1 9 0v3.5"/></svg>`;
  }
  function iconEyeOff() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 3l18 18"/><path d="M10.6 5.2A10.7 10.7 0 0 1 12 5c5.5 0 9 5 9 7-.4.7-1.1 1.7-2.2 2.7M6.5 6.7C4.4 8 3 10.2 3 12c0 2 3.5 7 9 7 1.4 0 2.7-.3 3.8-.8"/><path d="M9.5 10a3.2 3.2 0 0 0 4.6 4.4"/></svg>`;
  }
  function iconEye() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12c0-2 3.5-7 9-7s9 5 9 7-3.5 7-9 7-9-5-9-7z"/><circle cx="12" cy="12" r="3"/></svg>`;
  }

  function renderLogin() {
    root.innerHTML = "";
    const wrap = el("div", { class: "login-screen" });
    wrap.innerHTML = `
      <div class="login-card">
        <div class="login-input">
          ${iconEnvelope()}
          <input type="email" id="loginEmail" placeholder="E-mail" autocomplete="username" />
        </div>
        <div class="login-input">
          ${iconLock()}
          <input type="password" id="loginSenha" placeholder="Senha" autocomplete="current-password" />
          <span class="toggle-senha" id="toggleSenha">${iconEyeOff()}</span>
        </div>
        <div class="login-error" id="loginError" style="display:none;"></div>
        <button class="btn btn-primary btn-block" id="btnEntrar">Entrar</button>
        <button class="btn btn-ghost btn-block" id="btnEsqueci" style="margin-top:6px;">Esqueci minha senha</button>
      </div>
    `;
    root.appendChild(wrap);

    const btnEntrar = document.getElementById("btnEntrar");
    const btnEsqueci = document.getElementById("btnEsqueci");
    const senhaInput = document.getElementById("loginSenha");
    const toggleSenha = document.getElementById("toggleSenha");
    let senhaVisivel = false;
    toggleSenha.addEventListener("click", () => {
      senhaVisivel = !senhaVisivel;
      senhaInput.type = senhaVisivel ? "text" : "password";
      toggleSenha.innerHTML = senhaVisivel ? iconEye() : iconEyeOff();
    });

    const doLogin = async () => {
      const email = document.getElementById("loginEmail").value;
      const senha = document.getElementById("loginSenha").value;
      const errEl = document.getElementById("loginError");
      errEl.style.display = "none";
      if (!email || !senha) {
        errEl.textContent = "Preencha e-mail e senha.";
        errEl.style.display = "block";
        return;
      }
      btnEntrar.disabled = true;
      btnEntrar.textContent = "Entrando…";
      const result = await Auth.login(email, senha);
      btnEntrar.disabled = false;
      btnEntrar.textContent = "Entrar";
      if (!result.ok) {
        errEl.textContent = result.error;
        errEl.style.display = "block";
      }
      // Se deu certo, o próprio onAuthStateChanged (ver bootstrap) dispara o render().
    };

    btnEntrar.addEventListener("click", doLogin);
    senhaInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") doLogin();
    });

    btnEsqueci.addEventListener("click", async () => {
      const email = document.getElementById("loginEmail").value;
      const errEl = document.getElementById("loginError");
      if (!email) {
        errEl.textContent = "Digite seu e-mail no campo acima primeiro.";
        errEl.style.display = "block";
        return;
      }
      const result = await Auth.resetPassword(email);
      errEl.style.display = "block";
      errEl.style.color = result.ok ? "var(--green)" : "";
      errEl.textContent = result.ok
        ? "Enviamos um e-mail com instruções para redefinir sua senha."
        : result.error;
    });
  }

  function renderNav(activeRoute) {
    const nav = document.createElement("div");
    nav.className = "bottom-nav";
    nav.innerHTML = NAV_ITEMS.map((item) => {
      const ativo = activeRoute === item.route;
      return `
      <button class="nav-item ${ativo ? "active" : ""}" data-route="${item.route}" ${ativo ? 'aria-current="page"' : ""}>
        ${GcIcons.img(item.iconKey, "nav-icon-img")}
        <span>${item.label}</span>
      </button>`;
    }).join("");
    nav.addEventListener("click", (e) => {
      const btn = e.target.closest(".nav-item");
      if (btn) navigate(btn.dataset.route);
    });
    GcIcons.ativarFallback(nav);
    return nav;
  }

  function renderMais(screen, session) {
    const itens = [
      { route: "aniversariantes", iconKey: "birthdays", titulo: "Aniversariantes", desc: "Próximos aniversários e avisos", sempre: true },
      { route: "visitantes", iconKey: "visitors", titulo: "Visitantes e integração", desc: "Funil de acompanhamento", sempre: true },
      { route: "acompanhamento", iconKey: "pastoralCare", titulo: "Acompanhamento pastoral", desc: "Acesso restrito", acao: "verAcompanhamentoPastoral" },
      { route: "oracao", iconKey: "prayer", titulo: "Pedidos de oração", desc: "Acompanhamento de pedidos", sempre: true },
      { route: "mapa-biblico", iconKey: "bibleMap", titulo: "Mapa bíblico", desc: "Livros já utilizados no púlpito", sempre: true },
      { route: "usuarios", iconKey: "usersPermissions", titulo: "Usuários e permissões", desc: "Somente administrador", acao: "gerenciarUsuarios" },
      { route: "lixeira", iconKey: "trash", titulo: "Lixeira", desc: "Itens arquivados", acao: "verLixeira" },
    ].filter((i) => i.sempre || Permissoes.pode(session.papel, i.acao));

    screen.innerHTML = `
      <div class="topbar">${Utils.logoImg("topbar-logo")}<h1 style="margin-left:8px;">Mais</h1></div>
      <div class="card row-list" id="maisMenu">
        ${itens
          .map(
            (i) => `<button class="row-item" data-route="${i.route}">
          <div class="more-icon-container">${GcIcons.img(i.iconKey, "", 27)}</div>
          <div class="row-main"><div class="name">${Utils.escapeHtml(i.titulo)}</div><div class="meta">${Utils.escapeHtml(i.desc)}</div></div>
          <span class="chev">›</span>
        </button>`
          )
          .join("")}
      </div>

      <div class="section-title"><h2>Busca global</h2></div>
      <div class="search-box">
        <span>${Utils.iconSearch()}</span>
        <input id="buscaGlobalInput" placeholder="Buscar pessoa, mensagem, texto bíblico…" />
      </div>

      <div class="section-title"><h2>Conta</h2></div>
      <div class="card">
        <div class="flex-between" style="margin-bottom:12px;">
          <div>
            <div style="font-weight:700;">${Utils.escapeHtml(session.nome)}</div>
            <div class="text-dim" style="font-size:12.5px;">${session.papel === "admin" ? "Administrador" : "Liderança"} · ${Utils.escapeHtml(session.email)}</div>
          </div>
        </div>
        <button class="btn btn-secondary btn-block" id="logoutBtn">Sair</button>
      </div>
    `;
    screen.querySelectorAll("[data-route]").forEach((el) => el.addEventListener("click", () => navigate(el.dataset.route)));
    GcIcons.ativarFallback(screen);
    document.getElementById("logoutBtn").addEventListener("click", async () => {
      await Auth.logout();
      state.loaded = false;
    });
    document.getElementById("buscaGlobalInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.target.value.trim()) {
        navigate(`busca/${encodeURIComponent(e.target.value.trim())}`);
      }
    });
  }

  function renderBusca(screen, state, session, termoEncoded) {
    const termo = decodeURIComponent(termoEncoded || "").toLowerCase();
    const pessoas = state.pessoas.filter((p) => !p.arquivadoEm && p.nomeCompleto?.toLowerCase().includes(termo));
    const mensagens = Permissoes.pode(session.papel, "verPulpito")
      ? state.mensagens.filter((m) =>
          [m.titulo, m.passagemPrincipal, m.tema, ...(m.tags || [])].filter(Boolean).join(" ").toLowerCase().includes(termo)
        )
      : [];

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <h1>Busca: "${Utils.escapeHtml(termo)}"</h1>
        <div style="width:38px;"></div>
      </div>
      <div class="section-title"><h2>Pessoas (${pessoas.length})</h2></div>
      <div class="card row-list">
        ${
          pessoas.length
            ? pessoas.map((p) => `<button class="row-item" data-nav="pessoas/${p.id}"><div class="avatar">${Utils.astronautIcon()}</div><div class="row-main"><div class="name">${Utils.escapeHtml(p.nomeCompleto)}</div></div><span class="chev">›</span></button>`).join("")
            : `<div class="empty-state" style="padding:16px;">Nenhuma pessoa encontrada.</div>`
        }
      </div>
      <div class="section-title"><h2>Mensagens (${mensagens.length})</h2></div>
      <div class="card row-list">
        ${
          mensagens.length
            ? mensagens.map((m) => `<button class="row-item" data-nav="pulpito/${m.id}"><div class="avatar">📖</div><div class="row-main"><div class="name">${Utils.escapeHtml(m.titulo)}</div><div class="meta">${Utils.escapeHtml(m.passagemPrincipal || "")}</div></div><span class="chev">›</span></button>`).join("")
            : `<div class="empty-state" style="padding:16px;">Nenhuma mensagem encontrada.</div>`
        }
      </div>
    `;
    document.getElementById("voltarBtn").addEventListener("click", () => history.back());
    screen.querySelectorAll("[data-nav]").forEach((el) => el.addEventListener("click", () => navigate(el.dataset.nav)));
  }

  function reloadData() {
    state.loaded = false;
    render();
  }

  function bootstrap() {
    window.addEventListener("hashchange", render);
    Auth.init((session) => {
      state.loaded = false;
      render();
    });
  }

  return { state, navigate, render, reloadData, bootstrap };
})();

document.addEventListener("DOMContentLoaded", App.bootstrap);
