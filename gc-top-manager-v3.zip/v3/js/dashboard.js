/**
 * DASHBOARD — visão rápida do GC. Frequência e alertas agora vêm de
 * js/logica-pura.js (as mesmas funções cobertas pelos testes), não de
 * cálculos soltos aqui.
 */

const Dashboard = (() => {
  function iconPeople() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3"/><path d="M2.5 19c0-3.3 2.9-5.7 6.5-5.7s6.5 2.4 6.5 5.7"/><circle cx="17" cy="9" r="2.3"/><path d="M15.5 13.5a4.7 4.7 0 0 1 5.5 4.6"/></svg>`;
  }
  function iconPerson() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c0-4 3.4-6.8 7.5-6.8s7.5 2.8 7.5 6.8"/></svg>`;
  }
  function iconPersonPlus() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="10" cy="8" r="3.4"/><path d="M3 20c0-3.8 3.1-6.5 7-6.5s7 2.7 7 6.5"/><path d="M18.5 8v5M16 10.5h5"/></svg>`;
  }
  function iconBarChart() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20V11M12 20V4M20 20v-7"/></svg>`;
  }
  function iconCalendarSmall() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3.5" y="5" width="17" height="15.5" rx="2.2"/><path d="M3.5 9.5h17M8 3v3.6M16 3v3.6"/></svg>`;
  }
  function iconHeartOutline() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20.2s-7.8-4.7-7.8-10.2C4.2 6.9 6.4 5 9 5c1.4 0 2.6.7 3 1.8C12.4 5.7 13.6 5 15 5c2.6 0 4.8 1.9 4.8 5 0 5.5-7.8 10.2-7.8 10.2z"/></svg>`;
  }

  function iconBell() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 10a6 6 0 0 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 14 6 10z"/><path d="M9.5 18.5a2.5 2.5 0 0 0 5 0"/></svg>`;
  }
  function iconPin() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-6.6 7-11.5A7 7 0 0 0 5 9.5C5 14.4 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.3"/></svg>`;
  }
  function iconClock() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>`;
  }
  function iconGiftSmall() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3.5" y="9" width="17" height="11" rx="1.6"/><path d="M3.5 9h17M12 9v11"/><path d="M12 9c-1.2-3.4-3-4.6-4.5-4.2-1.3.3-1.8 1.7-.9 2.7.7.8 2.6 1.5 5.4 1.5zM12 9c1.2-3.4 3-4.6 4.5-4.2 1.3.3 1.8 1.7.9 2.7-.7.8-2.6 1.5-5.4 1.5z"/></svg>`;
  }

  function dateBadge(iso) {
    return Utils.dateBadgeHTML(iso);
  }

  function computeStats(state) {
    const hoje = state.hojeISO;
    const pessoasAtivas = state.pessoas.filter((p) => !p.arquivadoEm);
    const membros = pessoasAtivas.filter((p) => p.situacao === "membro").length;

    const inicioMesISO = hoje.slice(0, 8) + "01";
    const visitantesNoMes = pessoasAtivas.filter(
      (p) => ["visitante", "visitante recorrente"].includes(p.situacao) && p.chegouEm >= inicioMesISO
    ).length;
    const novosIntegrados = pessoasAtivas.filter((p) => p.situacao === "novo integrado" && p.chegouEm >= inicioMesISO).length;

    const freqGeral = Logica.frequenciaGeral(state.encontros, hoje);

    return { membros, visitantesNoMes, novosIntegrados, freqMedia: freqGeral.percentual };
  }

  function proximoEncontro(state) {
    return state.encontros
      .filter((e) => !e.arquivadoEm && e.data >= state.hojeISO)
      .sort((a, b) => (a.data > b.data ? 1 : -1))[0];
  }

  function aniversariantesDaSemana(state) {
    return state.pessoas
      .filter((p) => !p.arquivadoEm)
      .map((p) => ({ ...p, dias: Utils.daysUntilNextBirthday(p.nascimento) }))
      .filter((p) => p.dias !== null && p.dias <= 7)
      .sort((a, b) => a.dias - b.dias)
      .slice(0, 5);
  }

  function ultimosEncontrosRealizados(state, n = 6) {
    return Logica.encontrosRealizados(state.encontros.filter((e) => !e.arquivadoEm), state.hojeISO)
      .sort((a, b) => (a.data > b.data ? -1 : 1))
      .slice(0, n);
  }

  function miniChart(ultimos) {
    if (!ultimos.length) return "";
    const ordenados = [...ultimos].reverse();
    const max = Math.max(1, ...ordenados.map((e) => (e.participantesElegiveis || []).filter((id) => e.presenca && e.presenca[id]).length));
    const bars = ordenados
      .map((e) => {
        const total = (e.participantesElegiveis || []).filter((id) => e.presenca && e.presenca[id]).length;
        const h = Math.max(6, Math.round((total / max) * 56));
        return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;">
          <div style="width:100%;max-width:22px;height:${h}px;border-radius:6px;background:linear-gradient(180deg,#f0a94f,#c97324);"></div>
          <div style="font-size:10px;color:var(--text-faint);">${Utils.parseDateBR(e.data).slice(0, 5)}</div>
        </div>`;
      })
      .join("");
    return `<div style="display:flex;align-items:flex-end;gap:8px;height:80px;">${bars}</div>`;
  }

  function render(screen, state, session) {
    const { membros, visitantesNoMes, novosIntegrados, freqMedia } = computeStats(state);
    const proximo = proximoEncontro(state);
    const aniversariantes = aniversariantesDaSemana(state);
    const alertas = Permissoes.pode(session.papel, "verCuidado")
      ? Logica.identificarCuidado(state.pessoas, state.encontros, state.hojeISO, indexarContatos(state.cuidadoContatos))
      : [];
    const ultimos = ultimosEncontrosRealizados(state);
    const versiculo = Versiculos.sortear();

    screen.innerHTML = `
      <div class="dash-header">
        <div class="avatar">${Utils.astronautIcon()}</div>
        <div class="greet">
          <h1>Olá, ${Utils.escapeHtml(session.nome)}! 👋</h1>
          <div class="subtitle">Que bom ter você por aqui.</div>
        </div>
        <button class="icon-btn bell-btn" id="menuBtn">${iconBell()}<span class="dot"></span></button>
      </div>

      <div class="hero-verse">
        <div>
          <div class="quote">"${Utils.escapeHtml(versiculo.texto)}"</div>
          <div class="ref">${Utils.escapeHtml(versiculo.ref)}</div>
        </div>
        <div class="spark">✦</div>
      </div>

      <div class="stat-grid">
        <div class="stat-card"><div class="stat-icon">${iconPeople()}</div><span class="value">${membros}</span><span class="label">Membros ativos</span><span class="stat-chev">›</span></div>
        <div class="stat-card"><div class="stat-icon">${iconPerson()}</div><span class="value">${visitantesNoMes}</span><span class="label">Visitantes no mês</span><span class="stat-chev">›</span></div>
        <div class="stat-card"><div class="stat-icon">${iconPersonPlus()}</div><span class="value">${novosIntegrados}</span><span class="label">Novos integrados</span><span class="stat-chev">›</span></div>
        <div class="stat-card"><div class="stat-icon">${iconBarChart()}</div><span class="value">${freqMedia}%</span><span class="label">Frequência média</span><span class="stat-chev">›</span></div>
      </div>

      <div class="section-title"><h2>Próximo encontro</h2><a href="#/encontros">Ver todos ›</a></div>
      ${
        proximo
          ? `<button class="card" style="width:100%;" data-nav="encontros/${proximo.id}">
              <div class="encontro-card-row">
                ${dateBadge(proximo.data)}
                <div class="info">
                  <div class="titulo">${Utils.escapeHtml(proximo.tema || "Encontro do GC")}</div>
                  <div class="sub">${Utils.escapeHtml(proximo.textoBiblico || "")}</div>
                  <div class="linha2">
                    <span>${iconPin()}${Utils.escapeHtml(proximo.local || "")}</span>
                    <span>${iconClock()}${Utils.escapeHtml(proximo.hora || "")}${proximo.hora ? "h" : ""}</span>
                  </div>
                </div>
                <span class="chev">›</span>
              </div>
            </button>`
          : `<div class="card empty-state" style="padding:20px;"><img src="assets/images/loading-mascot.webp" alt="" style="width:96px;height:auto;margin:0 auto 10px;" loading="lazy" /><p>Nenhum encontro agendado.</p></div>`
      }

      ${
        aniversariantes.length
          ? `<div class="section-title"><h2>Próximos aniversários</h2></div>
             <div class="card row-list">
               ${aniversariantes
                 .map(
                   (p) => `<div class="row-item" style="cursor:default;">
                    <div class="avatar">${Utils.astronautIcon()}</div>
                    <div class="row-main">
                      <div class="name">${Utils.escapeHtml(p.apelido || p.nomeCompleto.split(" ")[0])}</div>
                      <div class="meta">${Utils.formatBirthdayShort(p.nascimento)}</div>
                    </div>
                    <span class="dias-pill">${iconGiftSmall()} Em ${p.dias} ${p.dias === 1 ? "dia" : "dias"}</span>
                  </div>`
                 )
                 .join("")}
             </div>`
          : ""
      }

      ${
        Permissoes.pode(session.papel, "verCuidado") && alertas.length
          ? `<div class="section-title" style="margin-top:16px;"></div>
             <button class="card row-item" style="width:100%;" data-nav="cuidado">
                <div class="avatar" style="border-radius:50%;">${iconHeartOutline()}</div>
                <div class="row-main">
                  <div class="name">Cuidado e acompanhamento</div>
                  <div class="meta">${alertas.length} ${alertas.length === 1 ? "pessoa pode" : "pessoas podem"} precisar de contato</div>
                </div>
                <span class="chev">›</span>
              </button>`
          : ""
      }

      ${
        ultimos.length
          ? `<div class="section-title"><h2>Frequência nos últimos encontros</h2></div>
             <div class="card">${miniChart(ultimos)}</div>`
          : ""
      }
    `;

    document.getElementById("menuBtn").addEventListener("click", () => Utils.toast("Sem novas notificações."));
    screen.querySelectorAll("[data-nav]").forEach((el) => el.addEventListener("click", () => App.navigate(el.dataset.nav)));
  }

  function indexarContatos(cuidadoContatos) {
    const map = {};
    cuidadoContatos.forEach((c) => {
      // mantém o mais recente por pessoa
      if (!map[c.pessoaId] || c.data > map[c.pessoaId].data) map[c.pessoaId] = c;
    });
    return map;
  }

  return { render, indexarContatos };
})();
