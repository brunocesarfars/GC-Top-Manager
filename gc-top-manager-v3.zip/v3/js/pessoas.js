/**
 * PESSOAS — cadastro, lista com filtros/busca e ficha individual.
 *
 * Mudanças de segurança/integridade nesta versão:
 * - "Excluir" nunca mais é exclusão física por padrão: marca
 *   arquivadoEm (vai para a Lixeira). Exclusão definitiva é uma ação
 *   separada, só para admin, com confirmação forte.
 * - A aba de Acompanhamento na ficha só é OFERECIDA e só busca dados
 *   se a pessoa logada tiver permissão — para quem não tem, mostra uma
 *   mensagem de "área restrita" em vez de tentar buscar e vazar dados.
 * - Links (WhatsApp/telefone/e-mail) passam por Utils.sanitizarUrl.
 */

const Pessoas = (() => {
  const SITUACOES = ["visitante", "visitante recorrente", "membro", "novo integrado", "afastado/inativo"];
  let filtroAtivo = "todos";
  let termoBusca = "";
  let tabAtiva = "resumo";

  function ativos(state) {
    return state.pessoas.filter((p) => !p.arquivadoEm);
  }

  function render(screen, state, session) {
    const podeCriarEditar = Permissoes.pode(session.papel, "editarPessoas");
    const filtrados = ativos(state).filter((p) => {
      const passaFiltro =
        filtroAtivo === "todos" ||
        (filtroAtivo === "membros" && p.situacao === "membro") ||
        (filtroAtivo === "visitantes" && ["visitante", "visitante recorrente"].includes(p.situacao)) ||
        (filtroAtivo === "inativos" && p.situacao === "afastado/inativo");
      const passaBusca =
        !termoBusca || [p.nomeCompleto, p.telefone, p.situacao].filter(Boolean).join(" ").toLowerCase().includes(termoBusca);
      return passaFiltro && passaBusca;
    });

    screen.innerHTML = `
      <div class="topbar">
        <h1>Pessoas</h1>
        ${podeCriarEditar ? `<button class="icon-btn" id="addPessoaBtn">+</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div class="search-box"><span>${Utils.iconSearch()}</span><input id="pessoaSearch" placeholder="Buscar nome, telefone ou status…" value="${Utils.escapeHtml(termoBusca)}" /></div>
      <div class="chip-row" id="filtroChips">
        <button class="chip ${filtroAtivo === "todos" ? "active" : ""}" data-f="todos">Todos</button>
        <button class="chip ${filtroAtivo === "membros" ? "active" : ""}" data-f="membros">Membros</button>
        <button class="chip ${filtroAtivo === "visitantes" ? "active" : ""}" data-f="visitantes">Visitantes</button>
        <button class="chip ${filtroAtivo === "inativos" ? "active" : ""}" data-f="inativos">Inativos</button>
      </div>
      <div class="card row-list">
        ${
          filtrados.length
            ? filtrados
                .map(
                  (p) => `<button class="row-item" data-nav="pessoas/${p.id}">
                <div class="avatar">${p.fotoUrl ? "" : Utils.astronautIcon()}</div>
                <div class="row-main">
                  <div class="name">${Utils.escapeHtml(p.nomeCompleto)}</div>
                  <div class="meta"><span class="badge ${Utils.statusBadgeClass(p.situacao)}">${Utils.capitalize(p.situacao)}</span></div>
                </div>
                <span class="chev">›</span>
              </button>`
                )
                .join("")
            : `<div class="empty-state"><div class="glyph">🧑‍🤝‍🧑</div><p>Nenhuma pessoa encontrada.</p></div>`
        }
      </div>
    `;

    // avatar com foto (evitamos template string com URL não sanitizada — setamos via JS)
    filtrados.forEach((p) => {
      if (!p.fotoUrl) return;
      const btn = screen.querySelector(`[data-nav="pessoas/${p.id}"] .avatar`);
      if (btn) {
        const img = document.createElement("img");
        img.src = Utils.sanitizarUrl(p.fotoUrl);
        img.alt = "";
        img.style.cssText = "width:100%;height:100%;border-radius:50%;object-fit:cover;";
        btn.appendChild(img);
      }
    });

    screen.querySelectorAll("[data-nav]").forEach((el) => el.addEventListener("click", () => App.navigate(el.dataset.nav)));
    if (podeCriarEditar) document.getElementById("addPessoaBtn").addEventListener("click", () => openForm(null, state, session));
    document.getElementById("pessoaSearch").addEventListener("input", (e) => {
      termoBusca = e.target.value.toLowerCase();
      render(screen, state, session);
    });
    document.getElementById("filtroChips").addEventListener("click", (e) => {
      const btn = e.target.closest(".chip");
      if (!btn) return;
      filtroAtivo = btn.dataset.f;
      render(screen, state, session);
    });
  }

  function renderDetail(screen, state, id, session) {
    const p = state.pessoas.find((x) => x.id === id);
    if (!p) {
      screen.innerHTML = `<div class="empty-state">Pessoa não encontrada.</div>`;
      return;
    }

    const freq = Logica.frequenciaIndividual(p.id, state.encontros, state.hojeISO);
    const participacoes = Logica.encontrosRealizados(state.encontros, state.hojeISO)
      .filter((e) => (e.participantesElegiveis || []).includes(p.id) || (e.visitantesIds || []).includes(p.id))
      .sort((a, b) => (a.data > b.data ? -1 : 1));

    const podeEditar = Permissoes.pode(session.papel, "editarPessoas");

    screen.innerHTML = `
      <div class="topbar">
        <button class="icon-btn" id="voltarBtn">←</button>
        <div style="width:38px;"></div>
        ${podeEditar ? `<button class="icon-btn" id="editPessoaBtn">✎</button>` : `<div style="width:38px;"></div>`}
      </div>
      <div style="text-align:center;margin-bottom:16px;">
        <div class="avatar" id="fichaAvatar" style="width:84px;height:84px;font-size:26px;margin:0 auto 12px;">${p.fotoUrl ? "" : Utils.astronautIcon()}</div>
        <div style="font-size:19px;font-weight:700;">${Utils.escapeHtml(p.nomeCompleto)}</div>
        ${p.anonimizadoEm ? `<div class="badge badge-muted" style="margin-top:6px;">Anonimizada</div>` : p.arquivadoEm ? `<div class="badge badge-muted" style="margin-top:6px;">Arquivada</div>` : `<div style="margin-top:6px;"><span class="badge ${Utils.statusBadgeClass(p.situacao)}">${Utils.capitalize(p.situacao)}</span></div>`}
      </div>
      <div style="display:flex;gap:10px;justify-content:center;margin-bottom:20px;" id="fichaContatos"></div>

      <div class="tab-row">
        <button class="tab-btn ${tabAtiva === "resumo" ? "active" : ""}" data-tab="resumo">Resumo</button>
        <button class="tab-btn ${tabAtiva === "presenca" ? "active" : ""}" data-tab="presenca">Presença</button>
        <button class="tab-btn ${tabAtiva === "acompanhamento" ? "active" : ""}" data-tab="acompanhamento">Acompanhamento</button>
      </div>

      <div id="tabContent"></div>
    `;

    if (p.fotoUrl) {
      const img = document.createElement("img");
      img.src = Utils.sanitizarUrl(p.fotoUrl);
      img.style.cssText = "width:100%;height:100%;border-radius:50%;object-fit:cover;";
      document.getElementById("fichaAvatar").appendChild(img);
    }

    const contatos = document.getElementById("fichaContatos");
    if (p.whatsapp) contatos.appendChild(linkBtn("whatsapp", iconWhatsapp(), `https://wa.me/${Utils.normalizarTelefone(p.whatsapp)}`));
    if (p.telefone) contatos.appendChild(linkBtn("tel", iconPhone(), `tel:${Utils.normalizarTelefone(p.telefone)}`));
    if (p.email) contatos.appendChild(linkBtn("mail", iconMail(), `mailto:${p.email}`));

    document.getElementById("voltarBtn").addEventListener("click", () => App.navigate("pessoas"));
    if (podeEditar) document.getElementById("editPessoaBtn").addEventListener("click", () => openForm(p, state, session));
    screen.querySelector(".tab-row").addEventListener("click", (e) => {
      const btn = e.target.closest(".tab-btn");
      if (!btn) return;
      tabAtiva = btn.dataset.tab;
      renderDetail(screen, state, id, session);
    });

    renderTabContent(screen, state, session, p, freq, participacoes);
  }

  function iconWhatsapp() {
    return `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5A9.5 9.5 0 0 0 3.6 17l-1.1 4.5 4.6-1.2A9.5 9.5 0 1 0 12 2.5zm5.5 13.6c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .1-3.3-.9-2.8-1.2-4.5-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8 0-1.3.7-2 1-2.3.3-.3.6-.3.8-.3h.5c.2 0 .4 0 .6.5.2.5.7 1.8.8 1.9.1.2.1.3 0 .5-.1.2-.2.3-.3.5-.2.2-.3.3-.5.5-.2.2-.3.4-.1.7.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.4 2.5 1.6.3.2.5.1.7-.1.2-.2.7-.8.9-1.1.2-.3.4-.2.6-.1.2.1 1.5.7 1.8.8.3.1.5.2.5.3.1.3.1.7-.1 1.2z"/></svg>`;
  }
  function iconPhone() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 3h3l1.5 4.5-2 1.5a13 13 0 0 0 6.5 6.5l1.5-2L21 15v3a2 2 0 0 1-2 2C10.5 20 4 13.5 4 5a2 2 0 0 1 2-2z"/></svg>`;
  }
  function iconMail() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2.5" y="4.5" width="19" height="15" rx="2.5"/><path d="M3.5 6l8.5 7 8.5-7"/></svg>`;
  }

  function linkBtn(tipo, iconeSvg, url) {
    const a = document.createElement("a");
    a.className = `contact-btn ${tipo}`;
    a.href = Utils.sanitizarUrl(url, ["https:", "tel:", "mailto:"]);
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.innerHTML = iconeSvg;
    return a;
  }

  function renderTabContent(screen, state, session, p, freq, participacoes) {
    const content = screen.querySelector("#tabContent");

    if (tabAtiva === "resumo") {
      content.innerHTML = `
        <div class="card">
          ${infoRow("📅", "Nascimento", p.nascimento ? `${Utils.parseDateBR(p.nascimento)}${Utils.daysUntilNextBirthday(p.nascimento) !== null ? ` (em ${Utils.daysUntilNextBirthday(p.nascimento)} dias)` : ""}` : null)}
          ${infoRow("🏠", "Chegou ao GC", p.chegouEm ? Utils.parseDateBR(p.chegouEm) : null)}
          ${infoRow("👋", "Convidado por", p.convidadoPor)}
          ${infoRow("📱", "Telefone", p.telefone)}
          ${infoRow("✉️", "E-mail", p.email)}
          ${infoRow("💬", "Nome preferido", p.apelido)}
          ${infoRow("📝", "Observações", p.observacoes)}
        </div>
        ${
          (p.situacaoHistorico || []).length
            ? `<div class="section-title"><h2>Histórico de situação</h2></div>
               <div class="card row-list">
                 ${p.situacaoHistorico
                   .slice()
                   .reverse()
                   .map((h) => `<div class="row-item" style="cursor:default;"><div class="row-main"><div class="name">${Utils.capitalize(h.situacao)}</div><div class="meta">${Utils.parseDateBR(h.data)}</div></div></div>`)
                   .join("")}
               </div>`
            : ""
        }
      `;
    } else if (tabAtiva === "presenca") {
      content.innerHTML = `
        <div class="card" style="margin-bottom:12px;">
          <div class="stat-grid" style="grid-template-columns:repeat(2,1fr);">
            <div class="stat-card"><div class="value">${freq.elegivel}</div><div class="label">Encontros elegíveis</div></div>
            <div class="stat-card"><div class="value">${freq.percentual}%</div><div class="label">Frequência</div></div>
          </div>
        </div>
        <div class="card row-list">
          ${
            participacoes.length
              ? participacoes
                  .map((e) => {
                    const presente = e.presenca && e.presenca[p.id] === true;
                    return `<div class="row-item" style="cursor:default;">
                <div class="avatar" style="background:${presente ? "rgba(76,175,125,0.16)" : "rgba(107,117,147,0.18)"};color:${presente ? "var(--green)" : "var(--text-dim)"};border-radius:10px;">${presente ? "✓" : "–"}</div>
                <div class="row-main"><div class="name">${Utils.escapeHtml(e.tema || "Encontro")}</div><div class="meta">${Utils.parseDateBR(e.data)}</div></div>
              </div>`;
                  })
                  .join("")
              : `<div class="empty-state" style="padding:16px;">Sem histórico ainda.</div>`
          }
        </div>`;
    } else {
      const podeVerAcompanhamento = Permissoes.pode(session.papel, "verAcompanhamentoPastoral");
      const pedidosVisiveis = state.oracaoVisivel.filter((o) => o.pessoaId === p.id);
      const pedidosPrivados = podeVerAcompanhamento ? state.oracaoPrivado.filter((o) => o.pessoaId === p.id) : [];
      const acompanhamentos = podeVerAcompanhamento ? state.acompanhamento.filter((a) => a.pessoaId === p.id) : [];

      content.innerHTML = `
        <div class="section-title"><h2>Pedidos de oração</h2></div>
        <div class="card row-list">
          ${[...pedidosVisiveis, ...pedidosPrivados]
            .map((o) => `<div class="row-item" style="cursor:default;"><div class="row-main"><div class="name">${Utils.escapeHtml(o.pedido || "")}</div><div class="meta">${Utils.capitalize(o.status)} · ${Utils.parseDateBR(o.data)}${o.privacidade === "privado" ? ' · <span class="badge badge-muted">Privado</span>' : ""}</div></div></div>`)
            .join("") || `<div class="empty-state" style="padding:16px;">Nenhum pedido visível para você.</div>`}
        </div>
        <div class="section-title"><h2>Acompanhamento pastoral</h2></div>
        ${
          podeVerAcompanhamento
            ? `<div class="card row-list">
                ${
                  acompanhamentos.length
                    ? acompanhamentos.map((a) => `<div class="row-item" style="cursor:default;"><div class="row-main"><div class="name">${Utils.escapeHtml(a.assunto || "")}</div><div class="meta">${Utils.parseDateBR(a.data)} · ${Utils.escapeHtml(a.responsavel || "")}</div></div></div>`).join("")
                    : `<div class="empty-state" style="padding:16px;">Nenhum registro ainda.</div>`
                }
              </div>`
            : `<div class="card empty-state" style="padding:16px;"><div class="glyph">🔒</div><p>Área restrita — sem permissão para visualizar.</p></div>`
        }
      `;
    }
  }

  function infoRow(icon, label, value) {
    return `<div style="display:flex;gap:12px;padding:9px 0;border-bottom:1px solid var(--border);">
      <div style="width:20px;text-align:center;">${icon}</div>
      <div><div style="font-size:11.5px;color:var(--text-dim);">${label}</div><div style="font-size:13.5px;margin-top:2px;">${value ? Utils.escapeHtml(value) : "—"}</div></div>
    </div>`;
  }

  // ---------- deduplicação (usada aqui e por Encontros.openVisitanteRapido) ----------
  function encontrarPossiveisDuplicatas(nome, telefone, pessoas) {
    const telNorm = Utils.normalizarTelefone(telefone);
    return pessoas.filter((p) => {
      if (p.arquivadoEm) return false;
      const mesmoTelefone = telNorm && (Utils.normalizarTelefone(p.telefone) === telNorm || Utils.normalizarTelefone(p.whatsapp) === telNorm);
      const nomeParecido = Utils.nomesParecidos(p.nomeCompleto, nome);
      return mesmoTelefone || nomeParecido;
    });
  }

  /**
   * Uma pessoa "tem histórico relacionado" se aparece em algum encontro
   * (presença/elegibilidade/visita), pedido de oração ou acompanhamento.
   * Nesse caso, excluir de verdade destruiria estatísticas antigas —
   * a opção passa a ser anonimizar, não excluir. Usado aqui e na Lixeira.
   */
  function temHistoricoRelacionado(pessoaId, state) {
    const emEncontro = state.encontros.some(
      (e) => (e.participantesElegiveis || []).includes(pessoaId) || (e.visitantesIds || []).includes(pessoaId) || (e.presenca && pessoaId in e.presenca)
    );
    const emOracao = state.oracaoVisivel.some((o) => o.pessoaId === pessoaId) || state.oracaoPrivado.some((o) => o.pessoaId === pessoaId);
    const emAcompanhamento = state.acompanhamento.some((a) => a.pessoaId === pessoaId);
    return emEncontro || emOracao || emAcompanhamento;
  }

  async function anonimizar(pessoa) {
    if (!confirm(`Anonimizar ${pessoa.nomeCompleto}? Nome, contato e observações pessoais serão apagados PARA SEMPRE (isso não pode ser desfeito, nem por um administrador). O histórico de presença é preservado, sem nome associado.`)) return;
    try {
      await Api.update("pessoas", pessoa.id, {
        nomeCompleto: "Pessoa anonimizada",
        apelido: "",
        telefone: "",
        whatsapp: "",
        email: "",
        fotoUrl: "",
        observacoes: "",
        convidadoPor: "",
        anonimizadoEm: Utils.todayISO(),
      });
      Utils.toast("Dados pessoais anonimizados.");
      Utils.closeModal();
      App.navigate("pessoas");
      App.reloadData();
    } catch (e) {
      Utils.toast("Sem permissão para anonimizar.", "error");
    }
  }

  function openForm(pessoa, state, session) {
    const isEdit = !!pessoa;
    const podeArquivar = isEdit && Permissoes.pode(session.papel, "arquivarPessoas");
    const podeAnonimizarOuExcluir = isEdit && Permissoes.pode(session.papel, "excluirDefinitivamente");
    const temHistorico = isEdit && temHistoricoRelacionado(pessoa.id, state);

    const modal = Utils.openModal(`
      <div class="modal-title">${isEdit ? "Editar pessoa" : "Nova pessoa"}</div>
      <div class="field"><label>Nome completo</label><input id="fNome" value="${pessoa ? Utils.escapeHtml(pessoa.nomeCompleto) : ""}" /></div>
      <div class="field"><label>Como gosta de ser chamado</label><input id="fApelido" value="${pessoa ? Utils.escapeHtml(pessoa.apelido || "") : ""}" /></div>
      <div class="field-row">
        <div class="field"><label>Telefone</label><input id="fTelefone" value="${pessoa ? Utils.escapeHtml(pessoa.telefone || "") : ""}" /></div>
        <div class="field"><label>WhatsApp</label><input id="fWhatsapp" value="${pessoa ? Utils.escapeHtml(pessoa.whatsapp || "") : ""}" /></div>
      </div>
      <div class="field"><label>E-mail</label><input id="fEmail" value="${pessoa ? Utils.escapeHtml(pessoa.email || "") : ""}" /></div>
      <div class="field-row">
        <div class="field">
          <label>Nascimento (opcional)</label>
          <input type="date" id="fNascimento" value="${pessoa ? pessoa.nascimento || "" : ""}" />
          <div class="field-error" id="erroNascimento"></div>
        </div>
        <div class="field">
          <label>Chegou ao GC em (opcional)</label>
          <input type="date" id="fChegouEm" value="${pessoa ? pessoa.chegouEm || "" : ""}" />
          <div class="field-error" id="erroChegouEm"></div>
        </div>
      </div>
      <div class="field"><label>Convidado por</label><input id="fConvidadoPor" value="${pessoa ? Utils.escapeHtml(pessoa.convidadoPor || "") : ""}" /></div>
      <div class="field"><label>Situação</label>
        <select id="fSituacao">${SITUACOES.map((s) => `<option value="${s}" ${pessoa && pessoa.situacao === s ? "selected" : ""}>${Utils.capitalize(s)}</option>`).join("")}</select>
      </div>
      <div class="foto-picker">
        <label for="fFoto" class="foto-circle" id="fotoCircle">
          ${pessoa && pessoa.fotoUrl ? `<img src="${Utils.sanitizarUrl(pessoa.fotoUrl)}" alt="" />` : Utils.astronautIcon()}
          <span class="foto-edit-badge">✎</span>
        </label>
        <label for="fFoto" class="foto-label">${pessoa && pessoa.fotoUrl ? "Trocar foto" : "Adicionar foto"}</label>
        <input type="file" id="fFoto" accept="image/*" />
      </div>
      <div class="field"><label>Observações</label><textarea id="fObs">${pessoa ? Utils.escapeHtml(pessoa.observacoes || "") : ""}</textarea></div>
      <div id="duplicatasAviso"></div>
      <button class="btn btn-primary btn-block" id="salvarPessoaBtn">Salvar</button>
      ${podeArquivar ? `<button class="btn btn-danger btn-block" style="margin-top:10px;" id="arquivarPessoaBtn">Arquivar (mover para a lixeira)</button>` : ""}
      ${
        podeAnonimizarOuExcluir && temHistorico
          ? `<button class="btn btn-danger btn-block" style="margin-top:10px;" id="anonimizarBtn">Anonimizar dados pessoais</button>`
          : podeAnonimizarOuExcluir
          ? `<button class="btn btn-danger btn-block" style="margin-top:10px;" id="excluirDefBtn">Excluir definitivamente</button>`
          : ""
      }
    `);

    function validarCampoData(inputId, erroId, { proibirFutura }) {
      const valor = document.getElementById(inputId).value;
      const resultado = Utils.validarDataOpcional(valor, { proibirFutura });
      document.getElementById(erroId).textContent = resultado.valido ? "" : resultado.motivo;
      return resultado;
    }

    ["fNascimento", "fChegouEm"].forEach((id) => {
      document.getElementById(id).addEventListener("change", () => {
        if (id === "fNascimento") validarCampoData("fNascimento", "erroNascimento", { proibirFutura: true });
        else validarCampoData("fChegouEm", "erroChegouEm", { proibirFutura: false });
      });
    });

    document.getElementById("fFoto").addEventListener("change", (e) => {
      const arquivo = e.target.files && e.target.files[0];
      if (!arquivo) return;
      const leitor = new FileReader();
      leitor.onload = () => {
        document.getElementById("fotoCircle").innerHTML = `<img src="${leitor.result}" alt="" /><span class="foto-edit-badge">✎</span>`;
      };
      leitor.readAsDataURL(arquivo);
    });

    document.getElementById("salvarPessoaBtn").addEventListener("click", async () => {
      const nome = document.getElementById("fNome").value.trim();
      if (!nome) return Utils.toast("Informe o nome.", "error");
      const telefone = document.getElementById("fTelefone").value.trim();

      const validNascimento = validarCampoData("fNascimento", "erroNascimento", { proibirFutura: true });
      const validChegouEm = validarCampoData("fChegouEm", "erroChegouEm", { proibirFutura: false });
      if (!validNascimento.valido || !validChegouEm.valido) {
        Utils.toast("Corrija as datas destacadas antes de salvar.", "error");
        return;
      }

      if (!isEdit) {
        const duplicatas = encontrarPossiveisDuplicatas(nome, telefone, state.pessoas);
        const jaConfirmou = modal.dataset.duplicataConfirmada === "1";
        if (duplicatas.length && !jaConfirmou) {
          document.getElementById("duplicatasAviso").innerHTML = `
            <div class="card" style="border-color:var(--gold);margin-bottom:14px;">
              <div style="font-weight:700;margin-bottom:8px;">Pessoas parecidas já cadastradas</div>
              ${duplicatas.map((d) => `<div class="text-dim" style="font-size:13px;margin-bottom:4px;">• ${Utils.escapeHtml(d.nomeCompleto)}${d.telefone ? " · " + Utils.escapeHtml(d.telefone) : ""}</div>`).join("")}
              <div style="font-size:12.5px;margin-top:8px;color:var(--text-dim);">Confira se não é a mesma pessoa antes de continuar.</div>
            </div>`;
          modal.dataset.duplicataConfirmada = "1";
          Utils.toast("Confira as possíveis duplicatas antes de salvar de novo.", "error");
          return;
        }
      }

      const novaSituacao = document.getElementById("fSituacao").value;
      const situacaoHistorico = pessoa ? [...(pessoa.situacaoHistorico || [])] : [];
      if (!pessoa || pessoa.situacao !== novaSituacao) {
        situacaoHistorico.push({ situacao: novaSituacao, data: Utils.todayISO() });
      }

      const obj = {
        nomeCompleto: nome,
        apelido: document.getElementById("fApelido").value.trim(),
        telefone,
        whatsapp: document.getElementById("fWhatsapp").value.trim(),
        email: document.getElementById("fEmail").value.trim(),
        convidadoPor: document.getElementById("fConvidadoPor").value.trim(),
        situacao: novaSituacao,
        situacaoHistorico,
        observacoes: document.getElementById("fObs").value.trim(),
      };
      // Datas opcionais: se vazias, não mandamos string vazia — omitimos
      // na criação, ou mandamos null na edição pra REMOVER o campo (em
      // vez de gravar "" no banco).
      const valNascimento = document.getElementById("fNascimento").value;
      const valChegouEm = document.getElementById("fChegouEm").value;
      if (valNascimento) obj.nascimento = valNascimento;
      else if (isEdit && pessoa.nascimento) obj.nascimento = null;
      if (valChegouEm) obj.chegouEm = valChegouEm;
      else if (isEdit && pessoa.chegouEm) obj.chegouEm = null;

      if (pessoa && pessoa.fotoUrl) obj.fotoUrl = pessoa.fotoUrl;

      try {
        const fotoInput = document.getElementById("fFoto");
        let pessoaId = pessoa ? pessoa.id : null;
        if (isEdit) await Api.update("pessoas", pessoa.id, obj);
        else pessoaId = await Api.push("pessoas", obj);

        if (fotoInput.files && fotoInput.files[0] && typeof firebase !== "undefined" && firebase.storage) {
          try {
            const arquivo = fotoInput.files[0];
            const caminho = `${CONFIG.ROOT_PATH}/pessoas/${pessoaId}/foto.jpg`;
            const ref = firebase.storage().ref(caminho);
            await ref.put(arquivo);
            const url = await ref.getDownloadURL();
            await Api.update("pessoas", pessoaId, { fotoUrl: url });
          } catch (e) {
            Utils.toast("Pessoa salva, mas a foto não pôde ser enviada.", "error");
          }
        }

        Utils.toast("Pessoa salva!");
        Utils.closeModal();
        App.reloadData();
      } catch (e) {
        Utils.toast(e.code === "PERMISSION_DENIED" ? "Sem permissão para esta ação." : "Erro ao salvar. Confira os campos e tente novamente.", "error");
      }
    });

    if (podeArquivar) {
      document.getElementById("arquivarPessoaBtn").addEventListener("click", async () => {
        if (!confirm(`Arquivar ${pessoa.nomeCompleto}? Ela vai para a lixeira e pode ser restaurada depois.`)) return;
        try {
          await Api.update("pessoas", pessoa.id, { arquivadoEm: Utils.todayISO() });
          Utils.toast("Pessoa arquivada.");
          Utils.closeModal();
          App.navigate("pessoas");
          App.reloadData();
        } catch (e) {
          Utils.toast("Sem permissão para arquivar.", "error");
        }
      });
    }

    if (podeAnonimizarOuExcluir && temHistorico) {
      document.getElementById("anonimizarBtn").addEventListener("click", () => anonimizar(pessoa));
    } else if (podeAnonimizarOuExcluir) {
      document.getElementById("excluirDefBtn").addEventListener("click", async () => {
        if (!confirm(`Excluir ${pessoa.nomeCompleto} definitivamente? Esta pessoa não tem histórico relacionado, então isso é seguro — mas não pode ser desfeito.`)) return;
        try {
          await Api.remove("pessoas", pessoa.id);
          Utils.toast("Excluída definitivamente.");
          Utils.closeModal();
          App.navigate("pessoas");
          App.reloadData();
        } catch (e) {
          Utils.toast("Sem permissão para excluir definitivamente.", "error");
        }
      });
    }
  }

  return { render, renderDetail, openForm, encontrarPossiveisDuplicatas, temHistoricoRelacionado, anonimizar, SITUACOES };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = Pessoas;
}
