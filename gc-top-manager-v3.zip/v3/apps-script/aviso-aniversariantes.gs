/**
 * AVISO DE ANIVERSARIANTES — GC Top Manager (v3)
 * ---------------------------------------------------------------
 * NOVIDADES NESTA REVISÃO (correções de robustez):
 *
 * 1) Toda chamada HTTP ao Firebase agora CONFERE o código de status.
 *    Se não vier 200-299, a função lança erro — nunca segue em frente
 *    como se tivesse dado certo silenciosamente.
 *
 * 2) Reserva atômica antes de enviar: usamos o suporte a ETag da REST
 *    API do Realtime Database (cabeçalho X-Firebase-ETag / if-match)
 *    pra garantir que, mesmo se a função rodar duas vezes "ao mesmo
 *    tempo" (ex.: execução anterior atrasada + gatilho novo disparando),
 *    só uma delas consegue reservar o envio de cada aviso. Isso é o
 *    equivalente a uma transação, usando só a REST API.
 *
 * 3) Estados explícitos por aviso: reservado → enviando → sucesso |
 *    erro | incerto. "Incerto" quer dizer "o e-mail pode ter sido
 *    enviado, mas não conseguimos confirmar o registro no Firebase" —
 *    nesse caso a função NUNCA reenvia sozinha; ela loga um alerta
 *    (e tenta te avisar por e-mail) pra revisão manual.
 *
 * 4) Horário do aviso: o gatilho de tempo deve rodar A CADA 15 MINUTOS
 *    (não mais uma vez por dia num horário fixo do próprio gatilho).
 *    A cada execução, a função lê o horário configurado no app
 *    (config.avisoAniversario.horario) e só processa o envio do dia se
 *    o horário atual (America/Sao_Paulo) estiver dentro da janela de
 *    15 minutos a partir daquele horário. Fora da janela, a execução
 *    não faz nada (fica barata, pode rodar o dia todo sem problema).
 *
 * CONFIGURAÇÃO — igual à v2, resumindo:
 * 1. Firebase Authentication → crie automacao@seu-dominio.com.
 * 2. Realtime Database → defina manualmente
 *    /gcTopManager/usuarios/{uid-da-automacao}/papel = "automacao".
 * 3. script.google.com → cole este código.
 * 4. Propriedades do script: FIREBASE_API_KEY, FIREBASE_DATABASE_URL,
 *    AUTOMACAO_EMAIL, AUTOMACAO_SENHA.
 * 5. Gatilho de tempo para `enviarAvisosDeAniversario`: A CADA 15
 *    MINUTOS (não mais "timer diário"). Gatilho separado pra
 *    `processarFilaTeste`, também a cada 10-15 min.
 * 6. Rode qualquer função manualmente uma vez pra autorizar Gmail e
 *    UrlFetchApp.
 */

function getProp_(nome) {
  const valor = PropertiesService.getScriptProperties().getProperty(nome);
  if (!valor) throw new Error(`Propriedade do script não configurada: ${nome}`);
  return valor;
}

function autenticar_() {
  const apiKey = getProp_("FIREBASE_API_KEY");
  const email = getProp_("AUTOMACAO_EMAIL");
  const senha = getProp_("AUTOMACAO_SENHA");
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`;
  const res = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify({ email, password: senha, returnSecureToken: true }),
    muteHttpExceptions: true,
  });
  if (res.getResponseCode() < 200 || res.getResponseCode() >= 300) {
    throw new Error(`Falha ao autenticar a conta de automação (status ${res.getResponseCode()}): ${res.getContentText()}`);
  }
  const json = JSON.parse(res.getContentText());
  if (!json.idToken) throw new Error("Autenticação sem idToken na resposta: " + res.getContentText());
  return json.idToken;
}

function dbUrl_(caminho, idToken) {
  const base = getProp_("FIREBASE_DATABASE_URL");
  const sep = caminho.indexOf("?") >= 0 ? "&" : "?";
  return `${base}/gcTopManager/${caminho}.json${sep}auth=${idToken}`;
}

/** GET simples — lança erro se o status não for 2xx. */
function dbGet_(caminho, idToken) {
  const res = UrlFetchApp.fetch(dbUrl_(caminho, idToken), { muteHttpExceptions: true });
  const status = res.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(`Firebase GET falhou (status ${status}) em "${caminho}": ${res.getContentText()}`);
  }
  const texto = res.getContentText();
  return texto && texto !== "null" ? JSON.parse(texto) : null;
}

/** GET com ETag — usado antes de reservar um envio (comparação atômica). */
function dbGetComETag_(caminho, idToken) {
  const res = UrlFetchApp.fetch(dbUrl_(caminho, idToken), {
    muteHttpExceptions: true,
    headers: { "X-Firebase-ETag": "true" },
  });
  const status = res.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(`Firebase GET (ETag) falhou (status ${status}) em "${caminho}": ${res.getContentText()}`);
  }
  const etag = res.getHeaders()["ETag"] || res.getHeaders()["etag"];
  const texto = res.getContentText();
  const valor = texto && texto !== "null" ? JSON.parse(texto) : null;
  return { valor, etag };
}

/** PUT simples — lança erro se o status não for 2xx. */
function dbSet_(caminho, idToken, valor) {
  const res = UrlFetchApp.fetch(dbUrl_(caminho, idToken), {
    method: "put",
    contentType: "application/json",
    payload: JSON.stringify(valor),
    muteHttpExceptions: true,
  });
  const status = res.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(`Firebase PUT falhou (status ${status}) em "${caminho}": ${res.getContentText()}`);
  }
  return true;
}

/**
 * PUT condicional (compare-and-swap via if-match). Retorna:
 *   { sucesso: true }               — escreveu, ninguém mexeu antes
 *   { sucesso: false, conflito: true } — alguém já tinha mudado (412)
 * Qualquer outro status ainda é erro (lança exceção).
 */
function dbSetComETag_(caminho, idToken, valor, etagEsperado) {
  const res = UrlFetchApp.fetch(dbUrl_(caminho, idToken), {
    method: "put",
    contentType: "application/json",
    payload: JSON.stringify(valor),
    muteHttpExceptions: true,
    headers: { "if-match": etagEsperado },
  });
  const status = res.getResponseCode();
  if (status === 412) return { sucesso: false, conflito: true };
  if (status < 200 || status >= 300) {
    throw new Error(`Firebase PUT condicional falhou (status ${status}) em "${caminho}": ${res.getContentText()}`);
  }
  return { sucesso: true };
}

function dbRemove_(caminho, idToken) {
  const res = UrlFetchApp.fetch(dbUrl_(caminho, idToken), { method: "delete", muteHttpExceptions: true });
  const status = res.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(`Firebase DELETE falhou (status ${status}) em "${caminho}": ${res.getContentText()}`);
  }
  return true;
}

function tentarComRetry_(fn, tentativas, esperaMs) {
  let ultimoErro;
  for (let i = 0; i < tentativas; i++) {
    try {
      return fn();
    } catch (e) {
      ultimoErro = e;
      if (i < tentativas - 1) Utilities.sleep(esperaMs);
    }
  }
  throw ultimoErro;
}

function agoraSP_() {
  return Utilities.formatDate(new Date(), "America/Sao_Paulo", "yyyy-MM-dd HH:mm:ss");
}

function hojeSP_() {
  return Utilities.formatDate(new Date(), "America/Sao_Paulo", "yyyy-MM-dd");
}

function horaAtualSP_() {
  return Utilities.formatDate(new Date(), "America/Sao_Paulo", "HH:mm");
}

function minutosDesdeMeiaNoite_(horaHHMM) {
  const partes = horaHHMM.split(":").map(Number);
  return partes[0] * 60 + partes[1];
}

/** A execução está dentro da janela de 15 min a partir do horário configurado? */
function dentroDaJanelaDeEnvio_(horarioConfigurado) {
  if (!horarioConfigurado) return true; // sem horário configurado — não bloqueia (comportamento antigo)
  const configMin = minutosDesdeMeiaNoite_(horarioConfigurado);
  const agoraMin = minutosDesdeMeiaNoite_(horaAtualSP_());
  return agoraMin >= configMin && agoraMin < configMin + 15;
}

function ehBissexto_(ano) {
  return (ano % 4 === 0 && ano % 100 !== 0) || ano % 400 === 0;
}

function diasAteAniversario_(nascimentoISO, hojeISO) {
  const partes = nascimentoISO.split("-").map(Number);
  const mes = partes[1];
  const dia = partes[2];
  const anoHoje = Number(hojeISO.split("-")[0]);

  function aniversarioNoAno(ano) {
    if (mes === 2 && dia === 29 && !ehBissexto_(ano)) return new Date(ano, 1, 28);
    return new Date(ano, mes - 1, dia);
  }

  const hoje = new Date(hojeISO + "T00:00:00");
  let candidato = aniversarioNoAno(anoHoje);
  let diff = Math.round((candidato - hoje) / 86400000);
  if (diff < 0) {
    candidato = aniversarioNoAno(anoHoje + 1);
    diff = Math.round((candidato - hoje) / 86400000);
  }
  return diff;
}

/**
 * Envia (com reserva atômica) o aviso de uma pessoa/antecedência.
 * Devolve o status final: "sucesso" | "erro" | "incerto" | "ignorado".
 */
function processarAvisoDaPessoa_(idToken, pessoaId, pessoa, dias, ano, config) {
  const chave = `${pessoaId}_${ano}_${dias}`;
  const caminho = `avisosEnviados/${chave}`;

  let atual;
  try {
    atual = dbGetComETag_(caminho, idToken);
  } catch (e) {
    Logger.log(`Erro ao consultar reserva de ${chave}: ${e}`);
    return "erro";
  }

  if (atual.valor && atual.valor.status === "sucesso") return "ignorado"; // já enviado
  if (atual.valor && atual.valor.status === "incerto") return "ignorado"; // exige revisão manual, não mexe sozinho
  if (atual.valor && atual.valor.status === "enviando") {
    return "ignorado"; // execução concorrente possivelmente em andamento
  }

  const reserva = dbSetComETag_(
    caminho,
    idToken,
    { pessoaId, ano, dias, status: "reservado", reservadoEm: agoraSP_() },
    atual.etag
  );
  if (!reserva.sucesso) return "ignorado"; // alguém reservou entre o GET e o PUT

  try {
    dbSet_(caminho, idToken, { pessoaId, ano, dias, status: "enviando", reservadoEm: agoraSP_() });
  } catch (e) {
    Logger.log(`Não consegui marcar "enviando" para ${chave}: ${e}`);
    return "erro";
  }

  const primeiroNome = (pessoa.apelido || pessoa.nomeCompleto || "").split(" ")[0];
  const dataFormatada = pessoa.nascimento.split("-").slice(1).reverse().join("/");
  let mensagem;
  if (dias === 0) mensagem = `Hoje é aniversário de ${primeiroNome} 🎉`;
  else if (dias === 1) mensagem = `Amanhã é aniversário de ${primeiroNome} 🎉`;
  else mensagem = `Aniversário chegando 🎂\n\n${pessoa.nomeCompleto} faz aniversário no dia ${dataFormatada}.\nFaltam ${dias} dias.`;

  try {
    GmailApp.sendEmail(config.email, `Aniversário: ${pessoa.nomeCompleto}`, mensagem, { name: "GC Top Manager" });
  } catch (e) {
    try {
      dbSet_(caminho, idToken, { pessoaId, ano, dias, status: "erro", erro: String(e), enviadoEm: agoraSP_() });
    } catch (e2) {
      Logger.log(`Falha dupla (envio e registro) para ${chave}: ${e2}`);
    }
    return "erro";
  }

  try {
    tentarComRetry_(() => dbSet_(caminho, idToken, { pessoaId, ano, dias, status: "sucesso", enviadoEm: agoraSP_() }), 3, 1500);
    return "sucesso";
  } catch (e) {
    Logger.log(`AVISO INCERTO: e-mail de ${chave} foi enviado, mas não consegui confirmar o registro no Firebase: ${e}`);
    try {
      dbSet_(caminho, idToken, { pessoaId, ano, dias, status: "incerto", erro: String(e), enviadoEm: agoraSP_() });
    } catch (e2) {
      Logger.log(`Não consegui nem marcar "incerto" para ${chave} — revise manualmente em /avisosEnviados/${chave}. Erro: ${e2}`);
    }
    try {
      if (config.email) {
        GmailApp.sendEmail(
          config.email,
          "GC Top Manager — revisão manual necessária",
          `O aviso de aniversário de ${pessoa.nomeCompleto} (chave ${chave}) foi enviado, mas o registro no banco não pôde ser confirmado. Por favor revise manualmente em /avisosEnviados/${chave} antes que a automação rode de novo, pra evitar envio duplicado.`,
          { name: "GC Top Manager" }
        );
      }
    } catch (e3) {
      Logger.log("Não consegui nem enviar o e-mail de alerta de revisão manual: " + e3);
    }
    return "incerto";
  }
}

function enviarAvisosDeAniversario() {
  const idToken = autenticar_();
  const config = dbGet_("config/avisoAniversario", idToken);
  if (!config || !config.email) {
    Logger.log("Sem e-mail configurado — nada a fazer.");
    return;
  }

  if (!dentroDaJanelaDeEnvio_(config.horario)) {
    return;
  }

  const antecedencia = config.antecedencia || { 7: true, 3: true, 1: true, 0: true };
  const pessoas = dbGet_("pessoas", idToken) || {};
  const hojeISO = hojeSP_();
  const ano = Number(hojeISO.slice(0, 4));

  let sucesso = 0, erro = 0, incerto = 0, ignorado = 0;

  Object.entries(pessoas).forEach(([pessoaId, pessoa]) => {
    if (!pessoa.nascimento || pessoa.arquivadoEm || pessoa.anonimizadoEm) return;
    const dias = diasAteAniversario_(pessoa.nascimento, hojeISO);
    if (!antecedencia[dias] && !antecedencia[String(dias)]) return;

    const resultado = processarAvisoDaPessoa_(idToken, pessoaId, pessoa, dias, ano, config);
    if (resultado === "sucesso") sucesso++;
    else if (resultado === "erro") erro++;
    else if (resultado === "incerto") incerto++;
    else ignorado++;
  });

  Logger.log(`Aviso de aniversário — sucesso: ${sucesso}, erro: ${erro}, incerto: ${incerto}, ignorado (já tratado): ${ignorado}`);
}

/**
 * Processa pedidos de "enviar e-mail de teste" (gravados em /filaTeste
 * pelo app). Roda num gatilho de 10-15 min, ou manualmente pelo editor.
 */
function processarFilaTeste() {
  const idToken = autenticar_();
  const fila = dbGet_("filaTeste", idToken) || {};
  Object.entries(fila).forEach(([id, pedido]) => {
    const destinatario = pedido.destinatario;
    if (destinatario) {
      try {
        GmailApp.sendEmail(
          destinatario,
          "GC Top Manager — e-mail de teste",
          "Este é um e-mail de teste do aviso de aniversariantes. Se você recebeu isto, a automação está funcionando corretamente.",
          { name: "GC Top Manager" }
        );
      } catch (e) {
        Logger.log("Falha ao enviar teste: " + e);
        return;
      }
    }
    try {
      dbRemove_(`filaTeste/${id}`, idToken);
    } catch (e) {
      Logger.log(`E-mail de teste enviado, mas não consegui limpar a fila (${id}): ${e}`);
    }
  });
}
