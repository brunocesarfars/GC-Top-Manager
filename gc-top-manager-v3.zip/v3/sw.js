/**
 * SERVICE WORKER — cache apenas do "casco" estático do app (HTML, CSS,
 * JS, manifest). NUNCA cacheia respostas do Firebase (dados de
 * pessoas, presença, oração, acompanhamento etc.) — essas requisições
 * são explicitamente ignoradas abaixo e sempre vão direto pra rede.
 * Isso é intencional: dados pastorais sensíveis não devem sobreviver
 * num cache do navegador depois que a pessoa sai do app.
 */

const CACHE_NAME = "gc-top-manager-shell-v5";
const ARQUIVOS_DO_CASCO = [
  "./",
  "./index.html",
  "./css/style.css",
  "./manifest.json",
  "./icons/favicon.ico",
  "./icons/icon-16.png",
  "./icons/icon-32.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-512-maskable.png",
  "./icons/apple-touch-icon.png",
  "./assets/images/login-background.webp",
  "./assets/images/login-background.png",
  "./assets/images/default-astronaut-avatar.webp",
  "./assets/images/gc-top-logo.webp",
  "./assets/images/loading-mascot.webp",
  "./assets/images/bible-card-background.webp",
  "./assets/icons/gc-top/icon-home.webp",
  "./assets/icons/gc-top/icon-people.webp",
  "./assets/icons/gc-top/icon-meetings.webp",
  "./assets/icons/gc-top/icon-pulpit.webp",
  "./assets/icons/gc-top/icon-more.webp",
  "./assets/icons/gc-top/icon-birthdays.webp",
  "./assets/icons/gc-top/icon-visitors.webp",
  "./assets/icons/gc-top/icon-pastoral-care.webp",
  "./assets/icons/gc-top/icon-prayer.webp",
  "./assets/icons/gc-top/icon-bible-map.webp",
  "./assets/icons/gc-top/icon-users-permissions.webp",
  "./assets/icons/gc-top/icon-trash.webp",
  "./js/firebase-config.js",
  "./js/datetime.js",
  "./js/logica-pura.js",
  "./js/permissoes.js",
  "./js/utils.js",
  "./js/gc-icons.js",
  "./js/versiculos.js",
  "./js/auth.js",
  "./js/api.js",
  "./js/dashboard.js",
  "./js/pessoas.js",
  "./js/encontros.js",
  "./js/aniversariantes.js",
  "./js/visitantes.js",
  "./js/cuidado.js",
  "./js/pulpito.js",
  "./js/usuarios.js",
  "./js/lixeira.js",
  "./js/app.js",
  "./js/sw-register.js",
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(ARQUIVOS_DO_CASCO)));
  // Nota: NÃO chamamos skipWaiting() aqui de propósito — o service worker
  // novo fica "esperando" até a pessoa confirmar a atualização (ver
  // js/sw-register.js), pra evitar trocar o app debaixo dela no meio do uso.
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((chaves) => Promise.all(chaves.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Qualquer coisa que não seja do próprio domínio do app (Firebase,
  // Google Fonts, etc.) passa direto pra rede — nunca é interceptada
  // nem cacheada aqui.
  if (url.origin !== self.location.origin) return;

  // Só GET de arquivos estáticos entra no cache-first. Tudo mais
  // (nenhuma chamada de dados passa por rotas do próprio domínio nesta
  // arquitetura, mas por segurança) vai direto pra rede.
  if (event.request.method !== "GET") return;

  event.respondWith(
    caches.match(event.request).then((cacheado) => cacheado || fetch(event.request))
  );
});
