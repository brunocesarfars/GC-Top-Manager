/**
 * CRIAR USUÁRIOS — script local, para rodar UMA VEZ na sua máquina
 * (nunca no navegador, nunca publicado em lugar nenhum).
 *
 * Por que isto é necessário: as regras do banco (de propósito) não
 * deixam ninguém escrever o próprio papel em /usuarios/{uid}/papel —
 * nem um admin. Só o Admin SDK (que roda com uma "chave mestra" e
 * ignora as regras) pode fazer essa configuração inicial. Depois de
 * Bruno e Fran existirem, o admin pode gerenciar OUTROS usuários pela
 * própria tela do app (Mais → Usuários e permissões).
 *
 * COMO USAR:
 * 1. No console do Firebase → Configurações do projeto → Contas de
 *    serviço → "Gerar nova chave privada". Salve o JSON baixado como
 *    `scripts/serviceAccountKey.json` (NÃO comite este arquivo em
 *    lugar nenhum — adicione ao .gitignore).
 * 2. `npm install firebase-admin` (na pasta do projeto).
 * 3. Rode:
 *      node scripts/criar-usuarios.js bruno@seudominio.com "senhaForte123!" "Bruno" admin
 *      node scripts/criar-usuarios.js fran@seudominio.com  "outraSenhaForte!" "Fran"  lideranca
 * 4. Apague o arquivo serviceAccountKey.json do seu computador depois
 *    de usar, se preferir — ele só é necessário para rodar este script.
 */

const path = require("path");

const [, , email, senha, nome, papel] = process.argv;

if (!email || !senha || !nome || !papel) {
  console.log("Uso: node scripts/criar-usuarios.js <email> <senha> <nome> <admin|lideranca>");
  process.exit(1);
}
if (!["admin", "lideranca"].includes(papel)) {
  console.log('Papel inválido. Use "admin" ou "lideranca".');
  process.exit(1);
}

let admin;
try {
  admin = require("firebase-admin");
} catch {
  console.log('Faltando dependência. Rode: npm install firebase-admin');
  process.exit(1);
}

let serviceAccount;
try {
  serviceAccount = require(path.join(__dirname, "serviceAccountKey.json"));
} catch {
  console.log("Não encontrei scripts/serviceAccountKey.json — baixe a chave de conta de serviço no console do Firebase primeiro.");
  process.exit(1);
}

const DATABASE_URL = process.env.FIREBASE_DATABASE_URL || "https://SUBSTITUA.firebaseio.com";
const ROOT_PATH = "gcTopManager";

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: DATABASE_URL,
});

async function main() {
  let userRecord;
  try {
    userRecord = await admin.auth().createUser({ email, password: senha, displayName: nome });
    console.log(`Conta criada: ${userRecord.uid}`);
  } catch (e) {
    if (e.code === "auth/email-already-exists") {
      userRecord = await admin.auth().getUserByEmail(email);
      console.log(`Conta já existia, reaproveitando uid: ${userRecord.uid}`);
    } else {
      throw e;
    }
  }

  await admin.database().ref(`${ROOT_PATH}/usuarios/${userRecord.uid}`).update({ papel, nome });
  console.log(`Papel "${papel}" atribuído a ${email}.`);
  process.exit(0);
}

main().catch((e) => {
  console.error("Erro:", e.message || e);
  process.exit(1);
});
