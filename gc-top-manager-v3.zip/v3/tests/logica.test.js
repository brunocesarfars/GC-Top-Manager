/**
 * TESTES — rodar com: node tests/logica.test.js
 * Sem dependências externas (usa apenas assert do Node).
 */
const assert = require("assert");
const path = require("path");
const DateUtil = require(path.join(__dirname, "../js/datetime.js"));
const Logica = require(path.join(__dirname, "../js/logica-pura.js"));

let passou = 0;
let falhou = 0;

function teste(nome, fn) {
  try {
    fn();
    console.log(`✅ ${nome}`);
    passou++;
  } catch (e) {
    console.log(`❌ ${nome}`);
    console.log("   " + e.message);
    falhou++;
  }
}

// ---------------------------------------------------------------
// DateUtil
// ---------------------------------------------------------------

teste("diasEntre — mesma data é 0", () => {
  assert.strictEqual(DateUtil.diasEntre("2026-09-13", "2026-09-13"), 0);
});

teste("diasEntre — vira o ano corretamente (31/12 -> 01/01)", () => {
  assert.strictEqual(DateUtil.diasEntre("2026-12-31", "2027-01-01"), 1);
});

teste("diasAteProximoAniversario — daqui a 7 dias", () => {
  const hoje = "2026-09-13";
  const nasc = "1990-09-20";
  assert.strictEqual(DateUtil.diasAteProximoAniversario(nasc, hoje), 7);
});

teste("diasAteProximoAniversario — já passou este ano, calcula pro ano que vem", () => {
  const hoje = "2026-09-13";
  const nasc = "1990-01-10";
  const dias = DateUtil.diasAteProximoAniversario(nasc, hoje);
  assert.strictEqual(dias, DateUtil.diasEntre(hoje, "2027-01-10"));
});

teste("diasAteProximoAniversario — 29 de fevereiro em ano não bissexto vira 28/fev", () => {
  const hoje = "2026-02-01"; // 2026 não é bissexto
  const nasc = "2000-02-29";
  const dias = DateUtil.diasAteProximoAniversario(nasc, hoje);
  assert.strictEqual(dias, DateUtil.diasEntre(hoje, "2026-02-28"));
});

teste("diasAteProximoAniversario — 29 de fevereiro em ano bissexto respeita o dia 29", () => {
  const hoje = "2028-01-01"; // 2028 é bissexto
  const nasc = "2000-02-29";
  const dias = DateUtil.diasAteProximoAniversario(nasc, hoje);
  assert.strictEqual(dias, DateUtil.diasEntre(hoje, "2028-02-29"));
});

teste("ehBissexto — regra dos séculos (1900 não é, 2000 é)", () => {
  assert.strictEqual(DateUtil.ehBissexto(1900), false);
  assert.strictEqual(DateUtil.ehBissexto(2000), true);
  assert.strictEqual(DateUtil.ehBissexto(2024), true);
  assert.strictEqual(DateUtil.ehBissexto(2026), false);
});

// ---------------------------------------------------------------
// Presença — snapshot de elegíveis
// ---------------------------------------------------------------

const pessoasBase = [
  { id: "a", situacao: "membro", chegouEm: "2020-01-01" },
  { id: "b", situacao: "membro", chegouEm: "2026-09-01" }, // chegou depois de alguns encontros
  { id: "c", situacao: "visitante", chegouEm: "2026-01-01" }, // visitante não é elegível
  { id: "d", situacao: "membro", chegouEm: "2020-01-01", arquivadoEm: "2026-01-01" }, // arquivada
  { id: "e", situacao: "novo integrado", chegouEm: "2025-05-01" },
];

teste("calcularElegiveis — respeita data de chegada, situação e arquivamento", () => {
  const elegiveis = Logica.calcularElegiveis(pessoasBase, "2026-06-01");
  assert.deepStrictEqual(elegiveis.sort(), ["a", "e"]);
});

teste("calcularElegiveis — pessoa que chegou depois entra em encontros futuros", () => {
  const elegiveis = Logica.calcularElegiveis(pessoasBase, "2026-09-15");
  assert.deepStrictEqual(elegiveis.sort(), ["a", "b", "e"]);
});

teste("montarPresencaExplicita — nunca deixa undefined, desmarcado vira false", () => {
  const elegiveis = ["a", "b"];
  const parcial = { a: true }; // b não veio no parcial (foi desmarcado na tela)
  const resultado = Logica.montarPresencaExplicita(elegiveis, parcial, []);
  assert.strictEqual(resultado.a, true);
  assert.strictEqual(resultado.b, false);
  assert.notStrictEqual(resultado.b, undefined);
});

teste("calcularTotais — separa membros de visitantes corretamente", () => {
  const presenca = { a: true, b: false, v1: true, v2: false };
  const totais = Logica.calcularTotais(presenca, ["a", "b"], ["v1", "v2"]);
  assert.deepStrictEqual(totais, { totalMembrosPresentes: 1, totalVisitantesPresentes: 1, totalPresentes: 2 });
});

// ---------------------------------------------------------------
// Frequência
// ---------------------------------------------------------------

function encontro(data, elegiveis, presentes, visitantesIds = [], visitantesPresentes = []) {
  const presenca = {};
  elegiveis.forEach((id) => (presenca[id] = presentes.includes(id)));
  visitantesIds.forEach((id) => (presenca[id] = visitantesPresentes.includes(id)));
  return { data, participantesElegiveis: elegiveis, presenca, visitantesIds };
}

teste("frequenciaGeral — nunca ultrapassa 100% e ignora encontros futuros", () => {
  const hoje = "2026-09-13";
  const encontros = [
    encontro("2026-09-01", ["a", "b"], ["a", "b"]), // 100%
    encontro("2026-09-08", ["a", "b"], ["a", "b"]), // 100%
    encontro("2026-09-20", ["a", "b"], ["a", "b"]), // futuro — deve ser ignorado
  ];
  const resultado = Logica.frequenciaGeral(encontros, hoje);
  assert.strictEqual(resultado.percentual, 100);
  assert.strictEqual(resultado.somaElegiveis, 4); // só os 2 encontros passados, 2 elegíveis cada
});

teste("frequenciaGeral — visitante presente não infla a frequência dos membros", () => {
  const hoje = "2026-09-13";
  const encontros = [encontro("2026-09-01", ["a", "b"], ["a"], ["v1"], ["v1"])]; // 1 de 2 membros, + 1 visitante presente
  const resultado = Logica.frequenciaGeral(encontros, hoje);
  assert.strictEqual(resultado.somaElegiveis, 2);
  assert.strictEqual(resultado.somaPresentes, 1);
  assert.strictEqual(resultado.percentual, 50);
});

teste("frequenciaIndividual — só conta encontros para os quais a pessoa era elegível", () => {
  const hoje = "2026-09-13";
  const encontros = [
    encontro("2026-08-01", ["a"], ["a"]), // b não era elegível ainda
    encontro("2026-09-01", ["a", "b"], ["a"]), // b elegível, mas faltou
  ];
  const freqA = Logica.frequenciaIndividual("a", encontros, hoje);
  const freqB = Logica.frequenciaIndividual("b", encontros, hoje);
  assert.deepStrictEqual(freqA, { elegivel: 2, presente: 2, percentual: 100 });
  assert.deepStrictEqual(freqB, { elegivel: 1, presente: 0, percentual: 0 });
});

teste("frequenciaIndividual — nunca ultrapassa 100 mesmo com dados estranhos", () => {
  const hoje = "2026-09-13";
  // presença marcada para alguém fora da lista de elegíveis não deveria nem ser possível,
  // mas o cálculo tem que ser resiliente mesmo assim
  const encontros = [encontro("2026-09-01", ["a"], ["a", "fantasma"])];
  const freq = Logica.frequenciaIndividual("a", encontros, hoje);
  assert.ok(freq.percentual <= 100);
});

// ---------------------------------------------------------------
// Cuidado e acompanhamento
// ---------------------------------------------------------------

teste("identificarCuidado — 3 faltas consecutivas gera alerta", () => {
  const hoje = "2026-09-22";
  const pessoas = [{ id: "a", situacao: "membro", chegouEm: "2020-01-01" }];
  const encontros = [
    encontro("2026-09-01", ["a"], ["a"]),
    encontro("2026-09-08", ["a"], []),
    encontro("2026-09-15", ["a"], []),
    encontro("2026-09-20", ["a"], []),
  ];
  const alertas = Logica.identificarCuidado(pessoas, encontros, hoje);
  assert.strictEqual(alertas.length, 1);
  assert.strictEqual(alertas[0].faltasConsecutivas, 3);
});

teste("identificarCuidado — não alerta por encontros anteriores à entrada da pessoa", () => {
  const hoje = "2026-09-22";
  const pessoas = [{ id: "b", situacao: "membro", chegouEm: "2026-09-18" }];
  const encontros = [
    encontro("2026-09-01", ["a"], ["a"]),
    encontro("2026-09-08", ["a"], ["a"]),
    encontro("2026-09-20", ["a", "b"], ["a"]), // b faltou só neste, o único pro qual era elegível
  ];
  const alertas = Logica.identificarCuidado(pessoas, encontros, hoje);
  assert.strictEqual(alertas.length, 0, "1 falta não deveria gerar alerta ainda");
});

teste("identificarCuidado — não considera encontros futuros", () => {
  const hoje = "2026-09-13";
  const pessoas = [{ id: "a", situacao: "membro", chegouEm: "2020-01-01" }];
  const encontros = [
    encontro("2026-09-01", ["a"], ["a"]),
    encontro("2026-09-20", ["a"], []), // futuro
    encontro("2026-09-27", ["a"], []), // futuro
    encontro("2026-10-04", ["a"], []), // futuro
  ];
  const alertas = Logica.identificarCuidado(pessoas, encontros, hoje);
  assert.strictEqual(alertas.length, 0);
});

teste("identificarCuidado — nunca duplica a mesma pessoa", () => {
  const hoje = "2026-10-01";
  const pessoas = [{ id: "a", situacao: "membro", chegouEm: "2020-01-01" }];
  const encontros = [
    encontro("2026-08-01", ["a"], []),
    encontro("2026-08-08", ["a"], []),
    encontro("2026-08-15", ["a"], []),
    encontro("2026-08-22", ["a"], []),
  ];
  const alertas = Logica.identificarCuidado(pessoas, encontros, hoje);
  assert.strictEqual(alertas.length, 1);
});

teste("identificarCuidado — contato marcado como concluído não aparece mais", () => {
  const hoje = "2026-09-22";
  const pessoas = [{ id: "a", situacao: "membro", chegouEm: "2020-01-01" }];
  const encontros = [
    encontro("2026-09-01", ["a"], []),
    encontro("2026-09-08", ["a"], []),
    encontro("2026-09-15", ["a"], []),
  ];
  const semResolucao = Logica.identificarCuidado(pessoas, encontros, hoje, {});
  const comResolucao = Logica.identificarCuidado(pessoas, encontros, hoje, { a: { status: "concluido" } });
  assert.strictEqual(semResolucao.length, 1);
  assert.strictEqual(comResolucao.length, 0);
});

teste("identificarCuidado — 'adiado até' no futuro suprime o alerta até a data", () => {
  const hoje = "2026-09-22";
  const pessoas = [{ id: "a", situacao: "membro", chegouEm: "2020-01-01" }];
  const encontros = [
    encontro("2026-09-01", ["a"], []),
    encontro("2026-09-08", ["a"], []),
    encontro("2026-09-15", ["a"], []),
  ];
  const adiado = Logica.identificarCuidado(pessoas, encontros, hoje, { a: { status: "adiado", adiadoAte: "2026-10-01" } });
  assert.strictEqual(adiado.length, 0);
});

// ---------------------------------------------------------------

console.log(`\n${passou} passaram, ${falhou} falharam.`);
process.exit(falhou > 0 ? 1 : 0);
