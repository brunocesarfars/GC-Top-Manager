/**
 * TESTES DAS REGRAS DO FIREBASE — roda contra o Firebase Local
 * Emulator Suite (Realtime Database), não contra produção.
 *
 * COMO RODAR:
 *   1) npm install   (instala @firebase/rules-unit-testing e firebase)
 *   2) npx firebase emulators:exec --only database,auth "node --test tests/regras.rules.test.js"
 *
 * O comando acima sobe os emuladores, roda os testes, e derruba os
 * emuladores no final — não precisa deixar nada rodando manualmente.
 *
 * IMPORTANTE (leia antes de rodar): a primeira execução baixa o
 * emulador do Realtime Database (um .jar) de storage.googleapis.com.
 * Isso exige acesso normal à internet na sua máquina — não funciona
 * em redes corporativas que bloqueiam esse domínio.
 */

const test = require("node:test");
const assert = require("node:assert");
const fs = require("fs");
const path = require("path");
const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");

const PROJECT_ID = "demo-gctop-rules-test";
let testEnv;

test.before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    database: {
      rules: fs.readFileSync(path.join(__dirname, "../rules/database.rules.json"), "utf8"),
      host: "127.0.0.1",
      port: 9000,
    },
  });
});

test.after(async () => {
  if (testEnv) await testEnv.cleanup();
});

async function seed(fn) {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await fn(context.database());
  });
}

function ctxFran() {
  // Fran = liderança
  return testEnv.authenticatedContext("uid-fran").database();
}
function ctxBruno() {
  // Bruno = admin
  return testEnv.authenticatedContext("uid-bruno").database();
}
function ctxOutroAdmin() {
  return testEnv.authenticatedContext("uid-outro-admin").database();
}
function ctxAutomacao() {
  return testEnv.authenticatedContext("uid-automacao").database();
}
function ctxSemAuth() {
  // Equivalente a uma chamada REST sem ?auth=token
  return testEnv.unauthenticatedContext().database();
}

async function seedPapeis() {
  await seed(async (db) => {
    await db.ref("gcTopManager/usuarios/uid-bruno").set({ papel: "admin", nome: "Bruno" });
    await db.ref("gcTopManager/usuarios/uid-outro-admin").set({ papel: "admin", nome: "OutroAdmin" });
    await db.ref("gcTopManager/usuarios/uid-fran").set({ papel: "lideranca", nome: "Fran" });
    await db.ref("gcTopManager/usuarios/uid-automacao").set({ papel: "automacao", nome: "Automação" });
  });
}

async function seedPessoa(id = "pessoa1", extra = {}) {
  await seed(async (db) => {
    await db.ref(`gcTopManager/pessoas/${id}`).set({
      nomeCompleto: "Pessoa Teste",
      situacao: "membro",
      ...extra,
    });
  });
}

async function seedEncontro(id = "encontro1", extra = {}) {
  await seed(async (db) => {
    await db.ref(`gcTopManager/encontros/${id}`).set({
      data: "2026-01-01",
      participantesElegiveis: [],
      presenca: {},
      ...extra,
    });
  });
}

// ---------------------------------------------------------------
// Sem autenticação
// ---------------------------------------------------------------

test("sem autenticação não lê pessoas", async () => {
  await seedPapeis();
  await seedPessoa();
  await assertFails(ctxSemAuth().ref("gcTopManager/pessoas").once("value"));
});

test("sem autenticação não escreve em pessoas (equivalente a REST sem token)", async () => {
  await seedPapeis();
  await assertFails(ctxSemAuth().ref("gcTopManager/pessoas/novaPessoa").set({ nomeCompleto: "X", situacao: "membro" }));
});

// ---------------------------------------------------------------
// Liderança — leituras restritas
// ---------------------------------------------------------------

test("liderança não lê oração privada", async () => {
  await seedPapeis();
  await seed(async (db) => db.ref("gcTopManager/oracaoPrivado/p1").set({ pedido: "sigiloso", status: "novo" }));
  await assertFails(ctxFran().ref("gcTopManager/oracaoPrivado").once("value"));
});

test("liderança não lê acompanhamento pastoral", async () => {
  await seedPapeis();
  await seed(async (db) => db.ref("gcTopManager/acompanhamento/a1").set({ pessoaId: "pessoa1", assunto: "x" }));
  await assertFails(ctxFran().ref("gcTopManager/acompanhamento").once("value"));
});

test("liderança não lê a configuração de aviso de aniversário (e-mail da Fran)", async () => {
  await seedPapeis();
  await seed(async (db) => db.ref("gcTopManager/config/avisoAniversario").set({ email: "fran@example.com" }));
  await assertFails(ctxFran().ref("gcTopManager/config/avisoAniversario").once("value"));
});

// ---------------------------------------------------------------
// Liderança — arquivamento/restauração/exclusão (o bug corrigido nesta rodada)
// ---------------------------------------------------------------

test("liderança NÃO consegue arquivar uma pessoa (setar arquivadoEm)", async () => {
  await seedPapeis();
  await seedPessoa("pessoa1");
  await assertFails(ctxFran().ref("gcTopManager/pessoas/pessoa1").update({ arquivadoEm: "2026-01-01" }));
});

test("liderança CONSEGUE editar outros campos da pessoa sem tocar em arquivadoEm", async () => {
  await seedPapeis();
  await seedPessoa("pessoa1");
  await assertSucceeds(ctxFran().ref("gcTopManager/pessoas/pessoa1").update({ observacoes: "atualizado pela liderança" }));
});

test("liderança NÃO consegue arquivar um encontro", async () => {
  await seedPapeis();
  await seedEncontro("encontro1");
  await assertFails(ctxFran().ref("gcTopManager/encontros/encontro1").update({ arquivadoEm: "2026-01-01" }));
});

test("liderança NÃO consegue restaurar uma pessoa já arquivada (reverter arquivadoEm)", async () => {
  await seedPapeis();
  await seedPessoa("pessoa1", { arquivadoEm: "2026-01-01" });
  await assertFails(ctxFran().ref("gcTopManager/pessoas/pessoa1").update({ arquivadoEm: null }));
});

test("liderança NÃO consegue excluir definitivamente uma pessoa", async () => {
  await seedPapeis();
  await seedPessoa("pessoa1");
  await assertFails(ctxFran().ref("gcTopManager/pessoas/pessoa1").remove());
});

test("admin CONSEGUE arquivar e restaurar uma pessoa", async () => {
  await seedPapeis();
  await seedPessoa("pessoa1");
  await assertSucceeds(ctxBruno().ref("gcTopManager/pessoas/pessoa1").update({ arquivadoEm: "2026-01-01" }));
  await assertSucceeds(ctxBruno().ref("gcTopManager/pessoas/pessoa1").update({ arquivadoEm: null }));
});

test("ninguém (nem admin) consegue reverter uma pessoa já anonimizada", async () => {
  await seedPapeis();
  await seedPessoa("pessoa1", { nomeCompleto: "Pessoa anonimizada", anonimizadoEm: "2026-01-01" });
  await assertFails(ctxBruno().ref("gcTopManager/pessoas/pessoa1").update({ nomeCompleto: "Nome Verdadeiro De Volta" }));
});

// ---------------------------------------------------------------
// Papéis — ninguém altera o próprio, admin altera o de outro
// ---------------------------------------------------------------

test("liderança não altera o próprio papel", async () => {
  await seedPapeis();
  await assertFails(ctxFran().ref("gcTopManager/usuarios/uid-fran/papel").set("admin"));
});

test("admin não altera o próprio papel", async () => {
  await seedPapeis();
  await assertFails(ctxBruno().ref("gcTopManager/usuarios/uid-bruno/papel").set("lideranca"));
});

test("admin altera o papel de outro usuário", async () => {
  await seedPapeis();
  await assertSucceeds(ctxBruno().ref("gcTopManager/usuarios/uid-fran/papel").set("admin"));
});

// ---------------------------------------------------------------
// Conta de automação — só o que precisa, nada além disso
// ---------------------------------------------------------------

test("automação lê pessoas (precisa disso pros aniversários)", async () => {
  await seedPapeis();
  await seedPessoa();
  await assertSucceeds(ctxAutomacao().ref("gcTopManager/pessoas").once("value"));
});

test("automação lê config/avisoAniversario", async () => {
  await seedPapeis();
  await seed(async (db) => db.ref("gcTopManager/config/avisoAniversario").set({ email: "fran@example.com" }));
  await assertSucceeds(ctxAutomacao().ref("gcTopManager/config/avisoAniversario").once("value"));
});

test("automação NÃO lê pedidos de oração", async () => {
  await seedPapeis();
  await seed(async (db) => db.ref("gcTopManager/oracaoVisivel/p1").set({ pedido: "x", status: "novo", privacidade: "liderança" }));
  await assertFails(ctxAutomacao().ref("gcTopManager/oracaoVisivel").once("value"));
});

test("automação NÃO lê acompanhamento pastoral", async () => {
  await seedPapeis();
  await seed(async (db) => db.ref("gcTopManager/acompanhamento/a1").set({ pessoaId: "pessoa1" }));
  await assertFails(ctxAutomacao().ref("gcTopManager/acompanhamento").once("value"));
});

test("automação NÃO lê encontros", async () => {
  await seedPapeis();
  await seedEncontro();
  await assertFails(ctxAutomacao().ref("gcTopManager/encontros").once("value"));
});

// ---------------------------------------------------------------
// Validação de campos
// ---------------------------------------------------------------

test("campo inesperado é recusado na criação de pessoa", async () => {
  await seedPapeis();
  await assertFails(
    ctxBruno().ref("gcTopManager/pessoas/novaPessoa").set({
      nomeCompleto: "Fulano",
      situacao: "membro",
      campoQueNaoDeveriaExistir: "hackzor",
    })
  );
});

test("data de nascimento em formato inválido é recusada", async () => {
  await seedPapeis();
  await assertFails(
    ctxBruno().ref("gcTopManager/pessoas/novaPessoa").set({
      nomeCompleto: "Fulano",
      situacao: "membro",
      nascimento: "31/02/2000",
    })
  );
});

test("pessoa SEM nascimento/chegouEm é aceita (campos opcionais)", async () => {
  await seedPapeis();
  await assertSucceeds(
    ctxBruno().ref("gcTopManager/pessoas/novaPessoaSemData").set({
      nomeCompleto: "Fulano Sem Data",
      situacao: "visitante",
    })
  );
});

test("situação fora do enum é recusada", async () => {
  await seedPapeis();
  await assertFails(
    ctxBruno().ref("gcTopManager/pessoas/novaPessoa").set({
      nomeCompleto: "Fulano",
      situacao: "situacao-inventada",
    })
  );
});
