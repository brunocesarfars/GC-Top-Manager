/**
 * TESTES DE INTERFACE (parte executável sem Firebase real)
 * ---------------------------------------------------------------
 * Roda com: node tests/interface.test.js
 *
 * Cobre a lógica por trás de várias das telas — validação de
 * formulário, detecção de duplicados, matriz de permissões — sem
 * precisar de um navegador nem de um projeto Firebase. Login,
 * recuperação de senha, upload de foto e "Fran sem acesso a dados
 * privados" DEPENDEM de um projeto Firebase real (ou do Local
 * Emulator Suite, que este sandbox não consegue baixar — ver
 * LEIA-ME.md) e por isso NÃO estão aqui: estão documentados como
 * checklist manual no LEIA-ME.md, seção de testes.
 */
const assert = require("node:assert");
const path = require("path");

global.window = undefined; // força os módulos a usarem os requires de Node, não os globais de navegador
const DateUtil = require(path.join(__dirname, "../js/datetime.js"));
global.DateUtil = DateUtil;
const Logica = require(path.join(__dirname, "../js/logica-pura.js"));
global.Logica = Logica;
const Permissoes = require(path.join(__dirname, "../js/permissoes.js"));
global.Permissoes = Permissoes;
const Utils = require(path.join(__dirname, "../js/utils.js"));
global.Utils = Utils;
const Pessoas = require(path.join(__dirname, "../js/pessoas.js"));

let passou = 0;
let falhou = 0;

function teste(nome, fn) {
  try {
    fn();
    console.log(`✅ ${nome}`);
    passou++;
  } catch (e) {
    console.log(`❌ ${nome}`);
    console.log("   " + e.message);
    falhou++;
  }
}

// ---------------------------------------------------------------
// Cadastro de pessoa — datas opcionais e validação (item 3)
// ---------------------------------------------------------------

teste("cadastro de pessoa SEM aniversário é válido (campo opcional)", () => {
  const r = Utils.validarDataOpcional("");
  assert.strictEqual(r.valido, true);
  assert.strictEqual(r.vazio, true);
});

teste("cadastro de pessoa COM aniversário válido é aceito", () => {
  const r = Utils.validarDataOpcional("1990-05-20", { proibirFutura: true });
  assert.strictEqual(r.valido, true);
});

teste("31/02 é recusado com mensagem clara (não '31 de fevereiro' silenciosamente virando março)", () => {
  const r = Utils.validarDataOpcional("2020-02-31");
  assert.strictEqual(r.valido, false);
  assert.match(r.motivo, /não existe/);
});

teste("data de nascimento no futuro é recusada", () => {
  const anoQueVem = String(Number(DateUtil.hojeISO().slice(0, 4)) + 1);
  const r = Utils.validarDataOpcional(`${anoQueVem}-01-01`, { proibirFutura: true });
  assert.strictEqual(r.valido, false);
  assert.match(r.motivo, /futuro/);
});

teste("'Chegou ao GC em' no futuro NÃO é bloqueado (só nascimento tem essa regra)", () => {
  const anoQueVem = String(Number(DateUtil.hojeISO().slice(0, 4)) + 1);
  const r = Utils.validarDataOpcional(`${anoQueVem}-01-01`, { proibirFutura: false });
  assert.strictEqual(r.valido, true);
});

// ---------------------------------------------------------------
// Visitante duplicado (item 12 da rodada anterior, reconfirmado aqui)
// ---------------------------------------------------------------

teste("visitante com telefone igual a alguém já cadastrado é detectado", () => {
  const pessoas = [{ id: "p1", nomeCompleto: "Maria Costa", telefone: "19991230002" }];
  const duplicatas = Pessoas.encontrarPossiveisDuplicatas("Maria C.", "(19) 99123-0002", pessoas);
  assert.strictEqual(duplicatas.length, 1);
});

teste("visitante com nome parecido (mesmo primeiro nome + sobrenome em comum) é detectado", () => {
  const pessoas = [{ id: "p1", nomeCompleto: "João Pedro Silva", telefone: "" }];
  const duplicatas = Pessoas.encontrarPossiveisDuplicatas("João Silva", "", pessoas);
  assert.strictEqual(duplicatas.length, 1);
});

teste("pessoa arquivada não conta como duplicata", () => {
  const pessoas = [{ id: "p1", nomeCompleto: "Maria Costa", telefone: "19991230002", arquivadoEm: "2026-01-01" }];
  const duplicatas = Pessoas.encontrarPossiveisDuplicatas("Maria Costa", "19991230002", pessoas);
  assert.strictEqual(duplicatas.length, 0);
});

teste("nomes realmente diferentes não geram falso positivo", () => {
  const pessoas = [{ id: "p1", nomeCompleto: "Ana Beatriz", telefone: "11111111111" }];
  const duplicatas = Pessoas.encontrarPossiveisDuplicatas("Carlos Eduardo", "22222222222", pessoas);
  assert.strictEqual(duplicatas.length, 0);
});

// ---------------------------------------------------------------
// Histórico relacionado — decide anonimizar vs. excluir (item 4)
// ---------------------------------------------------------------

teste("pessoa sem nenhum histórico pode ser excluída definitivamente", () => {
  const state = { encontros: [], oracaoVisivel: [], oracaoPrivado: [], acompanhamento: [] };
  assert.strictEqual(Pessoas.temHistoricoRelacionado("p1", state), false);
});

teste("pessoa que aparece em participantesElegiveis de um encontro TEM histórico (não pode excluir, só anonimizar)", () => {
  const state = { encontros: [{ id: "e1", participantesElegiveis: ["p1"], presenca: {} }], oracaoVisivel: [], oracaoPrivado: [], acompanhamento: [] };
  assert.strictEqual(Pessoas.temHistoricoRelacionado("p1", state), true);
});

teste("pessoa com pedido de oração tem histórico", () => {
  const state = { encontros: [], oracaoVisivel: [{ pessoaId: "p1" }], oracaoPrivado: [], acompanhamento: [] };
  assert.strictEqual(Pessoas.temHistoricoRelacionado("p1", state), true);
});

// ---------------------------------------------------------------
// Matriz de permissões — botão por botão (item 2)
// ---------------------------------------------------------------

const BOTOES_ADMIN_SOMENTE = ["arquivarPessoas", "anonimizarPessoas", "excluirDefinitivamente", "arquivarEncontros", "editarPulpito", "editarConfigAniversario", "verAcompanhamentoPastoral", "verOracaoPrivada", "gerenciarUsuarios", "verLixeira", "restaurarLixeira"];

BOTOES_ADMIN_SOMENTE.forEach((acao) => {
  teste(`"${acao}" é permitido para admin e negado para liderança`, () => {
    assert.strictEqual(Permissoes.pode("admin", acao), true);
    assert.strictEqual(Permissoes.pode("lideranca", acao), false);
  });
});

const BOTOES_AMBOS_OS_PAPEIS = ["verPessoas", "editarPessoas", "verEncontros", "registrarPresenca", "editarEncontros", "adicionarVisitante", "verPulpito", "editarOracao", "verCuidado", "resolverCuidado"];

BOTOES_AMBOS_OS_PAPEIS.forEach((acao) => {
  teste(`"${acao}" é permitido tanto para admin quanto para liderança`, () => {
    assert.strictEqual(Permissoes.pode("admin", acao), true);
    assert.strictEqual(Permissoes.pode("lideranca", acao), true);
  });
});

teste("papel desconhecido (ou nulo) nunca tem permissão nenhuma", () => {
  assert.strictEqual(Permissoes.pode(null, "verPessoas"), false);
  assert.strictEqual(Permissoes.pode("visitante-random", "verPessoas"), false);
});

// ---------------------------------------------------------------
// Presença — ausência gravada como false (revalidado aqui também)
// ---------------------------------------------------------------

teste("desmarcar alguém que estava presente grava false, não remove a chave", () => {
  const elegiveis = ["a", "b"];
  const presencaAnterior = { a: true, b: true };
  const presencaNaTela = { a: true, b: false }; // b foi desmarcado na tela
  const resultado = Logica.montarPresencaExplicita(elegiveis, presencaNaTela, []);
  assert.strictEqual(resultado.b, false);
  assert.notStrictEqual(resultado.b, undefined);
});

console.log(`\n${passou} passaram, ${falhou} falharam.`);
process.exit(falhou > 0 ? 1 : 0);
