# GC Top Manager — v3 (revisão final: autorização, integridade, formulários e automação)

Esta versão corrige problemas apontados numa revisão da v2. Nenhuma
funcionalidade foi removida e a identidade visual não foi tocada
(`css/style.css` continua a mesma desde a v1). Como sempre: **não
publique sem passar pelo checklist no final**.

---

## 1. O que foi corrigido nesta rodada

### 1.1. Regras de arquivamento (o bug mais sério)
A v2 tinha uma falha real: a regra de escrita de `pessoas` e
`encontros` liberava o nó inteiro pra liderança (`newData.exists()`
só impedia exclusão física, não impedia mudar `arquivadoEm`). Corrigido
embutindo a trava DIRETO na condição de `.write` do nó pai — não numa
regra filha, porque no Realtime Database uma regra de escrita mais
"alta" que já libera o nó inteiro não pode ser revogada por uma regra
mais "baixa" (foi exatamente esse erro que você apontou, e você está
certo). Agora:

```
".write": "... || (papel === 'lideranca' && newData.exists()
  && newData.child('arquivadoEm').val() === data.child('arquivadoEm').val()
  && newData.child('anonimizadoEm').val() === data.child('anonimizadoEm').val())"
```

Isso garante no servidor que liderança **nunca** consegue: arquivar,
restaurar (reverter `arquivadoEm`), excluir definitivamente (bloqueado
por `newData.exists()`), ou mexer em `anonimizadoEm`. Testado em
`tests/regras.rules.test.js` (ver seção de testes abaixo sobre por que
não consegui rodar esses testes aqui).

Também percebi e corrigi, nessa mesma revisão das regras, que
`avisosEnviados` não deixava a conta de automação LER o próprio
registro — o que quebraria a checagem de duplicidade do Apps Script.

### 1.2. Permissões em todos os botões
`Permissoes.pode()` agora é checado explicitamente antes de mostrar
cada botão listado no seu pedido (criar/editar/arquivar pessoa e
encontro, registrar presença, adicionar visitante, mensagens, pedidos
de oração, acompanhamento, configurações, lixeira). Botões que exigem
permissão que a pessoa não tem simplesmente não aparecem — não existe
mais nenhum caminho de "clicar e depois ver erro de permissão" nas
telas de Pessoas, Encontros, Cuidado e Lixeira. Adicionei duas
permissões novas na matriz que faltavam: `arquivarEncontros` e
`adicionarVisitante` (mais `anonimizarPessoas`, da correção do item
4). Coberto por testes automatizados (`tests/interface.test.js`).

### 1.3. Datas opcionais com validação de verdade
Nascimento e "Chegou ao GC em" agora são realmente opcionais:
- Campo vazio não manda `""` pro banco — na criação o campo é omitido,
  na edição manda `null` (o que remove o campo no Firebase).
- `Utils.validarDataOpcional()` (novo, em `js/utils.js`) recusa datas
  que não existem no calendário (ex.: 31/02 — testado, ver
  `tests/interface.test.js`) e recusa nascimento no futuro, com
  mensagem clara embaixo do campo (não mais só "Erro ao salvar").
- "Chegou ao GC em" continua sendo preenchido automaticamente com a
  data do encontro quando alguém é cadastrado pelo "+ Adicionar
  visitante" — isso já existia desde a v2 e continua.

### 1.4. Anonimização em vez de exclusão, quando há histórico
Antes de excluir de verdade, o app agora verifica se a pessoa aparece
em algum encontro (presença/elegibilidade/visita), pedido de oração ou
acompanhamento (`Pessoas.temHistoricoRelacionado()`). Se sim, o botão
vira **"Anonimizar dados pessoais"** em vez de "Excluir
definitivamente": apaga nome, telefone, WhatsApp, e-mail, foto e
observações (preservando o id interno e todo o histórico de presença
e estatísticas), marca `anonimizadoEm`, e as regras do banco impedem
— pra sempre, mesmo pra admin — que esses campos voltem ao que eram.
Só quando não há nenhum histórico relacionado a exclusão definitiva
continua disponível. A Lixeira reflete isso automaticamente.

### 1.5. Automação de aniversário mais robusta
Reescrevi `apps-script/aviso-aniversariantes.gs`:
- `dbGet_`/`dbSet_`/`dbRemove_` agora conferem o status HTTP e lançam
  erro se não vier 200-299 — nada mais "segue como se tivesse dado
  certo" silenciosamente.
- Antes de enviar, o script faz uma **reserva atômica** usando ETag/
  if-match da REST API do Realtime Database (compare-and-swap): duas
  execuções não conseguem enviar o mesmo aviso ao mesmo tempo.
- Estados explícitos por aviso: `reservado` → `enviando` → `sucesso`
  \| `erro` \| `incerto`. "Incerto" (e-mail enviado, mas não deu pra
  confirmar o registro) nunca é reenviado sozinho — fica registrado
  assim e o script tenta avisar por e-mail que precisa de revisão
  manual.

### 1.6. Horário do aviso agora controla de verdade
Implementei a opção recomendada: o gatilho do Apps Script deve rodar
**a cada 15 minutos** (não mais uma vez por dia); a cada execução, o
script lê `config.avisoAniversario.horario` e só processa o envio se o
horário atual (America/Sao_Paulo) estiver dentro da janela de 15
minutos a partir dali. Fora da janela, a execução não faz nada (é
barata, pode rodar o dia todo sem problema). O campo de horário no app
continua existindo — agora ele realmente controla o envio — com uma
notinha na tela explicando a dependência do gatilho de 15 em 15 min.

### 1.7 e 1.8. Testes
Ver seção 4 (relatório de testes) — é importante você ler com atenção
a parte sobre o que eu consegui RODAR de verdade e o que só ficou
escrito e pronto pra você rodar.

### 1.9. PWA
Gerei de verdade (não é só código — são os arquivos de imagem):
`icons/icon-192.png`, `icons/icon-512.png`,
`icons/icon-512-maskable.png`, `icons/apple-touch-icon.png` — um
ícone vetorial simples "gc✦" em navy/gold, dentro da zona segura pra
mascaramento adaptativo (Android). `manifest.json` atualizado com os
três primeiros; `index.html` com o link do apple-touch-icon. O
service worker agora tem uma versão de cache nova
(`gc-top-manager-shell-v2`) e um fluxo de atualização: quando existe
uma versão nova instalada, aparece um aviso discreto ("Nova versão
disponível — Atualizar") em vez de trocar a versão debaixo do uso sem
avisar.

---

## 2. Configuração (igual à v2, com um ajuste no gatilho)

Os passos de configuração do Firebase (criar projeto, ativar
Authentication/Realtime Database/Storage, preencher
`js/firebase-config.js`, publicar as regras, criar as contas de Bruno
e Fran) são os mesmos da entrega anterior — não vou repetir tudo aqui
pra não duplicar; o que muda:

- **Gatilho do Apps Script**: configure `enviarAvisosDeAniversario`
  para rodar **a cada 15 minutos** (Editar gatilho → Baseado em tempo
  → Temporizador por minuto → Cada 15 minutos), não mais "uma vez por
  dia". O script mesmo decide, a cada execução, se está dentro da
  janela configurada no app.
- Publique as regras atualizadas em `rules/database.rules.json` —
  **substitua** as regras antigas da v2, não apenas acrescente.

---

## 3. Matriz de permissões (atualizada)

| Ação | Admin | Liderança |
|---|:---:|:---:|
| Ver/editar pessoas | ✅ | ✅ |
| Arquivar pessoas | ✅ | ❌ |
| Anonimizar pessoas (quando há histórico) | ✅ | ❌ |
| Excluir pessoas definitivamente (sem histórico) | ✅ | ❌ |
| Ver/editar encontros, registrar presença, adicionar visitante | ✅ | ✅ |
| Arquivar encontros | ✅ | ❌ |
| Ver Púlpito | ✅ | ✅ |
| Editar/arquivar/duplicar Púlpito | ✅ | ❌ |
| Ver aniversariantes | ✅ | ✅ |
| Editar config. de aviso de aniversário | ✅ | ❌ |
| Ver/editar pedidos de oração visíveis | ✅ | ✅ |
| Ver/editar pedidos de oração **privados** | ✅ | ❌ |
| Ver/editar acompanhamento pastoral | ✅ | ❌ |
| Ver cuidado / resolver alertas | ✅ | ✅ |
| Gerenciar usuários (papéis) | ✅ | ❌ |
| Ver lixeira / restaurar / excluir definitivamente | ✅ | ❌ |

Lembrete de sempre: isso é conveniência de interface. A garantia real
está em `rules/database.rules.json`.

---

## 4. Relatório de testes — o que eu RODEI vs. o que só está escrito

Sendo direto sobre os limites deste ambiente, porque isso importa:

### 4.1. Rodei de verdade, aqui, agora — 56 testes, todos passando
```
node tests/logica.test.js       →  21 de 21 passaram
node tests/interface.test.js    →  35 de 35 passaram
```
`logica.test.js` cobre frequência, presença explícita, 29/fevereiro e
detecção de cuidado (igual à entrega anterior). `interface.test.js` é
novo nesta rodada e cobre, com testes reais de Node (sem simulação de
navegador): datas opcionais aceitando vazio, recusando 31/02 e
recusando nascimento futuro; detecção de visitante duplicado por
telefone e por nome parecido (e que pessoa arquivada não conta);
`temHistoricoRelacionado` decidindo corretamente anonimizar vs.
excluir; e a matriz de permissões inteira, ação por ação, admin vs.
liderança.

### 4.2. Escrevi o teste, tentei rodar, e o ambiente me bloqueou — sendo honesto sobre isso
`tests/regras.rules.test.js` cobre TODA a lista que você pediu (sem
autenticação, liderança não lê privado/acompanhamento/config, não
arquiva/restaura/exclui pessoa nem encontro, ninguém altera o próprio
papel, admin altera o de outro, automação só lê o que precisa,
validação de campos e datas). O comando exato pra rodar é:

```
npm install
npm run test:regras
# equivalente a: firebase emulators:exec --only database,auth "node --test tests/regras.rules.test.js"
```

Eu tentei rodar esse exato comando aqui, duas vezes. Ele funciona até
o ponto de baixar o emulador do Realtime Database — e falha assim:

```
Error: download failed, status 403: Host not in allowlist: storage.googleapis.com.
Add this host to your network egress settings to allow access.
```

Esse ambiente de geração de código só tem acesso a alguns domínios
(registro do npm, GitHub, PyPI etc.) — `storage.googleapis.com`, de
onde vem o `.jar` do emulador do Realtime Database, não está
liberado. Não tem workaround por aqui: confirmei que não existe
nenhuma cópia em cache do emulador na máquina. **Isso significa que os
21 cenários de regras estão escritos, revisados manualmente por mim,
e prontos — mas eu não vi nenhum deles passar de verdade.** Rode
`npm run test:regras` na sua máquina (com internet normal) antes de
confiar nas regras — é rápido, o emulador baixa uma vez só.

### 4.3. Só dá pra testar com Firebase real / manualmente (checklist)
Login, recuperação de senha, upload de foto, logout e "Fran sem acesso
a dados privados navegando de verdade" precisam de um projeto Firebase
de verdade (ou pelo menos o emulador, que está bloqueado aqui pelo
motivo acima). Checklist pra você rodar manualmente depois de
configurar:
- [ ] Login com Bruno e com Fran funciona.
- [ ] "Esqueci minha senha" chega por e-mail.
- [ ] Logout limpa a sessão (voltar pra tela de login).
- [ ] Upload de foto de pessoa aparece no Storage e na ficha.
- [ ] Logada como Fran, abrir o DevTools → aba Rede → confirmar que
      nenhuma resposta de `/acompanhamento`, `/oracaoPrivado` ou
      `/config` chega no navegador (não é só "a tela não mostra": tem
      que conferir que o dado nem chegou).
- [ ] Arquivar pessoa/encontro só funciona logado como Bruno; logado
      como Fran, o botão nem aparece, e forçando a chamada direto
      (console do navegador) a regra recusa.

---

## 5. Checklist de publicação

- [ ] Publicar as regras ATUALIZADAS desta v3 (substituindo as da v2).
- [ ] Rodar `npm run test:regras` na sua máquina e conferir que os 21
      cenários passam antes de confiar nas regras em produção.
- [ ] Reconfigurar o gatilho do Apps Script para 15 em 15 minutos.
- [ ] Repetir o checklist manual da seção 4.3.
- [ ] Só depois disso, liberar para uso — de novo, isto está indo pra
      sua revisão, não estou declarando pronto pra produção.

---

## 6. O que ficou para uma próxima versão

- Autorização fina por registro individual de oração (permanece igual
  à limitação já registrada na entrega anterior).
- Gráficos históricos mais elaborados.
- Rodar de fato o `tests/regras.rules.test.js` num ambiente com acesso
  ao `storage.googleapis.com` — assim que isso acontecer, o resultado
  real (passou/falhou, com detalhes) deveria substituir esta nota.
- Considerar mover o envio de aniversário para uma Cloud Function.
